/* Traduceri TED — interfață. Datele rămân pe acest PC. */
"use strict";

const S = { state: null, project: null, lang: null, tab: "pagini", job: null, ai: {}, page: 1, files: [], kind: "fisa" };
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(method, url, body, isForm) {
  const opt = { method, headers: { "X-Fise": "1" } };
  if (body !== undefined) {
    if (isForm) opt.body = body;
    else { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
  }
  const r = await fetch(url, opt);
  let data = {};
  try { data = await r.json(); } catch { /* fără conținut */ }
  if (!r.ok) throw new Error(data.error || `Eroare ${r.status}`);
  return data;
}
function toast(msg, isErr) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast" + (isErr ? " err" : "");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.add("hidden"), isErr ? 8000 : 3000);
}
async function safe(fn) { try { return await fn(); } catch (e) { toast(e.message, true); } }
const langName = (c) => S.state.languages[c] || c;
const pfile = (rel) => `/api/projects/${S.project.id}/file/${rel}`;
const srcLang = () => (S.project.source_language === "auto" ? S.project.detected_language || "en" : S.project.source_language);
const hasWords = (t) => /[^\W\d_]{2,}/u.test(t || "");

function textFor(f, lang) {
  if (lang === "src") return [f.src, "sursa"];
  if (f.ov && lang in f.ov) return [f.ov[lang], "manual"];
  if (f.tr && lang in f.tr) return [f.tr[lang], "ai"];
  if (lang === srcLang() || !hasWords(f.src)) return [f.src, "sursa"];
  return [f.src, "lipsa"];
}
const badge = (s) => ({ manual: '<span class="st manual">corectat</span>', ai: '<span class="st ai">AI</span>', lipsa: '<span class="st lipsa">netradus</span>' }[s] || "");

/* ------------------------------------------------------------------ pornire */
async function boot() {
  S.state = await api("GET", "/api/state");
  renderSidebar();
  $("#btnNew").onclick = () => { closeModal(); S.project = null; renderSidebar(); renderNew(); };
  $("#btnAI").onclick = () => openAI();
  $("#btnAITop").onclick = () => openAI();
  $("#aiBanner").onclick = () => openAI();
  $("#btnSettingsTop").onclick = () => openSettings();
  $("#btnSettings").onclick = () => openSettings();
  $("#btnUpdate").onclick = () => openUpdate();
  $("#btnQuit").onclick = () => quitApp();
  $("#updBanner").onclick = () => openUpdate();
  $("#verLabel").textContent = "v" + (S.state.version || "?");
  let touched = false;  // utilizatorul a început deja să lucreze => nu mai deschidem nimic peste pagină
  document.addEventListener("pointerdown", () => { touched = true; }, { capture: true, once: true });
  refreshAI().then((st) => {
    // prima pornire pe acest PC, fără AI conectat: arătăm o singură dată fereastra de conectare
    let shown = false;
    try { shown = localStorage.getItem("aiWelcome") === "1"; } catch { /* fără localStorage */ }
    if (!touched && !shown && !Object.values(st || {}).some((x) => x.ready)) {
      try { localStorage.setItem("aiWelcome", "1"); } catch { /* fără localStorage */ }
      openAI("Bun venit! Alege mai jos ce AI folosești, apoi: 1) Instalează (o singură dată), 2) Conectează-te cu contul, 3) Verifică. "
        + "Poți închide fereastra (✕) și o redeschizi oricând din „Conectare AI”.");
    }
  });
  checkUpdate(false);
  if (S.state.projects.length) openProject(S.state.projects[0].id); else renderNew();
}
async function refreshAI() {
  try { S.ai = await api("GET", "/api/ai/status"); } catch { S.ai = {}; }
  const ready = Object.values(S.ai).some((x) => x.ready);
  $("#aiDot").className = "dot " + (ready ? "ok" : "bad");
  $("#aiDotTop").className = "dot " + (ready ? "ok" : "bad");
  $("#aiBanner").classList.toggle("hidden", ready);
  return S.ai;
}
function renderSidebar() {
  $("#projectList").innerHTML = S.state.projects.map((p) => `
    <a data-id="${p.id}" class="${S.project && S.project.id === p.id ? "active" : ""}">${p.type === "manual" ? "📘" : "📄"} ${esc(p.name)}
      <small>${p.type === "manual" ? "Manual" : "Fișă tehnică"} · ${p.languages.map((l) => l.toUpperCase()).join(" ")}</small></a>`).join("")
    || '<small style="padding:8px 10px">Niciun document încă.</small>';
  $$("#projectList a").forEach((a) => (a.onclick = () => openProject(a.dataset.id)));
}
async function reloadList() { S.state = await api("GET", "/api/state"); renderSidebar(); }

/* ------------------------------------------------------------------ document nou */
function renderNew() {
  S.files = [];
  const langs = Object.entries(S.state.languages).map(([c, n]) => `
    <label class="chk"><input type="checkbox" value="${c}" ${c === "ro" ? "checked" : ""}> ${esc(n)}</label>`).join("");
  $("#main").innerHTML = `
  <div class="steps">
    <div><h1>Traducere document</h1>
      <p class="muted">Pui PDF-ul în engleză (fișă tehnică sau manual), bifezi limbile și apeși butonul.
      Primești <b>același document</b> — cu toate pozele, schemele și tabelele — în fiecare limbă.</p></div>
    <div class="card"><h2><span class="step-num">1</span>Ce documente sunt?</h2>
      <div class="lang-bar"><button class="lang-btn ${S.kind === "fisa" ? "active" : ""}" data-k="fisa">📄 Fișe tehnice</button>
      <button class="lang-btn ${S.kind === "manual" ? "active" : ""}" data-k="manual">📘 Manuale de utilizare</button></div></div>
    <div class="card"><h2><span class="step-num">2</span>PDF-urile</h2>
      <div class="drop" id="drop"><b>Trage aici unul sau mai multe PDF-uri</b><br><span class="muted">sau apasă pentru a le alege — fiecare PDF devine un document separat</span>
        <input type="file" id="fileIn" multiple accept=".pdf" hidden></div>
      <div class="file-chips" id="chips"></div></div>
    <div class="card"><h2><span class="step-num">3</span>În ce limbi?</h2>
      <div class="row"><span class="muted">Fiecare limbă se traduce direct din original.</span><span class="spacer"></span>
        <button class="btn small" id="allL">Toate</button><button class="btn small" id="noL">Niciuna</button></div>
      <div class="langs" id="langs">${langs}</div>
      <details style="margin-top:12px"><summary class="muted">Opțiuni</summary>
        <label class="chk" style="margin-top:8px;display:inline-flex"><input type="checkbox" id="rebrand">
          Documentul e de la alt producător: înlocuiește logo-ul și numele lui cu TED</label></details></div>
    <div class="row"><button class="btn primary big" id="go">Scanează, verifică, tradu și exportă</button><span class="muted" id="goHint"></span></div>
  </div>`;
  $$("[data-k]").forEach((b) => (b.onclick = () => { S.kind = b.dataset.k; $$("[data-k]").forEach((x) => x.classList.toggle("active", x === b)); }));
  const drop = $("#drop"), input = $("#fileIn");
  drop.onclick = () => input.click();
  input.onchange = () => addFiles(input.files);
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add("over"); };
  drop.ondragleave = () => drop.classList.remove("over");
  drop.ondrop = (e) => { e.preventDefault(); drop.classList.remove("over"); addFiles(e.dataTransfer.files); };
  $("#allL").onclick = () => $$("#langs input").forEach((i) => (i.checked = true));
  $("#noL").onclick = () => $$("#langs input").forEach((i) => (i.checked = false));
  $("#go").onclick = () => safe(async () => {
    if (!S.files.length) throw new Error("Adaugă cel puțin un PDF (pasul 2).");
    const languages = $$("#langs input:checked").map((i) => i.value);
    if (!languages.length) throw new Error("Bifează cel puțin o limbă (pasul 3).");
    $("#go").disabled = true;
    const ids = [];
    for (const [i, f] of S.files.entries()) {
      $("#goHint").textContent = `Încarc ${i + 1}/${S.files.length}: ${f.name}…`;
      const fd = new FormData();
      fd.append("file", f); fd.append("type", S.kind); fd.append("languages", languages.join(","));
      fd.append("replace_brand", $("#rebrand").checked ? "1" : "0");
      const p = await api("POST", "/api/projects", fd, true);
      ids.push(p.id);
    }
    await reloadList();
    $("#goHint").textContent = "Verific conexiunea AI…";
    const st = await refreshAI();
    const n = ids.length === 1 ? "Documentul a fost adăugat" : `${ids.length} documente au fost adăugate`;
    if (!Object.values(st).some((x) => x.ready)) {  // salvate; le procesăm după conectare
      await openProject(ids[0]);
      openAI(`${n} (îl găsești în stânga, la „Documentele mele”). Ca să fie scanat și tradus, conectează un AI, `
        + "apoi deschide documentul și apasă „Scanează, verifică, tradu și exportă”.");
      return;
    }
    // documentele se procesează unul după altul, în fundal
    S.queue = ids.slice(1);
    await openProject(ids[0]);
    runJob("all");
  }).finally(() => { const b = $("#go"); if (b) b.disabled = false; });
}
function addFiles(list) {
  S.files.push(...[...list].filter((f) => f.name.toLowerCase().endsWith(".pdf")));
  $("#chips").innerHTML = S.files.map((f) => `<span class="chip">📄 ${esc(f.name)}</span>`).join("");
}

/* ------------------------------------------------------------------ proiect */
async function openProject(id) {
  S.project = await api("GET", `/api/projects/${id}`);
  if (!S.lang || !S.project.languages.includes(S.lang)) S.lang = S.project.languages[0];
  S.page = Math.min(S.page || 1, S.project.sources[0]?.pages.length || 1);
  renderSidebar();
  renderProject();
  if (S.project._job) pollJob(S.project._job.id);
}
async function reloadProject() { await openProject(S.project.id); }

function issueCount(p) {
  let n = Object.values(p.qa || {}).reduce((a, l) => a + l.filter((i) => i.severity === "error").length, 0);
  for (const pg of p.doc?.pages || []) for (const b of pg.blocks) {
    n += Object.keys(b.text.check || {}).length + Object.keys(b.text.warn || {}).length;
  }
  return n;
}

function renderProject() {
  const p = S.project;
  const n = issueCount(p);
  const tabs = [["pagini", "Pagini"], ["verificare", `Verificare${n ? ` <span class="count">${n}</span>` : ""}`], ["export", "Export PDF"]];
  $("#main").innerHTML = `
  <div class="head">
    <div><input class="title-input" id="pName" value="${esc(p.name)}">
      <div class="row" style="margin-top:4px"><span class="chip">${p.type === "manual" ? "Manual" : "Fișă tehnică"}</span>
      <span class="chip">${p.sources[0]?.pages.length || 0} pagini</span>
      <label class="chip">original:
        <select id="srcSel" style="border:0;background:transparent;padding:0 2px;width:auto">
          ${[["auto", `automat${p.detected_language ? " (" + langName(p.detected_language) + ")" : ""}`], ["en", "English"], ["ro", "Română"], ["zh", "中文"]]
            .map(([v, t]) => `<option value="${v}" ${p.source_language === v ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></label>
      ${p.scan_check ? `<span class="chip ok">scanare verificată</span>` : p.doc ? '<span class="chip warn">scanare neverificată</span>' : ""}</div></div>
    <span class="spacer"></span>
    <button class="btn" id="bAll" title="Refă tot: scanare, verificare, traducere, export">↻ Refă tot</button>
    <button class="btn" id="bTr">Tradu</button>
    <button class="btn primary" id="bExp">Exportă PDF</button>
  </div>
  <div id="jobbar"></div>
  <div class="tabs">${tabs.map(([k, v]) => `<button class="tab ${S.tab === k ? "active" : ""}" data-tab="${k}">${v}</button>`).join("")}</div>
  <div id="tabBody"></div>`;
  $$(".tab").forEach((b) => (b.onclick = () => { S.tab = b.dataset.tab; renderProject(); }));
  $("#pName").onchange = (e) => safe(async () => { S.project = await api("PATCH", `/api/projects/${p.id}`, { name: e.target.value }); reloadList(); });
  $("#srcSel").onchange = (e) => safe(async () => {
    S.project = await api("PATCH", `/api/projects/${p.id}`, { source_language: e.target.value });
    toast("Limba originalului a fost schimbată. Apasă „Tradu”."); renderProject();
  });
  $("#bAll").onclick = () => { if (!p.doc || confirm("Refac scanarea? Corecturile făcute de tine se pierd.")) runJob("all"); };
  $("#bTr").onclick = () => runJob("translate");
  $("#bExp").onclick = () => runJob("export");
  ({ pagini: renderPages, verificare: renderVerify, export: renderExport })[S.tab]();
  renderJobbar();
}

/* ------------------------------------------------------------------ operații în fundal */
async function runJob(action, extra = {}) {
  await safe(async () => {
    const job = await api("POST", `/api/projects/${S.project.id}/run`, { action, ...extra });
    pollJob(job.id);
  });
}
async function pollJob(id) {
  S.job = await api("GET", `/api/jobs/${id}`).catch(() => null);
  renderJobbar();
  if (!S.job) return;
  if (S.job.state === "running") { setTimeout(() => pollJob(id), 1500); return; }
  const done = S.job;
  await reloadProject();
  await reloadList();
  if (done.state === "error") showNotice("err", `<b>${esc(done.title)} nu a reușit.</b> ${esc(done.error)}`);
  else {
    toast(`${done.title}: gata.`);
    if (done.title.startsWith("Scanare,")) { S.tab = "export"; renderProject(); }
    if (S.queue?.length) {  // următorul document din lot
      const next = S.queue.shift();
      await openProject(next);
      runJob("all");
    }
  }
}
function renderJobbar() {
  const el = $("#jobbar");
  if (!el) return;
  const j = S.job;
  if (j && j.state === "running" && j.project_id === S.project.id) {
    el.innerHTML = `<div class="jobbar"><div class="spin"></div><div><b>${esc(j.title)}</b><br><span class="muted">${esc(j.message)}</span>
      ${S.queue?.length ? `<br><span class="muted">Urmează încă ${S.queue.length} documente.</span>` : ""}</div></div>`;
    $$("#main input, #main textarea, #main select, #main .btn").forEach((x) => (x.disabled = true));
  } else el.innerHTML = "";
}
function showNotice(kind, html) { const el = $("#jobbar"); if (el) el.innerHTML = `<div class="notice ${kind}">${html}</div>`; }

/* ------------------------------------------------------------------ fila Pagini */
function langBar() {
  return `<div class="lang-bar"><span class="muted">Limba:</span>
    <button class="lang-btn ${S.lang === "src" ? "active" : ""}" data-l="src">Original</button>
    ${S.project.languages.map((l) => `<button class="lang-btn ${S.lang === l ? "active" : ""}" data-l="${l}">${esc(langName(l))}</button>`).join("")}
    <button class="btn small ghost" id="editLangs">✎ limbi</button></div>`;
}
function bindLangBar() {
  $$(".lang-btn[data-l]").forEach((b) => (b.onclick = () => { S.lang = b.dataset.l; renderProject(); }));
  $("#editLangs").onclick = editLanguages;
}

function blockRow(b) {
  const [text, state] = textFor(b.text, S.lang);
  const isSrc = S.lang === "src";
  const tag = text.length > 80 ? "textarea" : "input";
  const input = tag === "textarea" ? `<textarea rows="2" data-bid="${b.id}">${esc(text)}</textarea>` : `<input type="text" data-bid="${b.id}" value="${esc(text)}">`;
  const notes = [];
  if (b.scan_fix && isSrc) notes.push(`<div class="issue warning">🔎 corectat la verificarea scanării: „${esc(b.scan_fix.before)}” — ${esc(b.scan_fix.problem)}</div>`);
  if (b.scan_added && isSrc) notes.push('<div class="issue warning">🔎 text găsit doar la verificare — verifică poziția</div>');
  if (!isSrc && b.text.warn?.[S.lang]) notes.push(`<div class="issue error">⚠ ${esc(b.text.warn[S.lang])}</div>`);
  const ck = !isSrc && b.text.check?.[S.lang];
  if (ck && ck.applied && state !== "manual") notes.push(`<div class="issue warning">🔎 corectat automat: ${esc(ck.problem)}
     <button class="btn small ghost" data-revert="${b.id}">Revino la: „${esc(ck.before)}”</button></div>`);
  else if (ck && !ck.applied) notes.push(`<div class="issue warning">🔎 ${esc(ck.problem)}
     ${ck.suggestion ? `<button class="btn small" data-apply="${b.id}">Folosește: „${esc(ck.suggestion)}”</button>` : ""}</div>`);
  return `<tr class="${b.skip ? "skipped" : ""}"><td>${input}${!isSrc && state !== "sursa" ? `<div class="orig-text">${esc(b.text.src)}</div>` : ""}${notes.join("")}</td>
    <td class="actions">${isSrc ? "" : badge(state)}${state === "manual" ? `<button class="btn small ghost" data-reset="${b.id}" title="Renunță la corectură">↺</button>` : ""}
    <button class="btn small ghost" data-skip="${b.id}" data-v="${b.skip ? 0 : 1}" title="Lasă textul original neatins">${b.skip ? "include" : "nu traduce"}</button></td></tr>`;
}

function renderPages() {
  const p = S.project;
  if (!p.doc) {
    $("#tabBody").innerHTML = `<div class="card"><h2>Documentul nu a fost încă scanat</h2>
      <button class="btn primary big" id="go">Scanează, verifică, tradu și exportă</button></div>`;
    $("#go").onclick = () => runJob("all");
    return;
  }
  const n = p.doc.pages.length;
  S.page = Math.min(Math.max(1, S.page), n);
  const pg = p.doc.pages[S.page - 1];
  const lang = S.lang === "src" ? p.languages[0] : S.lang;
  const mode = { pdf: ["ok", "text exact din PDF"], contur: ["ok", "text desenat — poziții exacte din contur"], imagine: ["warn", "pagină scanată — poziții aproximative"] }[pg.mode] || ["", ""];
  const brand = (pg.brand || []).map((r) => `<label class="chk"><input type="checkbox" data-brand="${r.id}" ${r.replace !== false ? "checked" : ""}>
     ${r.kind === "logo" ? "Logo producător → logo TED" : "Contact producător → www.tedelectric.eu"}</label>`).join("");
  $("#tabBody").innerHTML = `
  ${langBar()}
  <div class="row" style="margin-bottom:10px"><button class="btn" id="pPrev" ${S.page === 1 ? "disabled" : ""}>←</button>
    <b>Pagina ${S.page} / ${n}</b><button class="btn" id="pNext" ${S.page === n ? "disabled" : ""}>→</button>
    <span class="chip ${mode[0]}">${mode[1]}</span><span class="spacer"></span>
    <span class="muted">Comparație cu:</span><b>${esc(langName(lang))}</b></div>
  <div class="grid" style="grid-template-columns:1fr 1fr;align-items:start">
    <div class="orig-pane"><div class="pg">Original</div><img src="${pfile(p.sources[0].pages[S.page - 1].image)}"></div>
    <div class="orig-pane"><div class="pg">Rezultat ${esc(langName(lang))}</div>
      <img id="prev" src="/api/projects/${p.id}/preview?lang=${lang}&page=${S.page}&t=${Date.now()}" alt="se generează…"></div>
  </div>
  ${p.replace_brand && brand ? `<div class="card" style="margin-top:12px"><h3>Branding pe această pagină</h3><div class="row">${brand}</div></div>` : ""}
  <div class="card" style="margin-top:12px"><div class="row"><h3>Textele paginii (${pg.blocks.length})</h3><span class="spacer"></span>
    <span class="hint">${S.lang === "src" ? "Corectezi ORIGINALUL: textul se retraduce în toate limbile." : `Corectezi doar în ${esc(langName(S.lang))}. Corectura rămâne și la retraducere.`}</span></div>
    <table class="rows">${pg.blocks.map(blockRow).join("") || '<tr><td class="muted">Fără text.</td></tr>'}</table></div>`;
  bindLangBar();
  $("#pPrev").onclick = () => { S.page -= 1; renderProject(); };
  $("#pNext").onclick = () => { S.page += 1; renderProject(); };
  const put = (bid, body) => safe(async () => { S.project = await api("PUT", `/api/projects/${p.id}/blocks/${bid}`, body); renderProject(); });
  $$("[data-bid]").forEach((el) => (el.onchange = () => put(el.dataset.bid, S.lang === "src" ? { src: el.value } : { lang: S.lang, text: el.value })));
  $$("[data-reset]").forEach((b) => (b.onclick = () => put(b.dataset.reset, { reset: S.lang })));
  $$("[data-skip]").forEach((b) => (b.onclick = () => put(b.dataset.skip, { skip: b.dataset.v === "1" })));
  $$("[data-brand]").forEach((c) => (c.onchange = () => put(c.dataset.brand, { replace: c.checked })));
  $$("[data-apply]").forEach((b) => (b.onclick = () => {
    const blk = pg.blocks.find((x) => x.id === b.dataset.apply);
    put(blk.id, { lang: S.lang, text: blk.text.check[S.lang].suggestion });
  }));
  $$("[data-revert]").forEach((b) => (b.onclick = () => {
    const blk = pg.blocks.find((x) => x.id === b.dataset.revert);
    put(blk.id, { lang: S.lang, text: blk.text.check[S.lang].before });
  }));
}

/* ------------------------------------------------------------------ fila Verificare */
function renderVerify() {
  const p = S.project, sc = p.scan_check, v = p.verification;
  const items = [];
  for (const pg of p.doc?.pages || []) for (const b of pg.blocks) {
    if (b.scan_fix) items.push(["scan", pg.n, b, `Scanare: „${b.scan_fix.before}” → „${b.text.src}” (${b.scan_fix.problem})`]);
    for (const [l, w] of Object.entries(b.text.warn || {})) items.push(["warn", pg.n, b, `${langName(l)}: ${w} — „${b.text.ov?.[l] || b.text.tr?.[l]}”`]);
    for (const [l, c] of Object.entries(b.text.check || {})) items.push(["check", pg.n, b, `${langName(l)}: ${c.problem}${c.applied ? ` — corectat automat: „${c.before}” → „${c.suggestion}”` : c.suggestion ? ` → „${c.suggestion}”` : ""}`]);
  }
  $("#tabBody").innerHTML = `
  <div class="card"><h2>1. Verificarea scanării</h2>
    <p class="muted">Un al doilea AI compară textul citit cu imaginea fiecărei pagini și corectează greșelile de citire (litere, cifre, unități).</p>
    ${sc ? `<div class="notice ok"><b>${esc(sc.provider)}</b> · ${esc(sc.at.replace("T", " "))}: ${sc.corrected} corecturi, ${sc.added} texte adăugate${sc.absent ? `, ${sc.absent} texte vechi ascunse eliminate` : ""}.</div>`
      : '<div class="notice warn">Scanarea nu a fost încă verificată.</div>'}
    <button class="btn" id="vScan">Verifică scanarea din nou</button></div>
  <div class="card"><h2>2. Verificarea traducerilor</h2>
    ${v ? `<div class="notice ${Object.values(v.issues).some((x) => x) ? "warn" : "ok"}"><b>${esc(v.provider)}</b> · ${esc(v.at.replace("T", " "))}:
      ${Object.entries(v.issues).map(([l, x]) => `${esc(langName(l))}: ${x} observații`).join(", ") || "nicio observație"}</div>` : '<div class="notice warn">Traducerile nu au fost verificate.</div>'}
    <button class="btn" id="vTr">Verifică traducerile din nou</button></div>
  <div class="card"><div class="row"><h2>3. Verificarea PDF-urilor finale</h2><span class="spacer"></span>
    <button class="btn" id="vQa">Verifică PDF-urile din nou</button></div>
    <p class="muted">După export, fiecare PDF tradus e controlat automat: cifrele din original, texte suprapuse, text original
      rămas netradus, text vechi ascuns rămas în fișier, plus o verificare vizuală a fiecărei pagini făcută de AI.</p>
    ${Object.keys(p.qa || {}).length ? Object.entries(p.qa).map(([l, list]) => `<h3 style="margin-top:10px">${esc(langName(l))}:
      ${list.length ? `${list.length} observații` : '<span class="chip ok">fără probleme</span>'}</h3>
      ${list.map((i) => `<div class="issue ${i.severity === "error" ? "error" : "warning"}">${i.page ? `<span class="pagelink" data-go="${i.page}">p.${i.page}</span>` : ""}
        <b>${esc(i.check)}</b> ${esc(i.text)}</div>`).join("")}`).join("")
      : '<div class="notice warn">PDF-urile finale nu au fost încă verificate.</div>'}</div>
  <div class="card"><h2>De văzut (${items.length})</h2>
    ${items.map(([k, n, b, t]) => `<div class="issue ${k === "warn" ? "error" : "warning"}"><span class="pagelink" data-go="${n}">p.${n}</span> ${esc(t)}</div>`).join("") || '<p class="muted">Nimic.</p>'}</div>`;
  $("#vScan").onclick = () => runJob("check");
  $("#vTr").onclick = () => runJob("verify");
  $("#vQa").onclick = () => runJob("qa");
  $$("[data-go]").forEach((a) => (a.onclick = () => { S.page = +a.dataset.go; S.tab = "pagini"; renderProject(); }));
}

/* ------------------------------------------------------------------ fila Export */
function renderExport() {
  const p = S.project, ex = p.exports || [];
  $("#tabBody").innerHTML = `
  <div class="card"><div class="row"><h2>PDF-urile traduse</h2><span class="spacer"></span>
    <button class="btn primary" id="doExp">Generează din nou</button></div>
    ${ex.length ? ex.map((e) => `<div style="border-top:1px solid var(--line);padding:8px 0"><div class="row"><b>${esc(langName(e.lang))}</b> · ${e.pages} pagini
      <span class="spacer"></span><button class="btn small" data-view="${e.file}">Previzualizează</button>
      <a class="btn small primary" href="${pfile(e.file)}?download=1">Descarcă</a></div>
      ${e.warnings.length ? `<div class="notice warn" style="margin-top:6px"><ul>${e.warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></div>` : '<span class="chip ok">fără avertismente</span>'}
      ${p.qa?.[e.lang] ? (p.qa[e.lang].length ? `<span class="chip warn">${p.qa[e.lang].length} observații la verificarea finală — vezi fila Verificare</span>` : '<span class="chip ok">verificare finală: fără probleme</span>') : ""}</div>`).join("")
      : '<p class="muted">Încă nu există PDF-uri.</p>'}
    <iframe class="pdf hidden" id="pdfView"></iframe></div>`;
  $("#doExp").onclick = () => runJob("export");
  $$("[data-view]").forEach((b) => (b.onclick = () => { const f = $("#pdfView"); f.classList.remove("hidden"); f.src = pfile(b.dataset.view) + "?t=" + Date.now(); f.scrollIntoView(); }));
}

/* ------------------------------------------------------------------ limbi */
function editLanguages() {
  const p = S.project;
  modal(`<h2>Limbile documentului</h2><div class="langs">${Object.entries(S.state.languages).map(([c, n]) =>
    `<label class="chk"><input type="checkbox" value="${c}" ${p.languages.includes(c) ? "checked" : ""}> ${esc(n)}</label>`).join("")}</div>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn" data-close>Renunță</button><button class="btn primary" id="saveL">Salvează și tradu</button></div>`);
  $("#saveL").onclick = () => safe(async () => {
    S.project = await api("PATCH", `/api/projects/${p.id}`, { languages: $$("#modalCard input:checked").map((i) => i.value) });
    closeModal(); renderProject(); runJob("translate");
  });
}

/* ------------------------------------------------------------------ Conectare AI */
function modal(html) { $("#modalCard").innerHTML = html; $("#modal").classList.remove("hidden"); $$("[data-close]").forEach((b) => (b.onclick = closeModal)); }
function closeModal() { $("#modal").classList.add("hidden"); }
$("#modal").addEventListener("click", (e) => {
  if (e.target.id !== "modal") return;
  // clic în afara ferestrei: o închidem și ducem clicul la butonul de dedesubt (ex. „+ Document nou”)
  closeModal();
  const under = document.elementFromPoint(e.clientX, e.clientY);
  const target = under && under.closest("button, a, label, input, .drop");
  if (target) target.click();
});

async function openAI(message) {
  modal('<h2>Conectare AI</h2><p class="muted">Se verifică…</p>');
  await refreshAI();
  const s = S.state.settings, st = S.ai, P = S.state.providers;
  const head = (key) => { const x = st[key] || {};
    return `<div class="row"><span class="dot ${x.ready ? "ok" : "bad"}"></span><b>${esc(P[key].label)}</b><span class="spacer"></span><span class="muted">${esc(x.message || "")}</span></div>`; };
  const cli = (key, install, model, hint) => { const x = st[key] || {};
    return `<div class="prov ${x.ready ? "ready" : ""}">${head(key)}
      <div class="row" style="margin-top:8px">${x.installed ? `<button class="btn ${x.ready ? "" : "primary"}" data-login="${key}">${x.ready ? "Reconectează" : "Conectează-te cu contul"}</button>` : ""}
      <button class="btn" data-refresh>Verifică</button>${x.ready ? `<button class="btn" data-test="${key}">Test</button>` : ""}</div>
      ${x.installed ? "" : `<div class="row" style="margin-top:8px"><button class="btn primary" data-install="${key}">⬇ Instalează ${key === "claude_cli" ? "Claude" : "Codex"} (o singură dată)</button></div>
        <div class="hint" style="margin-top:6px">Pasul 1: „Instalează” · Pasul 2: „Verifică” · Pasul 3: „Conectează-te cu contul”.
        Dacă instalarea automată nu merge, în PowerShell rulează:<code class="cmd">${esc(install)}</code></div>`}
      <label class="field" style="margin-top:8px">Model <input type="text" data-set="${model}" value="${esc(s[model] || "")}" placeholder="${hint}"></label></div>`; };
  const key = (k, name, has, model, link) => `<div class="prov ${st[k]?.ready ? "ready" : ""}">${head(k)}
      <div class="grid" style="grid-template-columns:2fr 1fr;margin-top:8px">
      <label class="field">Cheie API <input type="password" data-key="${name}" placeholder="${has ? "salvată — scrie alta ca s-o înlocuiești" : "lipește cheia aici"}"></label>
      <label class="field">Model <input type="text" data-set="${model}" value="${esc(s[model] || "")}"></label></div>
      <div class="row" style="margin-top:6px"><span class="hint">Cheie de la ${link}; se plătește pe consum.</span><span class="spacer"></span>
      ${has ? `<button class="btn small" data-test="${k}">Test</button><button class="btn small danger" data-clear="${name}">Șterge</button>` : ""}</div></div>`;
  const role = (r, label) => `<label class="field">${label}<select data-role="${r}_provider">${Object.keys(P).map((k) =>
    `<option value="${k}" ${s[r + "_provider"] === k ? "selected" : ""}>${esc(P[k].label)}${st[k]?.ready ? " ✓" : ""}</option>`).join("")}</select></label>`;
  const mode = s.ai_mode || "ambele";
  const useClaude = mode !== "codex", useOpenAI = mode !== "claude";
  const modeBtn = (m, title, sub) => `<button class="mode-btn ${mode === m ? "active" : ""}" data-mode="${m}"><b>${title}</b><small>${sub}</small></button>`;
  modal(`<div class="row"><h2 style="margin:0">Conectare AI</h2><span class="spacer"></span><button class="btn ghost" data-close>✕</button></div>
    ${message ? `<div class="notice warn" style="margin-top:10px">${esc(message)}</div>` : ""}
    <h3 style="margin-top:12px">Ce AI folosești?</h3>
    <div class="modes">
      ${modeBtn("claude", "Doar Claude", "abonament Claude Pro/Max")}
      ${modeBtn("codex", "Doar ChatGPT", "abonament ChatGPT Plus/Pro (Codex)")}
      ${modeBtn("ambele", "Ambele", "Claude traduce, ChatGPT verifică")}</div>
    <p class="hint">${mode === "ambele" ? "Cu ambele, verificarea e făcută de alt AI decât cel care scanează. Dacă unul nu e conectat, celălalt face tot."
      : mode === "custom" ? "Alegere manuală pe fiecare pas (vezi „Avansat” mai jos)." : "Tot lucrul (scanare, verificare, traducere) îl face doar AI-ul ales."}</p>
    <h3>Cu abonament</h3><div class="providers" style="margin:8px 0 16px">
      ${useClaude ? cli("claude_cli", "irm https://claude.ai/install.ps1 | iex", "claude_cli_model", "sonnet sau opus") : ""}
      ${useOpenAI ? cli("codex_cli", "npm install -g @openai/codex   (doar dacă instalarea automată nu merge; întâi Node.js de pe nodejs.org)", "codex_cli_model", "gol = implicit") : ""}</div>
    <details><summary class="muted">Cu cheie API în loc de abonament (opțional, plată pe consum)</summary>
      <div class="providers" style="margin:8px 0 16px">
      ${useClaude ? key("claude_api", "claude_api_key", s.has_claude_api_key, "claude_api_model", "console.anthropic.com") : ""}
      ${useOpenAI ? key("openai_api", "openai_api_key", s.has_openai_api_key, "openai_api_model", "platform.openai.com") : ""}</div>
      <p class="hint">La prima folosire a unei chei API aplicația instalează automat pachetele necesare (durează ~1 minut).</p></details>
    <details ${mode === "custom" ? "open" : ""}><summary class="muted">Avansat: alege AI-ul pentru fiecare pas</summary>
      <div class="grid" style="grid-template-columns:1fr 1fr 1fr;margin-top:8px">${role("extract", "Scanează")}${role("verify", "Verifică")}${role("translate", "Traduce")}</div>
      <label class="chk" style="margin-top:8px;display:inline-flex"><input type="checkbox" id="customMode" ${mode === "custom" ? "checked" : ""}> Folosește alegerea de mai sus</label></details>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn" data-close>Închide</button><button class="btn primary" id="saveAI">Salvează</button></div>`);
  $$("[data-mode]").forEach((b) => (b.onclick = () => safe(async () => {
    S.state.settings = await api("POST", "/api/settings", { ai_mode: b.dataset.mode });
    toast(`AI ales: ${S.state.ai_modes?.[b.dataset.mode] || b.dataset.mode}`); openAI();
  })));
  $$("[data-login]").forEach((b) => (b.onclick = () => safe(async () => toast((await api("POST", `/api/ai/${b.dataset.login}/login`)).message))));
  $$("[data-refresh]").forEach((b) => (b.onclick = () => openAI()));
  $$("[data-install]").forEach((b) => (b.onclick = () => safe(async () => toast((await api("POST", `/api/ai/${b.dataset.install}/install`)).message))));
  $$("[data-test]").forEach((b) => (b.onclick = () => safe(async () => {
    b.disabled = true; b.textContent = "Testez…";
    try { toast((await api("POST", `/api/ai/${b.dataset.test}/test`)).message); } finally { b.disabled = false; b.textContent = "Test"; }
  })));
  $$("[data-clear]").forEach((b) => (b.onclick = () => safe(async () => { S.state.settings = await api("POST", "/api/settings", { [`clear_${b.dataset.clear}`]: true }); openAI(); })));
  $("#saveAI").onclick = () => safe(async () => {
    const body = {};
    $$("[data-set]").forEach((i) => (body[i.dataset.set] = i.value));
    $$("[data-key]").forEach((i) => { if (i.value) body[i.dataset.key] = i.value; });
    $$("[data-role]").forEach((i) => (body[i.dataset.role] = i.value));
    if ($("#customMode").checked) body.ai_mode = "custom";
    else if (mode === "custom") body.ai_mode = "ambele";
    S.state.settings = await api("POST", "/api/settings", body);
    toast("Salvat."); openAI();
  });
}

/* ------------------------------------------------------------------ Actualizări și oprire */
async function checkUpdate(show) {
  let u;
  try { u = await api("GET", "/api/update/check"); } catch (e) { if (show) toast(e.message, true); return null; }
  S.update = u;
  const b = $("#updBanner");
  if (u.available) { b.textContent = `⟳ Versiune nouă: ${u.latest} — apasă pentru actualizare`; b.classList.remove("hidden"); }
  else b.classList.add("hidden");
  return u;
}
async function openUpdate() {
  modal('<h2>Actualizări</h2><p class="muted">Caut versiuni noi…</p>');
  const u = await checkUpdate(true);
  if (!u) { closeModal(); return; }
  const notes = (u.notes || []).map((n) => `<li>${esc(n)}</li>`).join("");
  let body;
  if (u.error) body = `<div class="notice warn">${esc(u.error)}</div><p class="hint">Verifică internetul și încearcă din nou.</p>`;
  else if (!u.available) body = `<p>Ai ultima versiune (<b>${esc(u.current)}</b>).</p>`;
  else if (!u.can_apply) body = `<p>Versiune nouă: <b>${esc(u.latest)}</b> (acum: ${esc(u.current)}).</p>${notes ? `<ul class="notes">${notes}</ul>` : ""}
      <p class="hint">Această copie nu este instalată cu instalatorul Windows, deci nu se poate actualiza singură.
      Instrucțiunile de instalare sunt aici: <a href="${esc(u.installer)}" target="_blank">${esc(u.installer)}</a></p>`;
  else body = `<p>Versiune nouă: <b>${esc(u.latest)}</b> (acum: ${esc(u.current)}).</p>${notes ? `<h3>Ce e nou</h3><ul class="notes">${notes}</ul>` : ""}
      <p class="hint">Documentele și setările tale rămân neatinse. Aplicația repornește singură (~10 secunde).</p>
      <div class="row" style="margin-top:12px"><span class="spacer"></span><button class="btn primary" id="doUpd">Actualizează acum</button></div>`;
  modal(`<div class="row"><h2 style="margin:0">Actualizări</h2><span class="spacer"></span><button class="btn ghost" data-close>✕</button></div>
    ${body}<p class="hint" style="margin-top:14px">Versiunile se publică aici: <a href="${esc(u.page || "#")}" target="_blank">${esc(u.page || "")}</a></p>`);
  const btn = $("#doUpd");
  if (btn) btn.onclick = () => safe(async () => {
    btn.disabled = true; btn.textContent = "Descarc…";
    const r = await api("POST", "/api/update/apply");
    modal(`<h2>Se actualizează…</h2><p>${esc(r.message)}</p><p class="muted" id="updWait">Aștept repornirea aplicației…</p>`);
    waitRestart(u.current);
  });
}
function waitRestart(oldVersion) {
  let tries = 0;
  const tick = async () => {
    tries += 1;
    try {
      const st = await (await fetch("/api/state", { cache: "no-store" })).json();
      if (st.version && st.version !== oldVersion) { location.reload(); return; }
    } catch { /* încă repornește */ }
    if (tries > 90) { $("#updWait").textContent = "Durează mai mult decât de obicei. Pornește aplicația din iconița de pe Desktop."; return; }
    setTimeout(tick, 1000);
  };
  setTimeout(tick, 2500);
}
async function quitApp() {
  if (!confirm("Închizi aplicația? Documentele rămân salvate.")) return;
  await safe(async () => {
    const r = await api("POST", "/api/shutdown");
    document.body.innerHTML = `<div style="padding:60px;font:16px system-ui;text-align:center"><h2>Traduceri TED s-a închis</h2>
      <p>${esc(r.message)}</p><p>O pornești din nou cu iconița „Traduceri TED” de pe Desktop.</p></div>`;
  });
}

/* ------------------------------------------------------------------ Setări */
function openSettings() {
  const s = S.state.settings;
  modal(`<div class="row"><h2 style="margin:0">Setări</h2><span class="spacer"></span><button class="btn ghost" data-close>✕</button></div>
    <div class="card" style="margin-top:12px"><h3>Adaugă o limbă</h3>
      <div class="grid" style="grid-template-columns:1fr 2fr auto;align-items:end">
        <label class="field">Cod<input type="text" id="lc" placeholder="ex. ja"></label>
        <label class="field">Nume<input type="text" id="ln" placeholder="ex. Japoneză"></label>
        <button class="btn primary" id="addL">Adaugă</button></div>
      <p class="hint">Acum: ${Object.values(S.state.languages).map(esc).join(", ")}.</p></div>
    <div class="card"><h3>Verificări</h3>
      <label class="chk"><input type="checkbox" id="visChk" ${s.visual_check !== false ? "checked" : ""}>
        Verificare vizuală cu AI a fiecărei pagini traduse (mai sigur, dar durează mai mult)</label></div>
    <div class="card"><h3>Adresa aplicației (port)</h3>
      <label class="field">Port<input type="number" id="portIn" value="${esc(s.port || location.port)}" min="1024" max="49151"></label>
      <p class="hint">Acum: <b>http://127.0.0.1:${esc(location.port)}</b>. Schimbă portul doar dacă încurcă alt program.
      Dacă portul e ocupat, aplicația alege singură altul liber. Noul port se folosește după ce închizi aplicația
      („⏻ Închide aplicația”) și o pornești din nou din iconiță.</p></div>
    <div class="card"><h3>Timp maxim pentru o operație AI</h3>
      <label class="field">Secunde<input type="number" id="tmo" value="${s.timeout_seconds}" min="60" max="3600"></label></div>
    <div class="row"><span class="spacer"></span><button class="btn primary" id="saveS">Salvează</button></div>`);
  $("#addL").onclick = () => safe(async () => {
    S.state.languages = (await api("POST", "/api/languages", { code: $("#lc").value, name: $("#ln").value })).languages;
    toast("Limbă adăugată."); openSettings();
  });
  $("#saveS").onclick = () => safe(async () => {
    const before = String(s.port || location.port), port = String($("#portIn").value || before);
    S.state.settings = await api("POST", "/api/settings", { timeout_seconds: $("#tmo").value, visual_check: $("#visChk").checked, port });
    closeModal();
    toast(port !== before ? "Salvat. Portul nou se folosește după repornirea aplicației." : "Salvat.");
  });
}

boot().catch((e) => toast(e.message, true));
