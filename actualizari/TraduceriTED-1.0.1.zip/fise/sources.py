"""Importul PDF-ului original. Originalul nu se modifică niciodată."""
from __future__ import annotations

import hashlib
from typing import Any

import pymupdf as fitz

from .storage import new_id, now, project_dir

MAX_BYTES = 150 * 1024 * 1024
MAX_PAGES = 200


def import_pdf(project: dict[str, Any], name: str, data: bytes) -> dict[str, Any]:
    if not data or len(data) > MAX_BYTES:
        raise ValueError(f"{name}: fișier gol sau mai mare de 150 MB.")
    if project["sources"]:
        raise ValueError("Proiectul are deja un PDF. Pentru alt document creează un proiect nou.")
    sid = new_id()
    folder = project_dir(project["id"]) / "surse" / sid
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "original.pdf").write_bytes(data)
    try:
        doc = fitz.open(folder / "original.pdf")
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"{name}: PDF-ul nu poate fi deschis ({e}).") from e
    pages = []
    with doc:
        if doc.needs_pass:
            raise ValueError(f"{name}: PDF-ul este protejat cu parolă.")
        if len(doc) > MAX_PAGES:
            raise ValueError(f"{name}: are {len(doc)} pagini; limita este {MAX_PAGES}.")
        for i, page in enumerate(doc):
            img = folder / f"pagina-{i + 1}.png"
            # imagine pentru scanare și pentru comparația vizuală (fără să modificăm originalul)
            dpi = 150 if max(page.rect.width, page.rect.height) < 1000 else 110
            page.get_pixmap(dpi=dpi, alpha=False).save(img)
            pages.append({"n": i + 1, "image": img.relative_to(project_dir(project["id"])).as_posix(),
                          "width": page.rect.width, "height": page.rect.height})
    src = {"id": sid, "name": name, "sha256": hashlib.sha256(data).hexdigest(), "pages": pages,
           "imported_at": now(), "path": f"surse/{sid}/original.pdf"}
    project["sources"].append(src)
    return src
