"""Motorul de traducere „în pagină”: același PDF, aceeași aranjare, altă limbă.

Funcționează la fel pentru fișe tehnice și manuale:
  1. scanare   — se găsește fiecare bloc de text și poziția lui;
  2. verificare — un AI compară textul citit cu imaginea paginii și corectează greșelile de citire;
  3. traducere — (în tasks.py) fiecare limbă direct din textul verificat;
  4. export    — textul vechi se șterge din zona lui și se scrie traducerea în același loc.

Cum se citește textul unei pagini:
  - text selectabil (strat de text): se ia textul și poziția din PDF;
  - text desenat ca contururi (frecvent la PDF-uri din Illustrator/Corel): poziția, mărimea și culoarea
    se iau exact din conturul literelor; textul îl citește AI-ul din imagine;
  - pagină scanată (imagine): AI-ul citește textul și poziția aproximativă.
"""
from __future__ import annotations

import html as _html
import re
import statistics
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

import pymupdf as fitz
from PIL import Image

from . import ai
from .catalog import CATEGORIES
from .storage import (DATA, FONTS_DIR, TEMPLATES_DIR, all_languages, effective_source_language, field, load_settings,
                      new_id, now, project_dir, text_for)

Progress = Callable[[str], None]
TED_CONTACT = "www.tedelectric.eu"
LOGO_RECT = fitz.Rect(60, 8, 262, 98)  # logo-ul TED din modelele Schema


# ====================================================================== geometrie
def _glyph_lines(page: fitz.Page) -> list[dict[str, Any]]:
    """Rândurile de text desenate ca contururi: trasee pline cu multe segmente, de înălțimea unui rând."""
    out = []
    width = page.rect.width
    for d in page.get_drawings():
        r, fill = d["rect"], d.get("fill")
        if fill is None or len(d["items"]) < 12:
            continue
        if not (2 <= r.height <= 60) or r.width > width * 0.95:
            continue
        out.append({"rect": fitz.Rect(r), "color": "#%02x%02x%02x" % tuple(int(c * 255) for c in fill[:3])})
    return out


def _glyph_parts(page: fitz.Page) -> list[fitz.Rect]:
    """Orice bucată de literă desenată (inclusiv virgule, accente, cozi): trasee pline cu curbe,
    mici; nu dreptunghiuri (celule, benzi), care trebuie să rămână."""
    out = []
    for d in page.get_drawings():
        r, items = d["rect"], d["items"]
        if d.get("fill") is None or r.width > page.rect.width * 0.95 or r.height > page.rect.height * 0.5:
            continue
        small_rect = len(items) <= 4 and r.width <= 25 and r.height <= 25  # litere drepte: I, l, -, T
        if any(i[0] == "c" for i in items) or len(items) >= 8 or small_rect:
            out.append(fitz.Rect(r))
    return out


def _boxes(page: fitz.Page) -> list[fitz.Rect]:
    """Dreptunghiurile pline (celule, benzi de titlu) — pentru alinierea textului centrat."""
    out = []
    for d in page.get_drawings():
        r = d["rect"]
        # dreptunghiuri și dreptunghiuri cu colțuri rotunjite (≤ 10 segmente)
        if d.get("fill") is not None and len(d["items"]) <= 10 and r.height >= 8 and r.width >= 2.5 * r.height:
            out.append(fitz.Rect(r))
    return out


def _em_fraction(text: str) -> float:
    """Ce fracțiune din mărimea fontului ocupă înălțimea literelor unui rând (majuscule + coadă)."""
    top = 0.72 if re.search(r"[A-Z0-9bdfhklt]", text) else 0.53
    bottom = 0.22 if re.search(r"[gjpqy,;()\[\]]", text) else 0.0
    return top + bottom


def _assign_glyphs(blocks: list[dict[str, Any]], glyphs: list[dict[str, Any]]) -> None:
    """Fiecare contur de rând aparține unui singur bloc: cel care îl acoperă cel mai mult
    (sau, la egalitate, cel mai apropiat). Apoi fiecare bloc se lipește de conturul lui."""
    owners: dict[int, list[dict[str, Any]]] = {}
    for g in glyphs:
        gr = g["rect"]
        # un singur contur pentru mai multe blocuri (ex. o listă întreagă): nu-l lipim de niciunul
        inside = sum(1 for b in blocks if (fitz.Rect(b["bbox"]) & gr).get_area()
                     >= 0.5 * max(0.01, fitz.Rect(b["bbox"]).get_area()))
        if inside >= 2:
            continue
        c = fitz.Point((gr.x0 + gr.x1) / 2, (gr.y0 + gr.y1) / 2)
        best, best_score = None, 0.0
        for i, b in enumerate(blocks):
            r = fitz.Rect(b["bbox"])
            m = 2.5 if b["origin"] == "pdf" else max(2.0, min(6.0, r.height / max(1, b.get("lines", 1)) * 0.3))
            er = r + (-m, -m, m, m)
            if not er.contains(c):
                continue
            score = (gr & r).get_area() / max(0.01, gr.get_area()) + 0.001 / (1 + abs(c.y - (r.y0 + r.y1) / 2))
            if score > best_score:
                best, best_score = i, score
        if best is not None:
            owners.setdefault(best, []).append(g)
    for i, hits in owners.items():
        _snap(blocks[i], hits, 1e6)


def _snap(block: dict[str, Any], glyphs: list[dict[str, Any]], margin: float) -> bool:
    """Lipește blocul de conturul literelor de sub el: poziție, mărime și culoare exacte."""
    r = fitz.Rect(block["bbox"]) + (-margin, -margin, margin, margin)
    hits = [g for g in glyphs if r.contains(fitz.Point((g["rect"].x0 + g["rect"].x1) / 2,
                                                        (g["rect"].y0 + g["rect"].y1) / 2))]
    if not hits:
        return False
    union = fitz.Rect(hits[0]["rect"])
    for g in hits[1:]:
        union |= g["rect"]
    # rândurile = trasee cu centre verticale diferite
    # rânduri = grupuri de contururi care se suprapun pe verticală (merge și când fiecare literă e
    # desenată separat: literele mici și majusculele aceluiași rând se suprapun)
    rows: list[list[fitz.Rect]] = []
    extents: list[list[float]] = []
    for g in sorted(hits, key=lambda g: (g["rect"].y0 + g["rect"].y1) / 2):
        gr = g["rect"]
        for row, ext in zip(rows, extents):
            overlap = min(ext[1], gr.y1) - max(ext[0], gr.y0)
            if overlap >= 0.4 * min(gr.height, ext[1] - ext[0]):
                row.append(gr)
                ext[0], ext[1] = min(ext[0], gr.y0), max(ext[1], gr.y1)
                break
        else:
            rows.append([gr])
            extents.append([gr.y0, gr.y1])
    row_h = statistics.median(max(x.y1 for x in row) - min(x.y0 for x in row) for row in rows)
    expected = max(1, int(block.get("lines") or 1))
    if len(rows) < expected:  # un singur traseu cuprinde mai multe rânduri (frecvent în CorelDRAW)
        row_h = union.height / expected / 1.15
        rows += [[] for _ in range(expected - len(rows))]
    rows = [row for row in rows if row] or rows
    size = row_h / _em_fraction(block["text"]["src"]) * 0.92  # DejaVu e puțin mai lat decât fonturile din fișe
    block.update({
        "bbox": [round(v, 2) for v in union],
        "size": round(max(4.5, min(60.0, size)), 2),
        "color": Counter(g["color"] for g in hits).most_common(1)[0][0],
        "glyphs": True, "lines": max(len(rows), expected),
    })
    if len(rows) > 1:
        centers = [((min(x.x0 for x in row) + max(x.x1 for x in row)) / 2) for row in rows]
        widths = [max(x.x1 for x in row) - min(x.x0 for x in row) for row in rows]
        mid = (union.x0 + union.x1) / 2
        if max(abs(c - mid) for c in centers) < 2.5 and max(widths) - min(widths) > 6:
            block["align"] = "center"
    return True


def _center_in_box(block: dict[str, Any], boxes: list[fitz.Rect]) -> None:
    """Un rând singur, centrat într-o bandă/celulă colorată (ex. titlul unei secțiuni), rămâne centrat."""
    r = fitz.Rect(block["bbox"])
    for b in boxes:
        if b.contains(r) and b.width > r.width * 1.3 and abs((b.x0 + b.x1) / 2 - (r.x0 + r.x1) / 2) < 3:
            block["align"] = "center"
            return


def _ink_bold(pix: fitz.Pixmap, blocks: list[dict[str, Any]], scale: float) -> None:
    """Text îngroșat = mai multă „cerneală” pe aceeași suprafață decât textul obișnuit de pe pagină."""
    dens = []
    for b in blocks:
        r = fitz.Rect(b["bbox"])
        rgb = tuple(int(b["color"][i:i + 2], 16) for i in (1, 3, 5))
        x0, y0 = int(r.x0 * scale), int(r.y0 * scale)
        x1, y1 = min(pix.width - 1, int(r.x1 * scale)), min(pix.height - 1, int(r.y1 * scale))
        step = max(1, int((x1 - x0) * (y1 - y0) / 4000) or 1)
        total = ink = 0
        for i, (x, y) in enumerate((x, y) for y in range(y0, y1) for x in range(x0, x1)):
            if i % step:
                continue
            total += 1
            p = pix.pixel(x, y)
            if sum(abs(p[k] - rgb[k]) for k in range(3)) < 90:
                ink += 1
        dens.append(ink / total if total else 0)
        b["_ink"] = dens[-1] / max(0.3, _em_fraction(b["text"]["src"]))
    vals = [b["_ink"] for b in blocks if b["_ink"] > 0]
    if len(vals) >= 4:
        med = statistics.median(vals)
        for b in blocks:
            if b["_ink"] > med * 1.3:
                b["bold"] = True
    for b in blocks:
        b.pop("_ink", None)


def _harmonize(blocks: list[dict[str, Any]]) -> None:
    """Mărimi apropiate (±12%) => aceeași mărime, ca textul de corp să arate uniform."""
    sizes = sorted(b["size"] for b in blocks)
    if len(sizes) < 3:
        return
    groups: list[list[float]] = [[sizes[0]]]
    for s in sizes[1:]:
        (groups[-1].append(s) if s <= groups[-1][0] * 1.12 else groups.append([s]))
    for b in blocks:
        for g in groups:
            if g[0] <= b["size"] <= g[-1] and len(g) >= 2:
                b["size"] = round(statistics.median(g), 2)


# ====================================================================== 1. scanare
PAGE_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["language", "manufacturer_names", "brand_regions", "blocks"],
    "properties": {
        "language": {"type": "string"},
        "manufacturer_names": {"type": "array", "items": {"type": "string"}},
        "brand_regions": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["kind", "box"],
            "properties": {"kind": {"type": "string", "enum": ["logo", "contact"]},
                           "box": {"type": "array", "items": {"type": "number"}}}}},
        "blocks": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["text", "box", "line_count", "bold", "color", "align"],
            "properties": {"text": {"type": "string"}, "box": {"type": "array", "items": {"type": "number"}},
                           "line_count": {"type": "integer"}, "bold": {"type": "boolean"},
                           "color": {"type": "string"}, "align": {"type": "string", "enum": ["left", "center", "right"]}}}},
    },
}


def _page_prompt(w: int, h: int, need_text: bool, need_brand: bool) -> str:
    parts = [f"This image is one page of a technical product document (datasheet or user manual), {w}x{h} pixels."]
    if need_text:
        parts.append(
            "blocks: every piece of printed text: titles, paragraphs, EACH list item separately (keep a leading dash, "
            "number or letter like \"- \", \"1.\" in the text; leave out only round bullet dots), EACH table cell separately, labels in technical drawings, footers. Do NOT include text inside "
            "photos, phone/app screenshots, logos or product labels in photos. Copy the text exactly as printed "
            "(letters, case, digits, units, symbols), as one string per block. box = [left, top, right, bottom] in "
            "pixels, tight around the text. line_count = printed lines in the block. color = text color as hex.")
    else:
        parts.append("blocks: return an empty list.")
    if need_brand:
        parts.append(
            "brand_regions: boxes around the MANUFACTURER's logos (kind=logo) and the manufacturer's company name / "
            "address / phone / e-mail / website blocks (kind=contact). Not certification marks, not TED branding. "
            "manufacturer_names: manufacturer company/brand names appearing in the text (not TED).")
    else:
        parts.append("brand_regions and manufacturer_names: empty lists.")
    parts.append("language: ISO 639-1 code of the page text (e.g. en, zh, ro).")
    return "\n".join(parts)


def _detect_language(text: str) -> str:
    if re.search(r"[一-鿿]", text):
        return "zh"
    words = re.findall(r"[^\W\d_]+", text.lower())
    ro = sum(w in _RO_WORDS for w in words) + len(re.findall(r"[ăâîșțşţ]", text.lower())) * 0.5
    en = sum(w in _EN_WORDS for w in words)
    return "ro" if ro > en else "en"


_RO_WORDS = {"si", "și", "este", "sunt", "pentru", "care", "sau", "din", "cu", "la", "de", "in", "în", "pe", "nu",
             "se", "mai", "acest", "aceasta", "daca", "dacă", "trebuie", "poate", "utilizare", "tensiune"}
_EN_WORDS = {"the", "and", "is", "are", "for", "of", "to", "with", "this", "that", "in", "on", "be", "it", "by", "or",
             "not", "as", "from", "can", "must", "should", "you", "your", "if", "when", "which", "will", "voltage"}


def analyze(project: dict[str, Any], progress: Progress) -> None:
    """Pasul 1 — scanarea: blocurile de text ale fiecărei pagini, cu poziție, mărime și culoare."""
    if not project["sources"]:
        raise ai.AIError("Importă întâi PDF-ul.")
    src = project["sources"][0]
    replace_brand = bool(project.get("replace_brand"))
    settings = load_settings()
    doc = fitz.open(project_dir(project["id"]) / src["path"])
    n_pages = len(doc)
    provider = None
    pages_out: list[dict[str, Any]] = []
    names: set[str] = set()

    def work(i: int) -> dict[str, Any]:
        page = doc[i]
        info = src["pages"][i]
        hidden = _hidden_rects(page)
        text_layer = " ".join(s["text"] for b in page.get_text("dict")["blocks"] if b["type"] == 0
                              for l in b["lines"] for s in l["spans"] if not _is_hidden(s["bbox"], hidden, s["text"]))
        has_text = len("".join(text_layer.split())) >= 150
        glyphs = _glyph_lines(page)
        blocks: list[dict[str, Any]] = []
        brand: list[dict[str, Any]] = []
        found_names: list[str] = []
        language = _detect_language(text_layer) if has_text else ""
        if has_text:
            blocks = _pdf_blocks(page)
        if not has_text or replace_brand:
            img_path = project_dir(project["id"]) / info["image"]
            with Image.open(img_path) as im:
                wpx, hpx = im.size
            out = provider.run(_page_prompt(wpx, hpx, not has_text, replace_brand), PAGE_SCHEMA, [img_path])
            sx, sy = page.rect.width / wpx, page.rect.height / hpx

            def pt(b):
                return [b[0] * sx, b[1] * sy, b[2] * sx, b[3] * sy] if len(b) == 4 else None

            if not has_text:
                for b in out.get("blocks", []):
                    box = pt(b.get("box") or [])
                    if b.get("text", "").strip() and box:
                        blk = _block(b["text"], box, _area_size(box, b), b.get("bold", False), b.get("color", ""),
                                     b.get("align", "left"), "ai")
                        blk["lines"] = max(1, int(b.get("line_count") or 1))
                        blocks.append(blk)
            brand = [{"id": new_id(), "kind": r["kind"], "bbox": pt(r["box"]), "replace": True}
                     for r in out.get("brand_regions", []) if pt(r.get("box") or [])]
            found_names = out.get("manufacturer_names", [])
            language = language or out.get("language", "")
        # poziții exacte din conturul literelor, când există
        _assign_glyphs(blocks, glyphs)
        boxes = _boxes(page)
        for b in blocks:
            if b.get("lines", 1) == 1:
                _center_in_box(b, boxes)
        if glyphs and blocks:
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
            _ink_bold(pix, [b for b in blocks if b.get("glyphs")], 2.0)
        _harmonize(blocks)
        mode = "pdf" if has_text else ("contur" if any(b.get("glyphs") for b in blocks) else "imagine")
        return {"n": i + 1, "mode": mode, "blocks": blocks, "brand": brand, "language": language,
                "names": found_names}

    if any(len("".join(" ".join(b["text"]["src"] for b in _pdf_blocks(doc[i])).split())) < 150
           for i in range(n_pages)) or replace_brand:
        provider = ai.for_role("extract", settings)
    done = 0
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(work, i) for i in range(n_pages)]
        for fut in futures:
            pages_out.append(fut.result())
            done += 1
            progress(f"Scanez paginile: {done}/{n_pages}…")
    doc.close()
    for p in pages_out:
        p.pop("language", None)
        names.update(n for n in p.pop("names") if n.strip() and "ted" not in n.lower())
    all_text = " ".join(b["text"]["src"] for p in pages_out for b in p["blocks"])
    if all_text.strip():
        project["detected_language"] = _detect_language(all_text)
    old = project.get("doc") or {}
    project["doc"] = {"pages": pages_out, "manufacturer_names": sorted(names) or old.get("manufacturer_names", []),
                      "scanned_at": now(), "provider": provider.label if provider else "text din PDF"}
    project["scan_check"] = None
    project["log"].append({"at": now(), "what": "Scanare"})


def _area_size(box: list[float], b: dict[str, Any]) -> float:
    """Mărimea fontului pentru text citit din imagine, fără contururi: din suprafață și număr de caractere."""
    w, h = box[2] - box[0], box[3] - box[1]
    n = max(1, len((b.get("text") or "").strip()))
    lines = max(1, int(b.get("line_count") or 1))
    from_box = h / lines / 1.22
    from_area = (w * h / (n * 0.55 * 1.22)) ** 0.5 * 0.88
    return round(max(5.0, min(60.0, min(from_box, from_area))), 2)


def _block(text: str, bbox, size: float, bold: bool, color: str, align: str, origin: str) -> dict[str, Any]:
    return {"id": new_id(), "text": field(text), "bbox": [round(v, 2) for v in bbox], "size": round(size, 2),
            "bold": bool(bold), "color": color if re.fullmatch(r"#[0-9a-fA-F]{6}", color or "") else "#1a1a1a",
            "align": align if align in ("left", "center", "right") else "left", "origin": origin, "skip": False}


class _Hidden(list):
    """Zonele de text ascuns; `.visible` = bucățile de text vizibile (pentru texte identice suprapuse)."""

    def __init__(self):
        super().__init__()
        self.visible: list[fitz.Rect] = []


def _hidden_rects(page: fitz.Page) -> list[fitz.Rect]:
    """Bucățile de text care NU se văd pe pagină (zonele lor exacte).

    Exemple: PDF editat (ex. iLovePDF) unde textul vechi a rămas în fișier, iar peste el s-a desenat din nou
    fundalul și apoi textul nou; strat OCR invizibil peste o pagină scanată. Metoda folosește ordinea în
    care e desenată pagina: un text e ascuns dacă DUPĂ el s-a desenat o imagine sau o formă opacă care
    îl acoperă complet, ori dacă e scris invizibil (fără să fie peste litere desenate)."""
    log = [(t, fitz.Rect(r)) for t, r in page.get_bboxlog()]
    covers = [(i, r) for i, (t, r) in enumerate(log) if t in ("fill-image", "fill-path", "fill-shade")]
    if not covers and not any(t == "ignore-text" for t, _ in log):
        trace = page.get_texttrace()
        if not any(tr["type"] == 3 for tr in trace):
            return []
    else:
        trace = page.get_texttrace()
    transparent = {d["seqno"] for d in page.get_drawings() if (d.get("fill_opacity") or 1) < 0.95}
    smask_rects = [fitz.Rect(i["bbox"]) for i in page.get_image_info(xrefs=True)
                   if i.get("xref") in {x[0] for x in page.get_images(full=True) if x[1]}]

    def opaque(idx: int, r: fitz.Rect) -> bool:
        if idx in transparent:
            return False
        if log[idx][0] == "fill-image":
            return not any(abs(r.x0 - m.x0) < 1 and abs(r.y0 - m.y0) < 1 and abs(r.x1 - m.x1) < 1
                           and abs(r.y1 - m.y1) < 1 for m in smask_rects)
        return True

    glyphs = None
    out = _Hidden()
    for tr in trace:
        r = fitz.Rect(tr["bbox"])
        if r.is_empty:
            continue
        hidden = False
        if tr["type"] == 3:  # text invizibil: ascuns, cu excepția stratului de text de peste litere desenate
            if glyphs is None:
                glyphs = _glyph_parts(page)
            hidden = sum((g & r).get_area() for g in glyphs) < 0.25 * max(0.01, r.get_area())
        else:
            k = tr["seqno"]
            hidden = any(i > k and (r & c).get_area() >= 0.9 * r.get_area() and opaque(i, c) for i, c in covers)
        r.hidden_text = "".join(chr(c[0]) for c in tr["chars"]).strip()  # type: ignore[attr-defined]
        (out if hidden else out.visible).append(r)
    return out


def _is_hidden(bbox, hidden: list[fitz.Rect], text: str | None = None) -> bool:
    """Bucata de text (zona + textul ei) este una dintre cele ascunse? Comparăm și textul, ca un text nou
    scris exact peste unul vechi ascuns (ex. „415 W” peste „450 W”) să nu fie luat drept ascuns."""
    r = fitz.Rect(bbox)
    t = " ".join((text or "").split())
    if text is not None:
        # același text există și într-o variantă vizibilă în același loc (ex. eticheta veche ascunsă și
        # eticheta nouă identică scrisă deasupra): îl considerăm vizibil
        for v in getattr(hidden, "visible", []):
            vt = " ".join(getattr(v, "hidden_text", "").split())
            if (r & v).get_area() >= 0.4 * max(0.01, min(r.get_area(), v.get_area())) and vt and (t in vt or vt in t):
                return False
    for h in hidden:
        inter = (r & h).get_area()
        if inter < 0.4 * max(0.01, min(r.get_area(), h.get_area())):
            continue
        ht = " ".join(getattr(h, "hidden_text", "").split())
        if text is None or not ht or not t or t in ht or ht in t:
            return True
    return False


_SUP = str.maketrans("0123456789+-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻")


def _line_text(line: dict) -> str:
    """Textul unui rând; cifrele scrise mai mic și mai sus (indici superiori) devin ², ³ etc."""
    spans = line["spans"]
    big = max((s["size"] for s in spans if s["text"].strip()), default=0)
    base = max((s["bbox"][3] for s in spans if s["text"].strip() and s["size"] >= 0.9 * big), default=0)
    out = []
    for s in spans:
        t = s["text"]
        if (t.strip() and s["size"] < 0.8 * big and s["bbox"][3] < base - 0.15 * big
                and all(c in "0123456789+-" for c in t.strip())):
            t = t.strip().translate(_SUP)
        out.append(t)
    return "".join(out)


def _union_spans(spans: list[dict]) -> fitz.Rect:
    r = fitz.Rect(spans[0]["bbox"])
    for s in spans[1:]:
        r |= fitz.Rect(s["bbox"])
    return r


def _starts_item(text: str) -> bool:
    """Rândul începe un element nou de listă: bulină, liniuță, simbol (Wingdings) sau „2.”, „3)”."""
    t = text.lstrip()
    return bool(t) and (t[0] in "•·▪●-–" or 0xE000 <= ord(t[0]) <= 0xF8FF or re.match(r"\d+[.)](?!\d)\s*\S", t) is not None)


def _merge_continuations(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Unește rândul următor cu cel de deasupra când e continuarea aceleiași propoziții (aceeași coloană,
    aceeași mărime și culoare, imediat dedesubt, începe cu literă mică sau cifră) — ca traducerea să fie a
    propoziției întregi, nu a bucăților de rând. Celulele de tabel (rânduri scurte) nu se unesc."""
    out: list[dict[str, Any]] = []
    for b in sorted(blocks, key=lambda x: (x["bbox"][1], x["bbox"][0])):
        merged = False
        first = b["text"]["src"].lstrip()[:1]
        new_item = (not first or first.isupper() or first in "•·▪●-–" or 0xE000 <= ord(first) <= 0xF8FF
                    or re.match(r"\s*\d+[.)](?!\d)\s*\S", b["text"]["src"]) is not None)  # „2. …”, buline-simbol
        if b["origin"] == "pdf" and not b.get("rotate") and not new_item:
            br = fitz.Rect(b["bbox"])
            for prev in reversed(out[-8:]):
                pr = fitz.Rect(prev["bbox"])
                if prev["origin"] != "pdf" or prev.get("rotate") or abs(pr.x0 - br.x0) >= 3:
                    continue
                same_style = abs(prev["size"] - b["size"]) < 0.6 and prev["color"] == b["color"]
                long_line = pr.width >= 140 and (first.isalpha() or pr.width >= 200)
                if (same_style and long_line and -0.4 * b["size"] <= br.y0 - pr.y1 < 0.7 * b["size"] + 2
                        and not prev["text"]["src"].rstrip().endswith(":")):
                    prev["text"]["src"] = prev["text"]["src"].rstrip() + " " + b["text"]["src"].lstrip()
                    prev["bbox"] = [round(v, 2) for v in (pr | br)]
                    prev["lines"] = prev.get("lines", 1) + b.get("lines", 1)
                    merged = True
                break
        if not merged:
            out.append(b)
    return out


def _pdf_blocks(page: fitz.Page) -> list[dict[str, Any]]:
    """Blocurile din stratul de text. Un paragraf (rânduri pline, aliniate) rămâne un bloc;
    rândurile de tabel și elementele de listă devin blocuri separate."""
    out = []
    hidden = _hidden_rects(page)
    marks = [d["rect"] for d in page.get_drawings()
             if d.get("fill") is not None and 2 < d["rect"].width < 13 and 2 < d["rect"].height < 13
             and abs(d["rect"].width - d["rect"].height) < 3]

    def bulleted(line) -> bool:  # un punct/bulină desenat imediat în stânga rândului
        x0, y0, _, y1 = line["bbox"]
        return any(m.x1 <= x0 + 1 and x0 - m.x1 < 14 and m.y1 > y0 and m.y0 < y1 for m in marks) \
            or _starts_item("".join(s["text"] for s in line["spans"]))

    for b in page.get_text("dict")["blocks"]:
        if b.get("type") != 0:
            continue
        # un „rând” din stratul de text poate conține bucăți aflate în locuri diferite (ex. o valoare
        # din tabel și titlul secțiunii de dedesubt): îl împărțim unde bucățile sunt departe una de alta
        lines = []
        for l in b["lines"]:
            seg: list[dict] = []
            for sp in l["spans"]:
                if hidden and sp["text"].strip() and _is_hidden(sp["bbox"], hidden, sp["text"]):
                    continue  # text ascuns sub o imagine/formă: nu se vede, nu se traduce
                if not sp["text"].strip():  # spațiile rămân în text, dar nu decid împărțirea
                    if seg:
                        seg.append(sp)
                    continue
                real = [x for x in seg if x["text"].strip()]
                if real:
                    prev = fitz.Rect(real[-1]["bbox"])
                    cur = fitz.Rect(sp["bbox"])
                    far = cur.x0 - prev.x1 > 2.0 * sp["size"] or abs(cur.y0 - prev.y0) > 0.6 * sp["size"]
                    if far:
                        lines.append({"spans": seg, "dir": l.get("dir"),
                                      "bbox": tuple(_union_spans([x for x in seg if x["text"].strip()]))})
                        seg = []
                seg.append(sp)
            if [x for x in seg if x["text"].strip()]:
                lines.append({"spans": seg, "dir": l.get("dir"),
                              "bbox": tuple(_union_spans([x for x in seg if x["text"].strip()]))})
        if not lines:
            continue
        widths = [l["bbox"][2] - l["bbox"][0] for l in lines]
        maxw = max(widths)
        body = widths[:-1] or widths
        same_x = max(l["bbox"][0] for l in lines) - min(l["bbox"][0] for l in lines) < 4
        line_gaps = [lines[k + 1]["bbox"][1] - lines[k]["bbox"][3] for k in range(len(lines) - 1)]
        size0 = lines[0]["spans"][0]["size"]
        paragraph = (len(lines) >= 2 and same_x and sum(w >= 0.85 * maxw for w in body) >= 0.6 * len(body)
                     and maxw >= 90 and max(line_gaps or [0]) < 0.7 * size0)  # celulele de tabel sunt înguste
        centers = [(l["bbox"][0] + l["bbox"][2]) / 2 for l in lines]
        sizes = [round(l["spans"][0]["size"]) for l in lines]
        gaps = [lines[k + 1]["bbox"][1] - lines[k]["bbox"][3] for k in range(len(lines) - 1)]
        centered_title = (len(lines) >= 2 and max(centers) - min(centers) < 5 and len(set(sizes)) == 1
                          and sizes[0] >= 14 and max(gaps or [0]) < 0.5 * sizes[0]
                          and not same_x)  # ex. „Technical / Data sheet” pe două rânduri centrate
        paragraph = paragraph or centered_title
        if paragraph:  # un paragraf cu buline = mai multe elemente de listă
            groups: list[list[dict]] = []
            for l in lines:
                if not groups or bulleted(l):
                    groups.append([l])
                else:
                    groups[-1].append(l)
        else:
            groups = [[l] for l in lines]
        for group in groups:
            spans = [s for l in group for s in l["spans"] if s["text"].strip()]
            text = " ".join(_line_text(l).strip() for l in group)
            bbox = fitz.Rect(group[0]["bbox"])
            for l in group[1:]:
                bbox |= fitz.Rect(l["bbox"])
            first = spans[0]
            bold = bool(first["flags"] & 16) or "bold" in first["font"].lower()
            blk = _block(text, bbox, statistics.median(s["size"] for s in spans) * 0.94, bold,
                         "#%06x" % first["color"], "left", "pdf")
            blk["lines"] = len(group)
            dx, dy = (group[0].get("dir") or (1, 0))
            if abs(dx) < 0.3:  # text vertical (ex. cote pe desene, axe de grafice)
                blk["rotate"] = 90 if dy < 0 else 270
            if centered_title:
                blk["align"] = "center"
            out.append(blk)
    out = _merge_continuations(out)
    # Două texte în același loc (ex. titlul vechi „450W…” sub cel nou „415W…”): se vede doar cel desenat
    # ultimul, deci îl păstrăm doar pe el.
    keep = []
    for i, b in enumerate(out):
        r = fitz.Rect(b["bbox"])
        covered = False
        for later in out[i + 1:]:
            o = fitz.Rect(later["bbox"])
            inter = (r & o).get_area()
            similar = min(r.get_area(), o.get_area()) >= 0.5 * max(r.get_area(), o.get_area())  # nu indici (m²)
            if similar and inter >= 0.6 * max(0.01, min(r.get_area(), o.get_area())):  # inclusiv dubluri identice
                covered = True
                break
        if not covered:
            keep.append(b)
    return keep


# ====================================================================== 2. verificare cu scanarea
SCAN_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["corrections", "missing", "bold_ids", "absent_ids"],
    "properties": {
        "corrections": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["id", "printed_text", "problem"],
            "properties": {"id": {"type": "string"}, "printed_text": {"type": "string"}, "problem": {"type": "string"}}}},
        "missing": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["text", "box"],
            "properties": {"text": {"type": "string"}, "box": {"type": "array", "items": {"type": "number"}}}}},
        "bold_ids": {"type": "array", "items": {"type": "string"}},
        "absent_ids": {"type": "array", "items": {"type": "string"}},
    },
}


def verify_scan(project: dict[str, Any], progress: Progress) -> dict[str, Any]:
    """Pasul 2 — al doilea AI compară textul citit cu imaginea paginii și corectează greșelile de citire."""
    import json
    docinfo = project.get("doc")
    if not docinfo:
        raise ai.AIError("Documentul nu a fost scanat.")
    provider = ai.for_role("verify", load_settings())
    src = project["sources"][0]
    pdf = fitz.open(project_dir(project["id"]) / src["path"])
    glyph_cache = {p["n"]: _glyph_lines(pdf[p["n"] - 1]) for p in docinfo["pages"]}
    sizes = {p["n"]: (pdf[p["n"] - 1].rect.width, pdf[p["n"] - 1].rect.height) for p in docinfo["pages"]}
    pdf.close()

    def work(page: dict[str, Any]) -> dict[str, Any]:
        img = project_dir(project["id"]) / src["pages"][page["n"] - 1]["image"]
        with Image.open(img) as im:
            wpx, hpx = im.size
        items = [{"id": b["id"], "text": b["text"]["src"]} for b in page["blocks"] if not b.get("skip")]
        prompt = (f"You check text recognition. The image ({wpx}x{hpx} px) is a page of a technical document. "
                  "Below are the text blocks read from it. For every block whose text is NOT exactly what is printed "
                  "(wrong letters, upper/lower case, digits, decimals, units, symbols, missing or extra words), give "
                  "the exact printed text and a short reason in Romanian. Do not rephrase correct text. "
                  "missing: printed text that is in none of the blocks (box in pixels [left, top, right, bottom]); "
                  "ignore logos, photos and app screenshots. bold_ids: ids of blocks printed in bold. "
                  "absent_ids: ids of blocks whose text is NOT printed on the page image at all (old hidden text "
                  "left in the file); do not list blocks that are printed, even if slightly misread.\n\nBLOCKS:\n"
                  + json.dumps(items, ensure_ascii=False))
        return provider.run(prompt, SCAN_SCHEMA, [img]) | {"_w": wpx, "_h": hpx}

    fixed = added = removed = 0
    pages = docinfo["pages"]
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(work, pages))
    for page, out in zip(pages, results):
        by_id = {b["id"]: b for b in page["blocks"]}
        for c in out.get("corrections", []):
            b = by_id.get(c.get("id"))
            new = (c.get("printed_text") or "").strip()
            if b and new and new != b["text"]["src"]:
                b["scan_fix"] = {"before": b["text"]["src"], "problem": c.get("problem", ""), "by": provider.label}
                b["text"]["src"] = new
                fixed += 1
        absent = set(out.get("absent_ids", []))
        for b in page["blocks"]:
            if b["id"] in absent and b["origin"] == "pdf":
                # text vechi ascuns: nu se traduce, nu se scrie, dar se șterge din fișier la export
                b["skip"] = True
                b["absent"] = True
                removed += 1
        bold = set(out.get("bold_ids", []))
        if bold:
            for b in page["blocks"]:
                b["bold"] = b["id"] in bold
        pw, ph = sizes[page["n"]]
        sx, sy = pw / out["_w"], ph / out["_h"]
        for m in out.get("missing", []):
            box = m.get("box") or []
            if len(box) == 4 and m.get("text", "").strip():
                pt = [box[0] * sx, box[1] * sy, box[2] * sx, box[3] * sy]
                nr = fitz.Rect(pt)
                dup = any((nr & fitz.Rect(b["bbox"])).get_area() >= 0.4 * max(0.01, min(nr.get_area(), fitz.Rect(b["bbox"]).get_area()))
                          or " ".join(m["text"].split()).lower() in " ".join(b["text"]["src"].split()).lower()
                          for b in page["blocks"])
                if dup:
                    continue  # textul e deja citit (eventual sub altă formă): nu-l scriem de două ori
                blk = _block(m["text"], pt, _area_size(pt, m), False, "", "left", "ai")
                _snap(blk, glyph_cache[page["n"]], max(3.0, (pt[3] - pt[1]) * 0.35))
                blk["scan_added"] = True
                page["blocks"].append(blk)
                added += 1
        progress(f"Verific scanarea: pagina {page['n']}/{len(pages)}…")
    result = {"provider": provider.label, "at": now(), "corrected": fixed, "added": added, "absent": removed}
    project["scan_check"] = result
    project["log"].append({"at": now(), "what": f"Verificare scanare cu {provider.label}: {fixed} corecturi, {added} adăugate"})
    return result


# ====================================================================== 4. export
def _ted_logo(category: str) -> Path:
    out = DATA / "cache" / f"logo-{category}.png"
    if out.exists():
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    with fitz.open(TEMPLATES_DIR / CATEGORIES[category]["schema"]) as d:
        pix = d[0].get_pixmap(clip=LOGO_RECT, dpi=500, alpha=False)
    im = Image.frombytes("RGB", (pix.width, pix.height), pix.samples).convert("RGBA")
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, _ = px[x, y]
            if min(r, g, b) > 205 and max(r, g, b) - min(r, g, b) < 40:
                px[x, y] = (r, g, b, 0)
    if im.getbbox():
        im = im.crop(im.getbbox())
    im.save(out)
    return out


def _bg_color(pix: fitz.Pixmap, rect: fitz.Rect, scale: float) -> tuple[float, float, float]:
    x0, y0 = max(0, int(rect.x0 * scale) - 3), max(0, int(rect.y0 * scale) - 3)
    x1, y1 = min(pix.width - 1, int(rect.x1 * scale) + 3), min(pix.height - 1, int(rect.y1 * scale) + 3)
    samples = []
    for x in range(x0, x1 + 1, max(1, (x1 - x0) // 20)):
        samples += [pix.pixel(x, y0), pix.pixel(x, y1)]
    for y in range(y0, y1 + 1, max(1, (y1 - y0) // 10)):
        samples += [pix.pixel(x0, y), pix.pixel(x1, y)]
    if not samples:
        return (1, 1, 1)
    return tuple(statistics.median(s[i] for s in samples) / 255 for i in range(3))  # type: ignore[return-value]


def _rgb(color: str) -> str:
    c = (color or "#1a1a1a").lstrip("#")
    try:
        return "rgb(%d,%d,%d)" % tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return "rgb(26,26,26)"


def export_document(project: dict[str, Any], lang: str, output: Path, pages: list[int] | None = None) -> dict[str, Any]:
    docinfo = project.get("doc")
    if not docinfo:
        raise ValueError("Documentul nu a fost încă scanat. Apasă „Scanează și tradu”.")
    src_lang = effective_source_language(project)
    doc = fitz.open(project_dir(project["id"]) / project["sources"][0]["path"])
    archive = fitz.Archive(str(FONTS_DIR))
    css = ("@font-face {font-family: fise; src: url(DejaVuSans.ttf);} "
           "@font-face {font-family: fise; src: url(DejaVuSans-Bold.ttf); font-weight: bold;} "
           "* {font-family: fise; margin: 0; padding: 0;}")
    replace_brand = bool(project.get("replace_brand"))
    names = docinfo.get("manufacturer_names", []) if replace_brand else []
    missing, overflow = 0, []
    for pinfo in docinfo["pages"]:
        if pages and pinfo["n"] not in pages:
            continue
        page = doc[pinfo["n"] - 1]
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        blocks, texts = [], []
        for b in pinfo["blocks"]:
            if b.get("skip") or not b["text"]["src"].strip():
                continue
            text, state = text_for(b["text"], lang, src_lang)
            missing += state == "lipsa"
            for n in names:
                if len(n) >= 3:
                    text = re.sub(re.escape(n), "TED", text, flags=re.I)
            if " ".join(text.split()) == " ".join(b["text"]["src"].split()):
                # același text ca cel tipărit în original (ex. „12.8V”, „1100±1”): pagina rămâne exact cum este
                continue
            blocks.append(b)
            texts.append(text)
        kept_ids = {b["id"] for b in blocks}
        for b in pinfo["blocks"]:
            if b["id"] in kept_ids or b.get("skip") or not b["text"]["src"].strip() or b["origin"] != "pdf":
                continue
            br = fitz.Rect(b["bbox"])
            if any((br & fitz.Rect(t["bbox"]) + (-1, -1, 1, 1)).get_area() > 0 for t in blocks if t["origin"] == "pdf"):
                blocks.append(b)  # ex. „A-A” lipit de „Profile Sectional Drawing”
                texts.append(b["text"]["src"])
        rects = [fitz.Rect(b["bbox"]) for b in blocks]
        # toate textele paginii (și cele neschimbate): traducerea nu are voie să se întindă peste ele
        all_blocks = [b for b in pinfo["blocks"] if not b.get("skip") and b["text"]["src"].strip()]
        all_rects = [fitz.Rect(b["bbox"]) for b in all_blocks]
        boxes = _boxes(page)
        rules = _vertical_rules(page)
        bgs = [_bg_color(pix, r, 2.0) for r in rects]
        brand = [r for r in pinfo.get("brand", []) if replace_brand and r.get("replace", True)]
        brand_bgs = [_bg_color(pix, fitz.Rect(r["bbox"]), 2.0) for r in brand]
        # textul ascuns (ex. valorile vechi ale unui produs, acoperite de o imagine) nu trebuie să rămână
        # în fișierul tradus: îl ștergem, fără să atingem imaginile și desenele
        hidden = _hidden_rects(page)  # păstrăm lista (are și `.visible`), doar îi adăugăm zonele absente
        hidden.extend(fitz.Rect(b["bbox"]) for b in pinfo["blocks"] if b.get("absent"))
        visible = [fitz.Rect(s["bbox"]) for b in page.get_text("dict")["blocks"] if b["type"] == 0
                   for l in b["lines"] for s in l["spans"]
                   if s["text"].strip() and not _is_hidden(s["bbox"], hidden, s["text"])]
        for h in hidden:
            if not any((h & v).get_area() > 0.2 * max(0.01, v.get_area()) for v in visible):
                page.add_redact_annot(h, fill=False)
        if hidden:
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_NONE,
                                  text=fitz.PDF_REDACT_TEXT_REMOVE)
        # ștergem textul vechi: textul selectabil + conturul literelor acoperit complet de zonă
        for r, b in zip(rects, blocks):
            if b.get("glyphs"):
                pad = 1.0
            elif b["origin"] == "pdf":
                pad = -0.6  # text selectabil: zona puțin mai mică, ca să nu atingă textele vecine
            else:
                pad = 3.0
            page.add_redact_annot(r + (-pad, -pad, pad, pad), fill=False)
        if blocks:
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE,
                                  graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED,
                                  text=fitz.PDF_REDACT_TEXT_REMOVE)
            # Ce a rămas din conturul literelor (cozi de g/y, virgule, accente — uneori un singur traseu
            # cuprinde mai multe rânduri): ștergem traseele aflate în mare parte în zonele de text.
            for _ in range(2):
                leftovers = [gr for gr in _glyph_parts(page)
                             if sum((gr & r).get_area() for r in rects) >= 0.35 * max(0.01, gr.get_area())
                             # nu benzi/casete care conțin textul (ex. bandă de titlu cu colțuri rotunjite)
                             and not any(gr.contains(r) and gr.width > r.width + 8 and gr.height > r.height + 3
                                         for r in rects)]
                if not leftovers:
                    break
                for gr in leftovers:
                    page.add_redact_annot(gr + (-0.6, -0.6, 0.6, 0.6), fill=False)
                page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE,
                                      graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED,
                                      text=fitz.PDF_REDACT_TEXT_NONE)
        # pagini scanate: textul e în imagine -> îl acoperim cu culoarea fundalului
        if page.get_images():
            for r, b, bg in zip(rects, blocks, bgs):
                if b["origin"] == "ai" and not b.get("glyphs"):
                    page.draw_rect(r + (-2, -2, 2, 2), color=None, fill=bg)
        for r, bg in zip(brand, brand_bgs):
            rect = fitz.Rect(r["bbox"]) + (-2, -2, 2, 2)
            page.add_redact_annot(rect, fill=bg)
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS, graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED)
            if r["kind"] == "logo":
                page.insert_image(rect, filename=str(_ted_logo(project.get("logo_category") or "lifepo4_batteries")),
                                  keep_proportion=True)
            else:
                _write(page, rect, TED_CONTACT, max(6, min(12, rect.height * 0.5)), False, "#0e1f3d", "center", css, archive)
        area = page.rect.get_area()
        pictures = [fitz.Rect(i["bbox"]) for i in page.get_image_info() if fitz.Rect(i["bbox"]).get_area() < 0.6 * area]
        plan = []
        art = _line_art(page)
        tight_all = [_tight(x, b["size"], b.get("lines") or 1, b.get("rotate"))
                     for x, b in zip(all_rects, all_blocks)]
        for i, (r, b, text) in enumerate(zip(rects, blocks, texts)):
            lines = max(1, b.get("lines") or 1)
            r = _tight(r, b["size"], lines, b.get("rotate"))
            others = [x for x in tight_all if not (abs(x.x0 - r.x0) < 0.1 and abs(x.y0 - r.y0) < 0.1
                                                   or abs(x.x0 - b["bbox"][0]) < 0.1 and abs(x.y1 - b["bbox"][3]) < 0.1)]
            others += pictures
            # distanța dintre rânduri ca în original
            lh = min(1.45, max(1.15 if b["size"] >= 18 else 1.05, r.height / lines / b["size"])) if lines > 1 else 1.22
            align = b["align"]
            r_orig = fitz.Rect(r)
            if not b.get("rotate"):
                r = _room_right(r, others, page.rect, align, boxes, rules)
            if b.get("glyphs"):
                # conturul cuprinde doar literele; textul HTML are nevoie și de spațiul de deasupra majusculelor
                top = r.y0 - 0.24 * b["size"]
                r = fitz.Rect(r.x0, top, r.x1, max(r.y1 + 0.1 * b["size"], top + lines * b["size"] * lh))
            inside_box = any(bx.contains(fitz.Rect(b["bbox"])) for bx in boxes)
            size = b["size"] * (1.18 if b["origin"] == "ai" else 1.0)
            one_line = lines == 1 and not b.get("rotate")
            if one_line and align == "left" and not inside_box and b["size"] < 7:
                # etichetă dintr-un desen: dacă spre dreapta dă de liniile desenului, crește spre stânga
                r, align = _label_room(text, r_orig, r, size, b["bold"], art, others)
            if not inside_box and not b.get("rotate"):  # poate coborî în spațiul liber (nu în celule de tabel)
                r = fitz.Rect(r.x0, r.y0, r.x1, r.y1 + min(_room_below(r, others, page.rect), b["size"] * 2.6))
            # text citit din imagine: mărimea e estimată, așa că pornim puțin mai mare și lăsăm
            # textul să se micșoreze până încape exact în zona originală
            fit = size if b.get("rotate") else _fit_size(text, r, size, b["bold"], lh, one_line)
            plan.append({"r": r, "r0": r_orig, "b": b, "text": text, "lh": lh, "size": size, "fit": fit,
                         "one_line": one_line, "align": align, "lines": lines, "inside_box": inside_box})
        # aceeași coloană + aceeași mărime în original => aceeași mărime și în traducere
        groups: dict[tuple, list[dict]] = {}
        for it in plan:
            if not it["b"].get("rotate"):
                key = (round(it["b"]["bbox"][0] / 4), round(it["b"]["size"] * 2), it["b"]["color"], it["b"]["bold"])
                groups.setdefault(key, []).append(it)
        for items in groups.values():
            if len(items) >= 2:
                fits = sorted(it["fit"] for it in items)
                common = max(fits[0], 0.85 * statistics.median(fits))
                for it in items:
                    it["fit"] = min(it["fit"], common)
            _flow(items)
        _move_bullets(page, plan, all_blocks)
        for it in plan:
            if not _write(page, it["r"], it["text"], it["fit"], it["b"]["bold"], it["b"]["color"], it["align"],
                          css, archive, it["lh"], it["b"].get("rotate", 0), it["one_line"]):
                overflow.append(pinfo["n"])
    if pages:
        doc.select([p - 1 for p in pages])
    doc.set_metadata({**(doc.metadata or {}), "producer": "Traduceri TED",
                      "title": f"{project['name']} – {all_languages().get(lang, lang)}"})
    output.parent.mkdir(parents=True, exist_ok=True)
    # fiecare bloc încorporează fontul: unim copiile identice și păstrăm doar literele folosite
    merged = fitz.open("pdf", doc.tobytes(garbage=4, deflate=True))
    doc.close()
    try:
        merged.subset_fonts()
    except Exception:  # noqa: BLE001
        pass
    merged.save(output, garbage=4, deflate=True)
    n = len(merged)
    merged.close()
    warnings = []
    if missing:
        warnings.append(f"{missing} texte nu sunt traduse în {all_languages().get(lang, lang)} și au rămas în original.")
    if overflow:
        warnings.append("Traducerea e mai lungă decât spațiul original (font micșorat) pe paginile: "
                        + ", ".join(str(p) for p in sorted(set(overflow))))
    approx = [p["n"] for p in docinfo["pages"] if p["mode"] == "imagine"]
    if approx:
        warnings.append(f"Pagini scanate (poziții aproximative): {', '.join(map(str, approx))}. Verifică previzualizarea.")
    if not project.get("scan_check"):
        warnings.append("Scanarea nu a fost verificată de al doilea AI.")
    return {"pages": n, "warnings": warnings}


def _vertical_rules(page: fitz.Page) -> list[fitz.Rect]:
    """Liniile verticale de tabel (marginile celulelor)."""
    out = []
    for d in page.get_drawings():
        for it in d["items"]:
            if it[0] == "l":
                a, b = it[1], it[2]
                if abs(a.x - b.x) < 1.5 and abs(a.y - b.y) > 6:
                    out.append(fitz.Rect(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x) + 0.1, max(a.y, b.y)))
            elif it[0] == "re":
                rr = it[1]
                if rr.width < 1.5 and rr.height > 6:
                    out.append(fitz.Rect(rr))
        if not d["items"] and d["rect"].width < 1.5 and d["rect"].height > 6:
            out.append(fitz.Rect(d["rect"]))
    return out


def _room_right(r: fitz.Rect, others: list[fitz.Rect], page_rect: fitz.Rect, align: str,
                boxes: list[fitz.Rect] | None = None, rules: list[fitz.Rect] | None = None) -> fitz.Rect:
    """Lărgește zona spre dreapta până la următorul element de pe aceleași rânduri, marginea celulei
    (dreptunghi colorat sau linie verticală de tabel) în care se află textul, sau marginea paginii."""
    limit = page_rect.width - max(14.0, min(r.x0, 40.0))
    for v in rules or []:
        if v.x0 >= r.x1 - 2 and v.y0 <= r.y0 + 2 and v.y1 >= r.y1 - 2:
            limit = min(limit, v.x0 - 3)
    for b in boxes or []:
        if b.contains(r):
            limit = min(limit, b.x1 - 3)
    for o in others:
        if o.y1 > r.y0 + 1 and o.y0 < r.y1 - 1 and o.x0 >= r.x1 - 1:
            limit = min(limit, o.x0 - 8)
    if align == "center":  # lărgim simetric, ca textul să rămână centrat în același loc
        left = max([v.x1 + 3 for v in rules or [] if v.x1 <= r.x0 + 2 and v.y0 <= r.y0 + 2 and v.y1 >= r.y1 - 2],
                   default=page_rect.width - limit)
        grow = max(0.0, min(limit - r.x1, r.x0 - left))
        for b in boxes or []:
            if b.contains(r):
                grow = max(0.0, min(grow, r.x0 - b.x0 - 3, b.x1 - 3 - r.x1))
        return fitz.Rect(r.x0 - grow, r.y0, r.x1 + grow, r.y1)
    if align != "left":
        return r
    return fitz.Rect(r.x0, r.y0, max(r.x1, limit), r.y1)


def _room_below(r: fitz.Rect, others: list[fitz.Rect], page_rect: fitz.Rect) -> float:
    """Câte puncte libere sunt sub text (până la următorul element care se suprapune pe orizontală)."""
    limit = page_rect.height - 30
    for o in others:
        # orice element care începe sub jumătatea blocului (rândurile pot fi ușor suprapuse în PDF)
        if o.y0 >= r.y0 + 0.5 * r.height and o.x1 > r.x0 and o.x0 < r.x1:
            limit = min(limit, o.y0 - 1)
    return max(0.0, limit - r.y1)


def _tight(r: fitz.Rect, size: float, lines: int, rotate) -> fitz.Rect:
    """Unele fonturi au rânduri foarte înalte (ex. „Label” de 4 pt într-o zonă de 12 pt). Pentru un singur
    rând păstrăm doar banda din jurul liniei de mijloc, unde sunt de fapt literele."""
    r = fitz.Rect(r)
    if lines == 1 and not rotate and r.height > 1.7 * size:
        c = (r.y0 + r.y1) / 2
        return fitz.Rect(r.x0, c - 0.62 * size, r.x1, c + 0.62 * size)
    return r


def _line_art(page: fitz.Page) -> list[fitz.Rect]:
    """Liniile subțiri ale desenelor tehnice (cote, săgeți, contururi), ca zone mici."""
    out = []
    for d in page.get_drawings():
        if d.get("color") is None or d.get("fill") is not None and d.get("type") != "s":
            continue
        for it in d["items"]:
            if it[0] == "l":
                a, b = it[1], it[2]
                out.append(fitz.Rect(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x), max(a.y, b.y)) + (-0.3, -0.3, 0.3, 0.3))
            elif it[0] == "c":
                out.append(fitz.Rect(it[1], it[1]) | it[2] | it[3] | it[4])
            elif it[0] == "re":
                q = it[1]
                out += [fitz.Rect(q.x0, q.y0, q.x1, q.y0) + (-0.3, -0.3, 0.3, 0.3),
                        fitz.Rect(q.x0, q.y1, q.x1, q.y1) + (-0.3, -0.3, 0.3, 0.3),
                        fitz.Rect(q.x0, q.y0, q.x0, q.y1) + (-0.3, -0.3, 0.3, 0.3),
                        fitz.Rect(q.x1, q.y0, q.x1, q.y1) + (-0.3, -0.3, 0.3, 0.3)]
    return out


def _label_room(text: str, orig: fitz.Rect, right: fitz.Rect, size: float, bold: bool,
                art: list[fitz.Rect], others: list[fitz.Rect]) -> tuple[fitz.Rect, str]:
    need = _font(bold).text_length(text, fontsize=size) * 1.03 + 1
    if need <= orig.width:
        return right, "left"
    pad = 0.2 * orig.height

    def hits(zone: fitz.Rect) -> bool:
        return zone.width > 0.5 and any(zone.intersects(a) for a in art)
    if not hits(fitz.Rect(orig.x1 + 0.5, orig.y0 + pad, min(right.x1, orig.x0 + need), orig.y1 - pad)):
        return right, "left"
    x0 = orig.x1 - need
    for o in others:  # alt text sau imagine în stânga, pe aceleași rânduri
        if o.y1 > orig.y0 + 1 and o.y0 < orig.y1 - 1 and o.x1 <= orig.x0 + 1:
            x0 = max(x0, o.x1 + 3)
    for a in art:
        if a.y1 > orig.y0 + pad and a.y0 < orig.y1 - pad and a.x1 <= orig.x0 - 0.5:
            x0 = max(x0, a.x1 + 1)
    if orig.x1 - x0 > right.width:
        return fitz.Rect(x0, orig.y0, orig.x1, orig.y1), "right"
    return right, "left"


def _wrap_lines(text: str, width: float, s: float, bold: bool, k: float = 1.03) -> int:
    font = _font(bold)
    space = font.text_length(" ", fontsize=s)
    lines, cur = 1, 0.0
    for w in text.split():
        wl = font.text_length(w, fontsize=s) * k
        if cur and cur + space + wl > width:
            lines, cur = lines + 1, wl
        else:
            cur = cur + (space if cur else 0) + wl
    return lines


def _flow(items: list[dict]) -> None:
    """Paragrafe / puncte de listă unul sub altul, în aceeași coloană: le așezăm ca un flux continuu, cu
    aceeași mărime de literă. Un punct care devine mai lung împinge restul în jos, în spațiul liber."""
    items = sorted(items, key=lambda it: it["r0"].y0)
    stacks, cur = [], []
    for it in items:
        b = it["b"]
        if b["origin"] != "pdf" or it["inside_box"] or it["align"] != "left" or b.get("rotate") or b.get("glyphs"):
            continue
        if cur and (it["r0"].y0 - cur[-1]["r0"].y1 > 1.6 * b["size"] or abs(it["r"].x1 - cur[-1]["r"].x1) > 40):
            stacks.append(cur)
            cur = []
        cur.append(it)
    if cur:
        stacks.append(cur)
    for st in stacks:
        if len(st) < 2 or sum(1 for it in st if it["lines"] >= 2) * 2 < len(st):
            continue  # rânduri de tabel (o singură linie fiecare): rămân pe loc
        top, bottom = st[0]["r0"].y0, max(it["r"].y1 for it in st)
        multi = [it["lh"] for it in st if it["lines"] >= 2]
        lh = statistics.median(multi) if multi else 1.2
        # spațiul dintre puncte, ca în original (rândurile din PDF au zone care se suprapun ușor)
        gaps = [0.0] + [max(0.0, st[k]["r0"].y0 - (st[k - 1]["r0"].y0 + st[k - 1]["lines"] * st[k - 1]["b"]["size"] * lh))
                        for k in range(1, len(st))]
        size0 = min(it["size"] for it in st)
        s = size0
        while s > size0 * 0.6:
            need = sum(gaps) + sum(_wrap_lines(it["text"], it["r"].width + max(2, it["r"].width * 0.03), s, it["b"]["bold"], 1.0) * s * lh for it in st)
            if need <= bottom - top:
                break
            s *= 0.97
        heights = [_wrap_lines(it["text"], it["r"].width + max(2, it["r"].width * 0.03), s, it["b"]["bold"], 1.0) * s * lh for it in st]
        y = top
        for it, g, h in zip(st, gaps, heights):
            y += g
            it["r"] = fitz.Rect(it["r"].x0, y, it["r"].x1, y + h + 0.3 * s)
            it["fit"], it["lh"], it["one_line"], it["flowed"] = s, lh, False, True
            y += h


_BULLETS = {"•", "●", "▪", "■", "◦", "○", "-", "–", "»", "►", "▶", "✓", "✔", "*", "·"}


def _move_bullets(page: fitz.Page, plan: list[dict], all_blocks: list[dict]) -> None:
    """Buletele sunt texte separate, în stânga punctelor. Dacă un punct a coborât (traducere mai lungă),
    buleta lui coboară odată cu el. Le căutăm direct în textul vizibil al paginii."""
    flowed = [it for it in plan if it.get("flowed") and abs(it["r"].y0 - it["r0"].y0) >= 0.5]
    if not flowed:
        return
    hidden = _hidden_rects(page)
    spans = []
    for blk in page.get_text("dict")["blocks"]:
        for line in blk.get("lines", []):
            for sp in line["spans"]:
                t = sp["text"].strip()
                if t in _BULLETS and not _is_hidden(sp["bbox"], hidden, t):
                    spans.append((fitz.Rect(sp["bbox"]), t, sp["size"], f"#{sp['color']:06x}"))
    moved, used = [], set()
    for it in flowed:
        x0, y0 = it["r0"].x0, it["r0"].y0
        cands = [(abs(r.y0 - y0), k) for k, (r, t, size, color) in enumerate(spans)
                 if k not in used and abs(r.y0 - y0) < 0.6 * size and r.x1 <= x0 + 1 and x0 - r.x1 < 25]
        if cands:
            k = min(cands)[1]
            used.add(k)
            moved.append((spans[k], it["r"].y0 - spans[k][0].y0))
    if not moved:
        return
    for (r, *_), _ in moved:
        page.add_redact_annot(r, fill=False)
    page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_NONE,
                          text=fitz.PDF_REDACT_TEXT_REMOVE)
    for (r, t, size, color), dy in moved:
        # DejaVu are mai mult spațiu în stânga bulinei decât fonturile obișnuite: compensăm
        nr = fitz.Rect(r.x0 - 0.3 * size, r.y0 + dy, r.x1 + 4, r.y1 + dy)
        plan.append({"r": nr, "r0": r, "b": {"bold": False, "color": color, "rotate": 0}, "text": t, "lh": 1.22,
                     "size": size, "fit": size, "one_line": True, "align": "left", "lines": 1, "inside_box": False})


def _fit_size(text: str, rect: fitz.Rect, size: float, bold: bool, lh: float, one_line: bool) -> float:
    """Cea mai mare mărime (≤ cea originală) la care textul încape în zonă, cu despărțire pe cuvinte."""
    font = _font(bold)
    words = text.split()
    width = max(1.0, rect.width - 1)
    s = size
    while s > size * 0.5:
        if one_line:
            if font.text_length(text, fontsize=s) * 1.03 <= width:
                return s
        else:
            lines, cur = 1, 0.0
            space = font.text_length(" ", fontsize=s)
            for w in words:
                wl = font.text_length(w, fontsize=s) * 1.03
                if cur and cur + space + wl > width:
                    lines, cur = lines + 1, wl
                else:
                    cur = cur + (space if cur else 0) + wl
            if lines * s * lh <= rect.height + 0.15 * s:
                return s
        s *= 0.96
    return size * 0.5


_FONTS: dict[bool, fitz.Font] = {}


def _font(bold: bool) -> fitz.Font:
    if bold not in _FONTS:
        _FONTS[bold] = fitz.Font(fontfile=str(FONTS_DIR / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")))
    return _FONTS[bold]


def _write(page, rect: fitz.Rect, text: str, size: float, bold: bool, color: str, align: str, css: str, archive,
           lh: float = 1.22, rotate: int = 0, one_line: bool = False) -> bool:
    body = _html.escape(text).replace("\n", "<br>")
    if one_line:  # titlu de bandă / celulă: micșorăm fontul cât să încapă pe un rând, în lățimea zonei
        width = _font(bold).text_length(text, fontsize=size) * 1.03  # lățimea reală, cu fontul folosit
        if width > rect.width - 1:
            size = max(size * 0.5, size * (rect.width - 1) / width)
    style = (f"font-size:{size:.2f}px; line-height:{lh}; color:{_rgb(color)}; text-align:{align};"
             f" font-weight:{'bold' if bold else 'normal'};")
    target = fitz.Rect(rect.x0, rect.y0 - 0.5, rect.x1 + max(2, rect.width * 0.03), rect.y1 + max(1.5, rect.height * 0.08))
    if rotate:  # text vertical: zona rămâne cea originală, doar scrisul e rotit
        target = fitz.Rect(rect.x0 - 1, rect.y0 - max(2, rect.height * 0.05), rect.x1 + 1, rect.y1 + max(2, rect.height * 0.05))
    spare, _ = page.insert_htmlbox(target, f'<div style="{style}">{body}</div>', css=css, archive=archive,
                                   scale_low=0.55, rotate=rotate)
    return spare >= 0


def preview_page(project: dict[str, Any], lang: str, page_no: int) -> bytes:
    tmp = project_dir(project["id"]) / "cache" / f"preview-{lang}-{page_no}.pdf"
    export_document(project, lang, tmp, pages=[page_no])
    with fitz.open(tmp) as d:
        png = d[0].get_pixmap(dpi=110).tobytes("png")
    tmp.unlink(missing_ok=True)
    return png
