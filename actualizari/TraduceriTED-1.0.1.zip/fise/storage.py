"""Proiecte, fișiere încărcate și setări — totul local, în folderul `data`."""
from __future__ import annotations

import json
import os
import re
import tempfile
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from .catalog import LANGUAGES

ROOT = Path(__file__).resolve().parent.parent
# Instalată cu instalatorul Windows (instalare/instaleaza-windows.ps1): <instalare>\app (codul), <instalare>\python, <instalare>\data (datele tale).
# Datele stau în afara folderului aplicației, ca actualizările să nu le atingă niciodată.
DATA = Path(os.environ["TRADUCERI_TED_DATA"]) if os.environ.get("TRADUCERI_TED_DATA") else (
    ROOT.parent / "data" if (ROOT.parent / "python" / "python.exe").exists() else ROOT / "data")
PROJECTS = DATA / "proiecte"
TEMPLATES_DIR = ROOT / "sabloane"
FONTS_DIR = ROOT / "fonts"

_lock = threading.RLock()


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def new_id() -> str:
    return uuid.uuid4().hex


def _atomic_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


# ---------------------------------------------------------------- setări
DEFAULT_SETTINGS: dict[str, Any] = {
    "ai_mode": "ambele",
    "visual_check": True,  # verificare vizuală cu AI a fiecărei pagini traduse, după export  # claude | codex | ambele | custom (vezi fise/ai/__init__.py)
    # Cine face fiecare pas: claude_cli, codex_cli, claude_api, openai_api
    "extract_provider": "claude_cli",    # scanare (citirea textului din pagini)
    "verify_provider": "codex_cli",      # verificare (alt AI decât cel care scanează)
    "translate_provider": "claude_cli",  # traducere
    "claude_cli_model": "sonnet",
    "codex_cli_model": "",
    "claude_api_model": "claude-opus-5-5",
    "openai_api_model": "gpt-5.5",
    "claude_api_key": "",
    "openai_api_key": "",
    "claude_cli_path": "",
    "codex_cli_path": "",
    "timeout_seconds": 600,
    "custom_languages": {},
}


def settings_path() -> Path:
    return DATA / "setari.json"


def load_settings() -> dict[str, Any]:
    saved = {}
    if settings_path().exists():
        try:
            saved = json.loads(settings_path().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            saved = {}
    return {**DEFAULT_SETTINGS, **saved}


def save_settings(settings: dict[str, Any]) -> None:
    with _lock:
        _atomic_write(settings_path(), settings)


def all_languages(settings: dict[str, Any] | None = None) -> dict[str, str]:
    s = settings or load_settings()
    return {**LANGUAGES, **(s.get("custom_languages") or {})}


# ---------------------------------------------------------------- texte traductibile
def field(src: str = "") -> dict[str, Any]:
    """Un text: `src` = originalul (verificat), `tr` = traducere AI, `ov` = corectură manuală pe limbă."""
    return {"id": new_id(), "src": src or "", "tr": {}, "ov": {}}


def has_words(text: str) -> bool:
    """False pentru texte fără cuvinte de tradus: 12.8V, 300Ah, TED007438, -20~60°C."""
    words = re.findall(r"[^\W\d_]{2,}", text or "")
    units = {"v", "a", "ah", "wh", "kwh", "w", "kw", "mm", "cm", "kg", "g", "hz", "khz", "va", "kva", "ma", "mah",
             "pcs", "ted", "ip", "dc", "ac", "c", "nm", "mw", "awg", "vdc", "vac", "kgs", "lbs"}
    return any(w.lower() not in units for w in words)


def text_for(f: dict[str, Any] | None, lang: str, source_lang: str) -> tuple[str, str]:
    """Textul dintr-o limbă și starea lui: manual | ai | sursa | lipsa."""
    if not f:
        return "", "lipsa"
    if lang in f.get("ov", {}):
        return f["ov"][lang], "manual"
    if lang in f.get("tr", {}):
        return f["tr"][lang], "ai"
    if lang == source_lang or not has_words(f.get("src", "")):
        return f.get("src", ""), "sursa"
    return f.get("src", ""), "lipsa"


def iter_fields(project: dict[str, Any]):
    for page in (project.get("doc") or {}).get("pages", []):
        for b in page["blocks"]:
            if not b.get("skip"):
                yield b["text"]


def find_block(project: dict[str, Any], block_id: str) -> dict[str, Any] | None:
    for page in (project.get("doc") or {}).get("pages", []):
        for b in page["blocks"] + page.get("brand", []):
            if b["id"] == block_id:
                return b
    return None


# ---------------------------------------------------------------- proiecte
def safe_id(value: str) -> str:
    if not re.fullmatch(r"[0-9a-f]{32}", value or ""):
        raise ValueError("Identificator invalid.")
    return value


def project_dir(pid: str) -> Path:
    return PROJECTS / safe_id(pid)


def load_project(pid: str) -> dict[str, Any]:
    path = project_dir(pid) / "proiect.json"
    if not path.exists():
        raise FileNotFoundError("Proiectul nu există.")
    return json.loads(path.read_text(encoding="utf-8"))


def save_project(project: dict[str, Any]) -> None:
    with _lock:
        project["updated_at"] = now()
        _atomic_write(project_dir(project["id"]) / "proiect.json", project)


def list_projects() -> list[dict[str, Any]]:
    PROJECTS.mkdir(parents=True, exist_ok=True)
    out = []
    for folder in PROJECTS.iterdir():
        try:
            p = json.loads((folder / "proiect.json").read_text(encoding="utf-8"))
            if p.get("version") != 2:
                continue  # proiecte din versiunea veche a aplicației
            out.append({"id": p["id"], "name": p["name"], "type": p["type"],
                        "updated_at": p.get("updated_at", ""), "languages": p.get("languages", [])})
        except (OSError, ValueError, KeyError):
            continue
    return sorted(out, key=lambda x: x["updated_at"], reverse=True)


def create_project(name: str, kind: str, languages: list[str], replace_brand: bool = False) -> dict[str, Any]:
    langs = [l for l in dict.fromkeys(languages) if l in all_languages()]
    if not langs:
        raise ValueError("Bifează cel puțin o limbă.")
    p = {
        "version": 2, "id": new_id(), "type": "manual" if kind == "manual" else "fisa",
        "name": (name or "Document nou").strip()[:160],
        "languages": langs, "source_language": "auto", "detected_language": None,
        "replace_brand": bool(replace_brand), "logo_category": "lifepo4_batteries",
        "sources": [], "doc": None, "scan_check": None, "verification": None, "exports": [], "qa": {}, "log": [],
        "created_at": now(), "updated_at": now(),
    }
    save_project(p)
    return p


def effective_source_language(project: dict[str, Any]) -> str:
    sl = project.get("source_language", "auto")
    if sl == "auto":
        return project.get("detected_language") or "en"
    return sl
