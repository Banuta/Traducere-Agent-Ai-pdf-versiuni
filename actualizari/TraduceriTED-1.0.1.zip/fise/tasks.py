"""Traducerea (fiecare limbă direct din textul verificat) și verificarea traducerilor."""
from __future__ import annotations

import json
import re
from typing import Any, Callable

from . import ai
from .catalog import LANGUAGE_ENGLISH_NAMES
from .storage import all_languages, effective_source_language, has_words, iter_fields, load_settings, now

Progress = Callable[[str], None]
_NUM = re.compile(r"\d+(?:[.,]\d+)*")


def numbers(text: str) -> list[str]:
    return sorted(_NUM.findall(text or ""))


def lang_name(code: str) -> str:
    return LANGUAGE_ENGLISH_NAMES.get(code) or all_languages().get(code, code)


TRANSLATE_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["translations"],
    "properties": {"translations": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["id", "text"],
        "properties": {"id": {"type": "string"}, "text": {"type": "string"}}}}},
}

TR_CHECK_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["issues"],
    "properties": {"issues": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["id", "problem", "suggestion"],
        "properties": {"id": {"type": "string"}, "problem": {"type": "string"},
                       "suggestion": {"type": "string"}}}}},
}


def needs_translation(f: dict[str, Any], lang: str, source_lang: str, force: bool = False) -> bool:
    src = f.get("src", "")
    if not src.strip() or not has_words(src) or source_lang == lang:
        return False  # valorile tehnice (12.8V, 300Ah) rămân identice în toate limbile
    if lang in f.get("ov", {}):
        return False  # corectura manuală nu se atinge niciodată
    if force:
        return True
    return f.get("tr_src", {}).get(lang) != src or lang not in f.get("tr", {})


def _item(f: dict[str, Any]) -> dict[str, Any]:
    """Fragmentul de tradus; textele scurte (celule, titluri) primesc o limită de lungime, ca să încapă."""
    src = f["src"]
    item: dict[str, Any] = {"id": f["id"], "text": src}
    if len(src) <= 60:
        item["max_chars"] = max(len(src) + 6, round(len(src) * 1.3))
    return item


def _prompt(lang: str, src_lang: str, items: list[dict], brand_names: list[str]) -> str:
    brand = ""
    if brand_names:
        brand = ("The document is re-branded for TED Electric: replace the manufacturer names "
                 + ", ".join(f'"{n}"' for n in brand_names) + ' with "TED", and their websites/e-mails with '
                 "www.tedelectric.eu.\n")
    return brand + f"""Translate these fragments of a technical product document (datasheet / user manual) from
{lang_name(src_lang)} into {lang_name(lang)}. Each fragment is one text block of a page (a title, paragraph, list item
or table cell); translate each one directly from the original.
Rules: use the standard technical terminology of {lang_name(lang)} electrical/battery product documentation.
Keep every number, decimal separator, range, tolerance, unit, symbol, model code and product identifier exactly
unchanged. Do not add, remove or explain information. Keep UPPER-CASE text upper-case. Keep each translation as
concise as possible: it must fit in the same place on the page. When an item has "max_chars", the translation
must not be longer than that (table cells, headings): use the standard abbreviations of {lang_name(lang)} technical
documentation if needed (e.g. "max.", "temp.", "coef."), never drop information. Return one translation per input id.

FRAGMENTS (JSON):
{json.dumps(items, ensure_ascii=False)}"""


def translate(project: dict[str, Any], languages: list[str], progress: Progress, force: bool = False) -> dict:
    if not project.get("doc"):
        raise ai.AIError("Documentul nu a fost încă scanat.")
    provider = ai.for_role("translate", load_settings())
    src_lang = effective_source_language(project)
    brand_names = project["doc"].get("manufacturer_names", []) if project.get("replace_brand") else []
    report = {}
    for lang in languages:
        todo = [f for f in iter_fields(project) if needs_translation(f, lang, src_lang, force)]
        done = 0
        for start in range(0, len(todo), 120):
            chunk = todo[start:start + 120]
            progress(f"Traduc în {all_languages().get(lang, lang)} ({start + len(chunk)}/{len(todo)})…")
            items = [_item(f) for f in chunk]
            out = provider.run(_prompt(lang, src_lang, items, brand_names), TRANSLATE_SCHEMA)
            by_id = {t["id"]: t["text"] for t in out.get("translations", []) if isinstance(t, dict)}
            retry = [f for f in chunk if not by_id.get(f["id"]) or "�" in by_id[f["id"]]]
            if retry:  # a doua încercare pentru textele lipsă sau cu caractere stricate
                again = provider.run(_prompt(lang, src_lang, [_item(f) for f in retry],
                                             brand_names), TRANSLATE_SCHEMA)
                by_id.update({t["id"]: t["text"] for t in again.get("translations", []) if isinstance(t, dict)})
            for f in chunk:
                text = by_id.get(f["id"])
                if not text or "�" in text:
                    continue
                f.setdefault("tr", {})[lang] = text
                f.setdefault("tr_src", {})[lang] = f["src"]
                warn = f.setdefault("warn", {})
                if numbers(f["src"]) != numbers(text):
                    warn[lang] = "Cifrele din traducere diferă de original."
                else:
                    warn.pop(lang, None)
                done += 1
        report[lang] = done
    project["log"].append({"at": now(), "what": f"Traducere {', '.join(languages)} cu {provider.label}"})
    return report


def verify_translations(project: dict[str, Any], languages: list[str], progress: Progress) -> dict:
    provider = ai.for_role("verify", load_settings())
    src_lang = effective_source_language(project)
    result: dict[str, Any] = {"provider": provider.label, "at": now(), "issues": {}}
    for lang in languages:
        for f in iter_fields(project):
            f.get("check", {}).pop(lang, None)
        pairs = [{"id": f["id"], "original": f["src"], "translation": f.get("ov", {}).get(lang) or f["tr"][lang]}
                 for f in iter_fields(project) if lang in f.get("tr", {}) or lang in f.get("ov", {})]
        if not pairs or lang == src_lang:
            continue
        found = 0
        by_id = {f["id"]: f for f in iter_fields(project)}
        for start in range(0, len(pairs), 150):
            chunk = pairs[start:start + 150]
            progress(f"Verific traducerea în {all_languages().get(lang, lang)} ({start + len(chunk)}/{len(pairs)})…")
            o = provider.run(f"""Check these {lang_name(lang)} translations of a technical product document against
the {lang_name(src_lang)} originals. Report only real errors: wrong meaning, wrong technical term, changed or missing
numbers/units/codes, untranslated text, grammar errors. Write "problem" in Romanian and "suggestion" as the corrected
{lang_name(lang)} text: exactly ONE complete corrected translation of the whole fragment (no alternatives, no "/" between
options, no comments), ready to replace the current translation.

PAIRS (JSON):
{json.dumps(chunk, ensure_ascii=False)}""", TR_CHECK_SCHEMA)
            for issue in o.get("issues", []):
                f = by_id.get(issue.get("id"))
                if not f:
                    continue
                sug = (issue.get("suggestion") or "").strip()
                check = {"problem": issue.get("problem", ""), "suggestion": sug}
                # corectăm automat traducerea AI (nu și corecturile tale), dacă cifrele rămân aceleași
                if sug and lang not in f.get("ov", {}) and numbers(sug) == numbers(f["src"]):
                    check.update({"applied": True, "before": f["tr"].get(lang, "")})
                    f["tr"][lang] = sug
                    f.setdefault("warn", {}).pop(lang, None)
                f.setdefault("check", {})[lang] = check
                found += 1
        result["issues"][lang] = found
    project["verification"] = result
    project["log"].append({"at": now(), "what": f"Verificare traduceri cu {provider.label}"})
    return result
