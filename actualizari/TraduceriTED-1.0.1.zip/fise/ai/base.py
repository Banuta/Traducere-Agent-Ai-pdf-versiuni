"""Interfața comună pentru toți furnizorii AI."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


class AIError(RuntimeError):
    """Eroare afișată utilizatorului (mesaj în română, fără detalii tehnice inutile)."""


class Provider:
    key = ""
    label = ""
    kind = ""  # "abonament" | "cheie API"

    def __init__(self, settings: dict[str, Any]):
        self.settings = settings

    # --- stare / logare -------------------------------------------------
    def status(self) -> dict[str, Any]:
        """{"ready": bool, "message": str, "installed": bool, "logged_in": bool}"""
        raise NotImplementedError

    def login(self) -> str:
        raise AIError("Acest furnizor nu are logare cu cont; folosește o cheie API.")

    def install(self) -> str:
        raise AIError("Acest furnizor nu are nevoie de instalare.")

    # --- execuție -------------------------------------------------------
    def run(self, prompt: str, schema: dict[str, Any], images: list[Path] | None = None) -> dict[str, Any]:
        raise NotImplementedError

    def test(self) -> str:
        out = self.run('Reply with the JSON object {"ok": true}.',
                       {"type": "object", "properties": {"ok": {"type": "boolean"}},
                        "required": ["ok"], "additionalProperties": False})
        if out.get("ok") is not True:
            raise AIError("Răspuns neașteptat la test.")
        return "Conexiunea funcționează."


def parse_json(text: str) -> dict[str, Any]:
    """Extrage un obiect JSON dintr-un răspuns (tolerează ```json ...```)."""
    text = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        raise AIError("AI-ul nu a returnat date în formatul cerut. Încearcă din nou.")
    try:
        value = json.loads(text[start:end + 1])
    except json.JSONDecodeError as e:
        raise AIError(f"Răspuns AI incomplet sau invalid ({e.msg}). Încearcă din nou.") from e
    if not isinstance(value, dict):
        raise AIError("Răspuns AI invalid.")
    return value


def schema_instructions(schema: dict[str, Any]) -> str:
    return ("\n\nReturn ONLY one JSON object (no prose, no markdown) that validates against this JSON Schema:\n"
            + json.dumps(schema, ensure_ascii=False))
