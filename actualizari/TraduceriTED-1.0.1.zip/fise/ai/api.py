"""Furnizori cu cheie API (plată pe consum): Claude API și OpenAI API."""
from __future__ import annotations

import base64
import importlib
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

from ..secret_store import decrypt
from .base import AIError, Provider, parse_json

_CLAUDE_FALLBACK_MODELS = {"claude-fable-5-1", "claude-opus-5-5", "claude-opus-5", "claude-sonnet-5-5"}


_install_lock = threading.Lock()


def _module(name: str):
    """Pachetele pentru chei API (anthropic, openai) se instalează doar la prima folosire,
    ca instalarea aplicației să fie rapidă pentru cine folosește doar abonamentul."""
    try:
        return importlib.import_module(name)
    except ImportError:
        pass
    req = Path(__file__).resolve().parents[2] / "requirements-api.txt"
    with _install_lock:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
                            "--only-binary=:all:", "-r", str(req)], capture_output=True, text=True, timeout=900,
                           creationflags=0x08000000 if sys.platform == "win32" else 0)
    if r.returncode:
        raise AIError("Nu am putut instala pachetele pentru cheile API (verifică internetul): " + r.stderr[-300:])
    importlib.invalidate_caches()
    return importlib.import_module(name)


def _b64(path: Path) -> str:
    return base64.b64encode(Path(path).read_bytes()).decode()


class ClaudeAPI(Provider):
    key, label, kind = "claude_api", "Claude API (cheie de la console.anthropic.com)", "cheie API"

    def _key(self) -> str:
        return decrypt(self.settings.get("claude_api_key", ""))

    def status(self):
        ok = bool(self._key())
        return {"ready": ok, "installed": True, "logged_in": ok,
                "message": "Cheie salvată." if ok else "Nu ai salvat o cheie API Claude."}

    def run(self, prompt, schema, images=None):
        anthropic = _module("anthropic")

        key = self._key()
        if not key:
            raise AIError("Salvează cheia API Claude în pagina Conectare AI.")
        client = anthropic.Anthropic(api_key=key, max_retries=3,
                                     timeout=float(self.settings.get("timeout_seconds", 600)))
        content: list[dict[str, Any]] = [
            {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": _b64(p)}}
            for p in images or []
        ]
        content.append({"type": "text", "text": prompt})
        model = self.settings.get("claude_api_model") or "claude-opus-5-5"
        kwargs: dict[str, Any] = dict(
            model=model, max_tokens=64000,
            output_config={"effort": "medium", "format": {"type": "json_schema", "schema": schema}},
            messages=[{"role": "user", "content": content}],
        )
        if model in _CLAUDE_FALLBACK_MODELS:
            kwargs["betas"] = ["server-side-fallback-2026-07-01"]
            kwargs["fallbacks"] = "default"
        try:
            with client.beta.messages.stream(**kwargs) as stream:
                msg = stream.get_final_message()
        except anthropic.AuthenticationError as e:
            raise AIError("Cheia API Claude nu este validă.") from e
        except anthropic.PermissionDeniedError as e:
            raise AIError("Cheia API Claude nu are acces la acest model.") from e
        except anthropic.RateLimitError as e:
            raise AIError("Limită de utilizare Claude API atinsă. Încearcă peste un minut.") from e
        except anthropic.APIStatusError as e:
            raise AIError(f"Claude API: eroare {e.status_code}: {e.message}") from e
        except anthropic.APIConnectionError as e:
            raise AIError("Nu mă pot conecta la Claude API. Verifică internetul.") from e
        if msg.stop_reason == "refusal":
            raise AIError("Claude a refuzat cererea.")
        if msg.stop_reason == "max_tokens":
            raise AIError("Răspunsul a fost prea lung și s-a întrerupt.")
        return parse_json("".join(b.text for b in msg.content if b.type == "text"))


class OpenAIAPI(Provider):
    key, label, kind = "openai_api", "OpenAI API (cheie de la platform.openai.com)", "cheie API"

    def _key(self) -> str:
        return decrypt(self.settings.get("openai_api_key", ""))

    def status(self):
        ok = bool(self._key())
        return {"ready": ok, "installed": True, "logged_in": ok,
                "message": "Cheie salvată." if ok else "Nu ai salvat o cheie API OpenAI."}

    def run(self, prompt, schema, images=None):
        openai = _module("openai")

        key = self._key()
        if not key:
            raise AIError("Salvează cheia API OpenAI în pagina Conectare AI.")
        client = openai.OpenAI(api_key=key, max_retries=3, timeout=float(self.settings.get("timeout_seconds", 600)))
        content: list[dict[str, Any]] = [{"type": "input_text", "text": prompt}]
        content += [{"type": "input_image", "image_url": f"data:image/png;base64,{_b64(p)}"} for p in images or []]
        try:
            r = client.responses.create(
                model=self.settings.get("openai_api_model") or "gpt-5.5",
                input=[{"role": "user", "content": content}],
                reasoning={"effort": "medium"},
                text={"format": {"type": "json_schema", "name": "rezultat", "schema": schema, "strict": True}},
            )
        except openai.AuthenticationError as e:
            raise AIError("Cheia API OpenAI nu este validă.") from e
        except openai.RateLimitError as e:
            raise AIError("Limită OpenAI atinsă sau cont fără credit.") from e
        except openai.APIStatusError as e:
            raise AIError(f"OpenAI API: eroare {e.status_code}: {e.message}") from e
        except openai.APIConnectionError as e:
            raise AIError("Nu mă pot conecta la OpenAI. Verifică internetul.") from e
        return parse_json(r.output_text)
