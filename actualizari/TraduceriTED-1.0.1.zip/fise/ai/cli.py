"""Claude Code și Codex CLI — folosesc abonamentul tău (Claude Pro/Max, ChatGPT Plus/Pro).

Te loghezi o singură dată, din aplicație (butonul „Conectează”), care deschide
fereastra oficială de logare. Aplicația nu vede și nu salvează parola sau tokenul.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from .base import AIError, Provider, parse_json, schema_instructions

WINDOWS = sys.platform == "win32"
NO_WINDOW = 0x08000000 if WINDOWS else 0  # CREATE_NO_WINDOW
NEW_CONSOLE = 0x00000010 if WINDOWS else 0  # CREATE_NEW_CONSOLE


def _find(name: str, configured: str) -> str | None:
    if configured and Path(configured).exists():
        return configured
    found = shutil.which(name)
    if found:
        return found
    if WINDOWS:  # locații uzuale pe Windows
        home = Path.home()
        for p in (home / ".local" / "bin" / f"{name}.exe",
                  Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "nodejs" / f"{name}.cmd",
                  home / "AppData" / "Roaming" / "npm" / f"{name}.cmd",
                  home / "AppData" / "Local" / "Programs" / name / f"{name}.exe"):
            if p.exists():
                return str(p)
    return None


def _cmd(exe: str, *args: str) -> list[str]:
    # Fișierele .cmd/.bat (instalare prin npm) trebuie pornite prin cmd.exe.
    if WINDOWS and exe.lower().endswith((".cmd", ".bat")):
        return ["cmd", "/c", exe, *args]
    return [exe, *args]


def _run(cmd: list[str], stdin: str = "", cwd: str | None = None, timeout: int = 600) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, input=stdin, capture_output=True, text=True, encoding="utf-8",
                              errors="replace", cwd=cwd, timeout=timeout, creationflags=NO_WINDOW)
    except subprocess.TimeoutExpired as e:
        raise AIError(f"AI-ul nu a răspuns în {timeout} secunde. Încearcă din nou sau mărește timpul în Setări.") from e
    except OSError as e:
        raise AIError(f"Programul nu a putut fi pornit: {e}") from e


def _open_console(cmd: list[str]) -> None:
    if WINDOWS:
        subprocess.Popen(["cmd", "/k", *cmd], creationflags=NEW_CONSOLE)
    else:  # dezvoltare pe Linux/macOS: rulăm în fundal
        subprocess.Popen(cmd)


class ClaudeCLI(Provider):
    key, label, kind = "claude_cli", "Claude (cont Claude Pro/Max)", "abonament"
    install_hint = ("Deschide PowerShell și rulează:  irm https://claude.ai/install.ps1 | iex   "
                    "apoi repornește aplicația.")

    def exe(self) -> str | None:
        return _find("claude", self.settings.get("claude_cli_path", ""))

    def status(self) -> dict[str, Any]:
        exe = self.exe()
        if not exe:
            return {"ready": False, "installed": False, "logged_in": False,
                    "message": "Claude Code nu este instalat pe acest PC."}
        r = _run(_cmd(exe, "auth", "status"), timeout=30)
        try:
            info = json.loads(r.stdout or "{}")
            logged = bool(info.get("loggedIn"))
        except ValueError:
            logged = r.returncode == 0 and "logged in" in (r.stdout + r.stderr).lower()
        return {"ready": logged, "installed": True, "logged_in": logged,
                "message": "Conectat." if logged else "Instalat, dar nu ești conectat."}

    def login(self) -> str:
        exe = self.exe()
        if not exe:
            raise AIError("Claude Code nu este instalat. " + self.install_hint)
        _open_console(_cmd(exe, "auth", "login"))
        return "S-a deschis fereastra de logare Claude. Urmează pașii din browser, apoi apasă „Verifică”."

    def install(self) -> str:
        if not WINDOWS:
            raise AIError("Instalarea automată e disponibilă pe Windows. " + self.install_hint)
        # instalatorul oficial Claude Code, într-o fereastră PowerShell vizibilă
        subprocess.Popen(["powershell", "-NoExit", "-ExecutionPolicy", "Bypass", "-Command",
                          "irm https://claude.ai/install.ps1 | iex; "
                          "Write-Host ''; Write-Host 'Gata. Inchide fereastra si apasa Verifica in aplicatie.'"],
                         creationflags=NEW_CONSOLE)
        return "Se instalează Claude Code în fereastra albastră. Când scrie „Gata”, apasă „Verifică”."

    def run(self, prompt, schema, images=None):
        exe = self.exe()
        if not exe:
            raise AIError("Claude Code nu este instalat. " + self.install_hint)
        with tempfile.TemporaryDirectory(prefix="fise-claude-") as work:
            names = []
            for i, img in enumerate(images or []):
                name = f"pagina_{i + 1:02d}{Path(img).suffix}"
                shutil.copy(img, Path(work) / name)
                names.append(name)
            full = prompt
            if names:
                full += ("\n\nThe source pages are image files in the current folder. Use the Read tool to "
                         "open EVERY one of them before answering: " + ", ".join(names))
            # Sesiune izolată: fără serverele MCP, comenzile și istoricul utilizatorului.
            args = ["-p", "--output-format", "json", "--model", self.settings.get("claude_cli_model") or "sonnet",
                    "--strict-mcp-config", "--disable-slash-commands", "--no-session-persistence"]
            args += ["--tools", "Read", "--allowedTools", "Read"] if names else ["--tools", ""]
            # --json-schema doar când putem transmite argumentul în siguranță (nu prin cmd.exe).
            use_schema = not (WINDOWS and exe.lower().endswith((".cmd", ".bat")))
            if use_schema:
                args += ["--json-schema", json.dumps(schema, ensure_ascii=False)]
            else:
                full += schema_instructions(schema)
            r = _run(_cmd(exe, *args), stdin=full, cwd=work, timeout=int(self.settings.get("timeout_seconds", 600)))
        try:
            data = json.loads(r.stdout)
        except ValueError:
            raise AIError(_explain_cli_error("Claude", r)) from None
        if data.get("is_error"):
            raise AIError("Claude: " + str(data.get("result") or data.get("subtype") or "eroare necunoscută")[:500])
        if isinstance(data.get("structured_output"), dict):
            return data["structured_output"]
        return parse_json(str(data.get("result", "")))


class CodexCLI(Provider):
    key, label, kind = "codex_cli", "Codex (cont ChatGPT Plus/Pro)", "abonament"
    install_hint = ("Apasă „Instalează Codex” în fereastra Conectare AI. Varianta manuală: Node.js de pe nodejs.org, "
                    "apoi în PowerShell:  npm install -g @openai/codex")

    def exe(self) -> str | None:
        return _find("codex", self.settings.get("codex_cli_path", ""))

    def status(self) -> dict[str, Any]:
        exe = self.exe()
        if not exe:
            return {"ready": False, "installed": False, "logged_in": False,
                    "message": "Codex CLI nu este instalat pe acest PC."}
        r = _run(_cmd(exe, "login", "status"), timeout=30)
        text = (r.stdout + r.stderr).lower()
        logged = r.returncode == 0 and "not logged" not in text
        return {"ready": logged, "installed": True, "logged_in": logged,
                "message": "Conectat." if logged else "Instalat, dar nu ești conectat."}

    def login(self) -> str:
        exe = self.exe()
        if not exe:
            raise AIError("Codex nu este instalat. " + self.install_hint)
        _open_console(_cmd(exe, "login"))
        return "S-a deschis fereastra de logare ChatGPT. Urmează pașii din browser, apoi apasă „Verifică”."

    def install(self) -> str:
        if not WINDOWS:
            raise AIError("Instalarea automată e disponibilă pe Windows. " + self.install_hint)
        script = Path(__file__).resolve().parents[2] / "instalare" / "instaleaza-codex.ps1"
        subprocess.Popen(["powershell", "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                         creationflags=NEW_CONSOLE)
        return "Se instalează Codex în fereastra albastră (nu e nevoie de Node.js). Când scrie „Gata”, apasă „Verifică”."

    def run(self, prompt, schema, images=None):
        exe = self.exe()
        if not exe:
            raise AIError("Codex nu este instalat. " + self.install_hint)
        with tempfile.TemporaryDirectory(prefix="fise-codex-") as work:
            out_file = Path(work) / "raspuns.json"
            schema_file = Path(work) / "schema.json"
            schema_file.write_text(json.dumps(schema), encoding="utf-8")
            # „-” = instrucțiunile vin pe stdin; îl punem primul, ca să nu fie luat drept imagine de -i.
            args = ["exec", "-", "--skip-git-repo-check", "--sandbox", "read-only",
                    "--output-last-message", str(out_file)]
            model = self.settings.get("codex_cli_model")
            if model:
                args += ["-m", model]
            for img in images or []:
                args += ["-i", str(img)]
            base = list(args)
            args += ["--output-schema", str(schema_file)]
            timeout = int(self.settings.get("timeout_seconds", 600))
            full = prompt + schema_instructions(schema)
            r = _run(_cmd(exe, *args), stdin=full, cwd=work, timeout=timeout)
            if r.returncode and "output-schema" in (r.stderr or ""):
                # Versiune mai veche de Codex, fără --output-schema.
                r = _run(_cmd(exe, *base), stdin=full, cwd=work, timeout=timeout)
            if r.returncode or not out_file.exists():
                raise AIError(_explain_cli_error("Codex", r))
            return parse_json(out_file.read_text(encoding="utf-8", errors="replace"))


def _explain_cli_error(name: str, r: subprocess.CompletedProcess) -> str:
    text = ((r.stderr or "") + "\n" + (r.stdout or "")).strip()
    low = text.lower()
    if "login" in low or "not logged" in low or "unauthorized" in low or "401" in low:
        return f"{name}: nu ești conectat. Apasă „Conectează” în pagina Conectare AI."
    if "limit" in low or "quota" in low or "429" in low:
        return f"{name}: ai atins limita de utilizare a abonamentului. Încearcă mai târziu sau folosește alt furnizor."
    return f"{name} a returnat o eroare: {text[-600:] or 'fără detalii'}"
