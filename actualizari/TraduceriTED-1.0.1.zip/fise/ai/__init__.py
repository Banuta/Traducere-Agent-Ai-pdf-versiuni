"""Registrul furnizorilor AI și alegerea AI-ului pentru fiecare pas."""
from __future__ import annotations

from typing import Any

from .api import ClaudeAPI, OpenAIAPI
from .base import AIError, Provider
from .cli import ClaudeCLI, CodexCLI

PROVIDERS: dict[str, type[Provider]] = {
    "claude_cli": ClaudeCLI,
    "codex_cli": CodexCLI,
    "claude_api": ClaudeAPI,
    "openai_api": OpenAIAPI,
}

# Ce AI folosește utilizatorul (setarea „ai_mode”):
#   claude  — doar Claude (abonament, sau cheie API Claude dacă abonamentul nu e conectat)
#   codex   — doar ChatGPT/Codex (abonament, sau cheie API OpenAI)
#   ambele  — Claude scanează și traduce, ChatGPT verifică (verificare independentă);
#             dacă unul lipsește, celălalt face tot
#   custom  — alegere manuală pe fiecare pas (setările *_provider)
AI_MODES = {"claude": "Doar Claude", "codex": "Doar ChatGPT (Codex)", "ambele": "Ambele", "custom": "Avansat"}
_CLAUDE = ["claude_cli", "claude_api"]
_OPENAI = ["codex_cli", "openai_api"]


def get(key: str, settings: dict[str, Any]) -> Provider:
    cls = PROVIDERS.get(key)
    if not cls:
        raise AIError(f"Furnizor AI necunoscut: {key}")
    return cls(settings)


def candidates(role: str, settings: dict[str, Any]) -> list[str]:
    """Furnizorii potriviți pentru un pas, în ordinea preferinței."""
    mode = settings.get("ai_mode") or "ambele"
    if mode == "claude":
        return _CLAUDE
    if mode == "codex":
        return _OPENAI
    if mode == "ambele":
        return _OPENAI + _CLAUDE if role == "verify" else _CLAUDE + _OPENAI
    chosen = settings.get(f"{role}_provider") or "claude_cli"
    return [chosen] + [k for k in PROVIDERS if k != chosen]


def for_role(role: str, settings: dict[str, Any]) -> Provider:
    """role: extract | translate | verify."""
    for key in candidates(role, settings):
        p = get(key, settings)
        if _ready(p):
            return p
    mode = settings.get("ai_mode") or "ambele"
    if mode == "claude":
        raise AIError("Ai ales să folosești doar Claude, dar Claude nu este conectat. Deschide „Conectare AI”.")
    if mode == "codex":
        raise AIError("Ai ales să folosești doar ChatGPT, dar Codex nu este conectat. Deschide „Conectare AI”.")
    raise AIError("Niciun AI nu este conectat. Deschide „Conectare AI” și conectează-te cu contul Claude sau ChatGPT.")


def _ready(p: Provider) -> bool:
    try:
        return bool(p.status().get("ready"))
    except Exception:  # noqa: BLE001
        return False


__all__ = ["AIError", "AI_MODES", "PROVIDERS", "Provider", "candidates", "get", "for_role"]
