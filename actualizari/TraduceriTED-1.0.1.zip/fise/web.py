"""Serverul local (Flask). Ascultă doar pe 127.0.0.1."""
from __future__ import annotations

import io
import shutil
from pathlib import Path
from typing import Any

from flask import Flask, abort, jsonify, render_template, request, send_file
from werkzeug.exceptions import HTTPException

from . import ai, checks, document, jobs, sources, tasks, update
from .catalog import CATEGORIES
from .secret_store import encrypt
from .storage import (ROOT, all_languages, create_project, find_block, list_projects, load_project, load_settings,
                      project_dir, save_project, save_settings)


def _project(pid: str) -> dict[str, Any]:
    try:
        return load_project(pid)
    except ValueError:
        abort(400, "Identificator invalid.")
    except FileNotFoundError:
        abort(404, "Proiectul nu există.")


def _editable(pid: str) -> dict[str, Any]:
    if jobs.active_for(pid):
        abort(409, "Așteaptă să se termine operația în curs.")
    return _project(pid)


def _public_settings(s: dict[str, Any]) -> dict[str, Any]:
    out = {k: v for k, v in s.items() if not k.endswith("_api_key")}
    out["has_claude_api_key"] = bool(s.get("claude_api_key"))
    out["has_openai_api_key"] = bool(s.get("openai_api_key"))
    return out


def _export_all(project: dict[str, Any], langs: list[str], progress=None) -> list[dict[str, Any]]:
    safe = "".join(c for c in Path(project["name"]).stem if c.isalnum() or c in "-_.()") or "document"
    results = []
    for lang in langs:
        if progress:
            progress(f"Export PDF {all_languages().get(lang, lang)}…")
        rel = f"exporturi/{safe}_{lang.upper()}.pdf"
        info = document.export_document(project, lang, project_dir(project["id"]) / rel)
        results.append({"lang": lang, "file": rel, **info})
    project["exports"] = results
    return results


def _exit_soon(delay: float = 0.8) -> None:
    """Oprește serverul după ce răspunsul a ajuns în browser."""
    import os
    import threading
    threading.Timer(delay, lambda: os._exit(0)).start()


def create_app() -> Flask:
    app = Flask(__name__, template_folder=str(ROOT / "templates"), static_folder=str(ROOT / "static"))
    app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024
    app.json.sort_keys = False  # păstrăm ordinea limbilor (română, engleză primele)

    @app.before_request
    def local_only():
        host = (request.host or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            abort(403, "Acces permis doar de pe acest calculator.")
        # Cererile care modifică date trebuie să vină din interfața aplicației (protecție CSRF).
        if request.method not in ("GET", "HEAD", "OPTIONS") and request.headers.get("X-Fise") != "1":
            abort(403, "Cerere respinsă: nu vine din aplicație.")

    @app.errorhandler(Exception)
    def on_error(e):
        if isinstance(e, HTTPException):
            return jsonify({"error": e.description}), e.code
        if isinstance(e, (ValueError, ai.AIError, FileNotFoundError, RuntimeError)):
            return jsonify({"error": str(e)}), 400
        app.logger.exception(e)
        return jsonify({"error": f"Eroare neașteptată: {e}"}), 500

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/state")
    def state():
        s = load_settings()
        return jsonify({"languages": all_languages(s), "projects": list_projects(), "settings": _public_settings(s),
                        "providers": {k: {"label": c.label, "kind": c.kind} for k, c in ai.PROVIDERS.items()},
                        "ai_modes": ai.AI_MODES, "version": update.current_version(),
                        "installed": update.installed_layout(),
                        "logos": {k: v["name"] for k, v in CATEGORIES.items()}})

    # ------------------------------------------------------------ AI
    @app.get("/api/ai/status")
    def ai_status():
        s = load_settings()
        out = {}
        for key in ai.PROVIDERS:
            try:
                out[key] = ai.get(key, s).status()
            except Exception as e:  # noqa: BLE001
                out[key] = {"ready": False, "installed": False, "logged_in": False, "message": str(e)}
        return jsonify(out)

    # ------------------------------------------------------------ versiune, actualizări, oprire
    @app.get("/api/update/check")
    def update_check():
        return jsonify(update.check())

    @app.post("/api/update/apply")
    def update_apply():
        if jobs.any_running():
            raise RuntimeError("Așteaptă să se termine operația în curs, apoi actualizează.")
        if not update.installed_layout():
            raise RuntimeError("Actualizarea automată merge doar la aplicația instalată cu instalatorul Windows. "
                               f"Descarcă versiunea nouă de la {update.PAGE}")
        info = update.download()
        update.restart_into_update()
        _exit_soon()
        return jsonify({"message": f"Se instalează versiunea {info['version']}. Pagina se reîncarcă singură.",
                        "version": info["version"]})

    @app.post("/api/shutdown")
    def shutdown():
        if jobs.any_running() and not (request.get_json(silent=True) or {}).get("force"):
            raise RuntimeError("O operație este încă în desfășurare. Închide aplicația după ce se termină.")
        _exit_soon()
        return jsonify({"message": "Aplicația s-a închis. Poți închide această filă."})

    @app.post("/api/ai/<key>/login")
    def ai_login(key: str):
        return jsonify({"message": ai.get(key, load_settings()).login()})

    @app.post("/api/ai/<key>/install")
    def ai_install(key: str):
        return jsonify({"message": ai.get(key, load_settings()).install()})

    @app.post("/api/ai/<key>/test")
    def ai_test(key: str):
        return jsonify({"message": ai.get(key, load_settings()).test()})

    @app.post("/api/settings")
    def settings_save():
        body = request.get_json(force=True) or {}
        s = load_settings()
        if body.get("ai_mode") in ai.AI_MODES:
            s["ai_mode"] = body["ai_mode"]
        for k in ("extract_provider", "translate_provider", "verify_provider"):
            if body.get(k) in ai.PROVIDERS:
                s[k] = body[k]
        for k in ("claude_cli_model", "codex_cli_model", "claude_api_model", "openai_api_model",
                  "claude_cli_path", "codex_cli_path"):
            if k in body:
                s[k] = str(body[k]).strip()[:300]
        if "visual_check" in body:
            s["visual_check"] = bool(body["visual_check"])
        if "timeout_seconds" in body:
            s["timeout_seconds"] = max(60, min(3600, int(body["timeout_seconds"])))
        for k in ("claude_api_key", "openai_api_key"):
            if body.get(k):
                s[k] = encrypt(str(body[k]).strip())
            if body.get(f"clear_{k}"):
                s[k] = ""
        save_settings(s)
        return jsonify(_public_settings(s))

    @app.post("/api/languages")
    def language_add():
        body = request.get_json(force=True) or {}
        code = str(body.get("code", "")).strip().lower()[:12]
        name = str(body.get("name", "")).strip()[:60]
        if not code or not name or not code.replace("-", "").isalnum():
            abort(400, "Scrie codul limbii (ex. ja) și numele ei (ex. Japoneză).")
        s = load_settings()
        s.setdefault("custom_languages", {})[code] = name
        save_settings(s)
        return jsonify({"languages": all_languages(s)})

    # ------------------------------------------------------------ proiecte
    @app.post("/api/projects")
    def project_new():
        """Un proiect per PDF: formular multipart cu `file`, `type`, `languages` (separate prin virgulă)."""
        f = request.files.get("file")
        if not f or not (f.filename or "").lower().endswith(".pdf"):
            abort(400, "Alege un fișier PDF.")
        name = Path((f.filename or "document.pdf").replace("\\", "/")).name
        langs = [l for l in request.form.get("languages", "").split(",") if l]
        p = create_project(Path(name).stem, request.form.get("type", "fisa"), langs,
                           request.form.get("replace_brand") == "1")
        try:
            sources.import_pdf(p, name, f.read())
        except ValueError:
            shutil.rmtree(project_dir(p["id"]), ignore_errors=True)
            raise
        save_project(p)
        return jsonify(p), 201

    @app.get("/api/projects/<pid>")
    def project_get(pid: str):
        p = _project(pid)
        p["_job"] = jobs.active_for(pid)
        return jsonify(p)

    @app.patch("/api/projects/<pid>")
    def project_patch(pid: str):
        p = _editable(pid)
        body = request.get_json(force=True) or {}
        if str(body.get("name", "")).strip():
            p["name"] = str(body["name"]).strip()[:160]
        if "languages" in body:
            langs = [l for l in dict.fromkeys(body["languages"]) if l in all_languages()]
            if not langs:
                abort(400, "Bifează cel puțin o limbă.")
            p["languages"] = langs
        if "replace_brand" in body:
            p["replace_brand"] = bool(body["replace_brand"])
        if body.get("logo_category") in CATEGORIES:
            p["logo_category"] = body["logo_category"]
        if "manufacturer_names" in body and p.get("doc"):
            p["doc"]["manufacturer_names"] = [n.strip() for n in str(body["manufacturer_names"]).split(",") if n.strip()]
        if body.get("source_language") in ("auto", "en", "zh", "ro"):
            p["source_language"] = body["source_language"]
        save_project(p)
        return jsonify(p)

    @app.delete("/api/projects/<pid>")
    def project_delete(pid: str):
        _editable(pid)
        shutil.rmtree(project_dir(pid), ignore_errors=True)
        return jsonify({"deleted": True})

    @app.get("/api/projects/<pid>/file/<path:rel>")
    def project_file(pid: str, rel: str):
        base = project_dir(pid).resolve()
        path = (base / rel).resolve()
        if base not in path.parents or not path.is_file():
            abort(404)
        return send_file(path, as_attachment=request.args.get("download") == "1")

    # ------------------------------------------------------------ operații
    @app.post("/api/projects/<pid>/run")
    def run(pid: str):
        _project(pid)
        body = request.get_json(force=True) or {}
        action = body.get("action")
        force = bool(body.get("force"))

        def work(project, progress):
            langs = [l for l in (body.get("languages") or project["languages"]) if l in all_languages()]
            out: dict[str, Any] = {}
            if action in ("scan", "all"):
                progress("Scanez documentul…")
                document.analyze(project, progress)
            if action in ("check", "all"):
                out["scan"] = document.verify_scan(project, progress)
            if action in ("translate", "all"):
                out["translated"] = tasks.translate(project, langs, progress, force=force)
            if action in ("verify", "all"):
                out["verification"] = tasks.verify_translations(project, langs, progress)
            if action in ("export", "all"):
                out["exports"] = _export_all(project, langs, progress)
            if action in ("qa", "all"):
                out["qa"] = checks.run_checks(project, langs, progress,
                                              use_ai=bool(load_settings().get("visual_check", True)))
            return out

        titles = {"scan": "Scanare", "check": "Verificare scanare", "translate": "Traducere",
                  "verify": "Verificare traduceri", "export": "Export PDF", "qa": "Verificarea PDF-urilor finale",
                  "all": "Scanare, verificare, traducere și export"}
        if action not in titles:
            abort(400, "Operație necunoscută.")
        return jsonify(jobs.start(pid, titles[action], work))

    @app.get("/api/jobs/<jid>")
    def job(jid: str):
        j = jobs.get(jid)
        if not j:
            abort(404, "Operația nu mai există (aplicația a fost repornită).")
        return jsonify(j)

    @app.get("/api/projects/<pid>/preview")
    def preview(pid: str):
        p = _project(pid)
        png = document.preview_page(p, request.args.get("lang", "ro"), int(request.args.get("page", 1)))
        return send_file(io.BytesIO(png), mimetype="image/png")

    # ------------------------------------------------------------ editare
    @app.put("/api/projects/<pid>/blocks/<bid>")
    def block_edit(pid: str, bid: str):
        """{lang, text}: corectură doar în limba aleasă; {src}: corectează originalul (toate limbile se
        retraduc); {reset: lang}: renunță la corectură; {skip}: nu traduce blocul; {size}: mărime font."""
        p = _editable(pid)
        b = find_block(p, bid)
        if not b:
            abort(404, "Textul nu există.")
        body = request.get_json(force=True) or {}
        if "replace" in body:  # zonă de branding
            b["replace"] = bool(body["replace"])
        elif "src" in body:
            new = str(body["src"])[:6000]
            if new != b["text"]["src"]:
                b.setdefault("manual_fix", {"before": b["text"]["src"]})
                b["text"]["src"] = new
                if not tasks.numbers(new) == tasks.numbers(b["manual_fix"]["before"]):
                    # valoare tehnică schimbată: traducerile vechi nu mai sunt valabile în nicio limbă
                    b["text"]["tr"], b["text"]["tr_src"] = {}, {}
        elif "reset" in body:
            b["text"].get("ov", {}).pop(body["reset"], None)
        elif "skip" in body:
            b["skip"] = bool(body["skip"])
        elif "size" in body:
            b["size"] = max(4.0, min(72.0, float(body["size"])))
        elif body.get("lang"):
            text = str(body.get("text", ""))[:6000]
            b["text"].setdefault("ov", {})[body["lang"]] = text
            b["text"].get("check", {}).pop(body["lang"], None)
            warn = b["text"].setdefault("warn", {})
            if tasks.numbers(b["text"]["src"]) != tasks.numbers(text):
                warn[body["lang"]] = "Cifrele diferă de original."
            else:
                warn.pop(body["lang"], None)
        else:
            abort(400, "Nimic de modificat.")
        save_project(p)
        return jsonify(p)

    return app
