"""Operații lungi (AI, export) rulate în fundal, cu progres afișat în interfață."""
from __future__ import annotations

import threading
import traceback
from typing import Any, Callable

from .storage import load_project, new_id, now, save_project

_jobs: dict[str, dict[str, Any]] = {}
_busy: dict[str, str] = {}  # project_id -> job_id
_lock = threading.Lock()


def start(project_id: str, title: str, work: Callable[[dict[str, Any], Callable[[str], None]], Any]) -> dict:
    with _lock:
        if project_id in _busy and _jobs[_busy[project_id]]["state"] == "running":
            raise RuntimeError("Proiectul are deja o operație în desfășurare. Așteaptă să se termine.")
        job = {"id": new_id(), "project_id": project_id, "title": title, "state": "running",
               "message": "Pornesc…", "started": now(), "result": None, "error": None, "steps": []}
        _jobs[job["id"]] = job
        _busy[project_id] = job["id"]

    def progress(msg: str) -> None:
        job["message"] = msg
        job["steps"].append(msg)

    def runner() -> None:
        try:
            project = load_project(project_id)
            job["result"] = work(project, progress)
            save_project(project)
            job["state"] = "done"
            job["message"] = "Gata."
        except Exception as e:  # noqa: BLE001 — orice eroare ajunge la utilizator ca mesaj
            job["state"] = "error"
            job["error"] = str(e) or e.__class__.__name__
            job["trace"] = traceback.format_exc()[-3000:]
        finally:
            job["finished"] = now()

    threading.Thread(target=runner, daemon=True).start()
    return job


def get(job_id: str) -> dict[str, Any] | None:
    job = _jobs.get(job_id)
    if not job:
        return None
    return {k: v for k, v in job.items() if k != "trace"}


def active_for(project_id: str) -> dict[str, Any] | None:
    jid = _busy.get(project_id)
    job = _jobs.get(jid) if jid else None
    return get(jid) if job and job["state"] == "running" else None


def any_running() -> bool:
    return any(j["state"] == "running" for j in _jobs.values())
