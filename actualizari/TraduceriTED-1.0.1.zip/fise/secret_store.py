"""Stocarea cheilor API: criptate cu Windows DPAPI (doar contul curent le poate citi).

Pe alte sisteme (folosit doar la dezvoltare) cheia e salvată codificat, cu avertisment.
"""
from __future__ import annotations

import base64
import sys

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    class _Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    def _to_blob(data: bytes):
        buf = (ctypes.c_byte * len(data)).from_buffer_copy(data)
        return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf

    def _protect(data: bytes, decrypt: bool) -> bytes:
        crypt, kernel = ctypes.windll.crypt32, ctypes.windll.kernel32
        src, keep = _to_blob(data)
        out = _Blob()
        fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
        ok = fn(ctypes.byref(src), None, None, None, None, 0x1, ctypes.byref(out))
        if not ok:
            raise ctypes.WinError()
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            kernel.LocalFree(out.pbData)
            del keep


def encrypt(secret: str) -> str:
    if not secret:
        return ""
    raw = secret.encode("utf-8")
    if sys.platform == "win32":
        return "dpapi:" + _protect(raw, False).hex()
    return "b64:" + base64.b64encode(raw).decode()


def decrypt(stored: str) -> str:
    if not stored:
        return ""
    kind, _, payload = stored.partition(":")
    try:
        if kind == "dpapi" and sys.platform == "win32":
            return _protect(bytes.fromhex(payload), True).decode("utf-8")
        if kind == "b64":
            return base64.b64decode(payload).decode("utf-8")
    except Exception:  # noqa: BLE001 — cheie coruptă / alt utilizator Windows
        return ""
    return ""
