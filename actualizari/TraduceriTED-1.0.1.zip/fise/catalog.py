"""Categorii de produse (cu șablonul Schema) și limbile disponibile."""
from __future__ import annotations

# Limbile de export. Se pot adăuga altele din aplicație (Setări -> Limbi).
LANGUAGES: dict[str, str] = {
    "ro": "Română",
    "en": "English",
    "hu": "Magyar",
    "bg": "Български",
    "de": "Deutsch",
    "fr": "Français",
    "it": "Italiano",
    "es": "Español",
    "pt": "Português",
    "pl": "Polski",
    "nl": "Nederlands",
    "el": "Ελληνικά",
    "cs": "Čeština",
    "sk": "Slovenčina",
    "sl": "Slovenščina",
    "hr": "Hrvatski",
    "sr": "Srpski",
    "uk": "Українська",
    "ru": "Русский",
    "tr": "Türkçe",
    "sv": "Svenska",
    "da": "Dansk",
    "fi": "Suomi",
    "no": "Norsk",
    "lt": "Lietuvių",
    "lv": "Latviešu",
    "et": "Eesti",
}

SOURCE_LANGUAGES = {"auto": "Detectare automată", "zh": "Chineză", "en": "Engleză", "ro": "Română"}

# Nume în engleză pentru instrucțiunile către AI.
LANGUAGE_ENGLISH_NAMES = {
    "ro": "Romanian", "en": "English", "hu": "Hungarian", "bg": "Bulgarian", "de": "German",
    "fr": "French", "it": "Italian", "es": "Spanish", "pt": "Portuguese", "pl": "Polish",
    "nl": "Dutch", "el": "Greek", "cs": "Czech", "sk": "Slovak", "sl": "Slovenian",
    "hr": "Croatian", "sr": "Serbian (Latin script)", "uk": "Ukrainian", "ru": "Russian",
    "tr": "Turkish", "sv": "Swedish", "da": "Danish", "fi": "Finnish", "no": "Norwegian",
    "lt": "Lithuanian", "lv": "Latvian", "et": "Estonian", "zh": "Chinese",
}

CATEGORIES: dict[str, dict] = {
    "cables": {
        "name": "Cabluri", "schema": "Schema_Cabluri.pdf",
        "sections": ["CONSTRUCTION", "GENERAL CHARACTERISTICS", "ELECTRICAL PERFORMANCE"],
    },
    "stabilizers": {
        "name": "Stabilizatoare", "schema": "Schema_Stabilizatoare.pdf",
        "sections": ["SPECIFICATIONS", "INPUT", "OUTPUT", "GENERAL CHARACTERISTICS", "PACKING INFORMATION"],
    },
    "batteries": {
        "name": "Acumulatori (plumb/AGM/GEL)", "schema": "Schema_Acumulatori.pdf",
        "sections": ["PHYSICAL SPECIFICATIONS", "PRODUCT SPECIFICATIONS", "CONSTANT CURRENT DISCHARGE",
                     "CONSTANT POWER DISCHARGE", "PRODUCT DIMENSIONS"],
    },
    "ups": {
        "name": "UPS", "schema": "Schema UPS.pdf",
        "sections": ["SPECIFICATIONS", "INPUT", "OUTPUT", "GENERAL CHARACTERISTICS"],
    },
    "solar_inverters": {
        "name": "Invertoare solare", "schema": "Schema Invertoare Solare.pdf",
        "sections": ["SPECIFICATIONS", "INPUT", "OUTPUT", "BATTERY", "SOLAR CHARGER & AC CHARGER",
                     "ENVIRONMENT", "PRODUCT DIMENSIONS"],
    },
    "automotive_inverters": {
        "name": "Invertoare auto", "schema": "Schema_Invertore Automotive.pdf",
        "sections": ["SPECIFICATIONS", "INPUT & OUTPUT", "GENERAL CHARACTERISTICS", "PACKING INFORMATION"],
    },
    "lifepo4_batteries": {
        "name": "Acumulatori LiFePO4", "schema": "Schema_Acumulatori_LiFePO4.pdf",
        "sections": ["SPECIFICATIONS", "PRODUCT DETAILS", "SYSTEM DESIGN"],
    },
    "lfp_storage": {
        "name": "Sisteme de stocare LFP (LiFePO4)", "schema": "Schema_LFP_LiFePO4.pdf",
        "sections": ["SPECIFICATIONS", "PRODUCT DETAILS", "BMS PARAMETERS", "DISCHARGE DATA"],
    },
}

# Textele fixe ale fișei (se traduc o dată per limbă și se pot corecta).
FIXED_TEXTS = {
    "technical_data_sheet": "TECHNICAL DATA SHEET",
    "part_number": "Part number",
    "disclaimer": "Product specifications are subject to change without further notice.",
}
