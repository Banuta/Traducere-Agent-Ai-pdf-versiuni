﻿# Instalează Codex CLI (ChatGPT) pentru utilizatorul curent, fără drepturi de administrator.
# 1) varianta de sine stătătoare de pe GitHub (nu are nevoie de Node.js);
# 2) dacă nu merge: Node.js LTS (winget) + npm install -g @openai/codex.
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Dest = Join-Path $env:LOCALAPPDATA "Programs\codex"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null

function Done {
    Write-Host ""
    Write-Host "Gata: Codex este instalat. Inchide fereastra si apasa 'Verifica' in aplicatie." -ForegroundColor Green
    exit 0
}

Write-Host "Instalez Codex (ChatGPT)..." -ForegroundColor Cyan
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "aarch64" } else { "x86_64" }
$names = @("codex-$arch-pc-windows-msvc.exe.zip", "codex-$arch-pc-windows-msvc.zip")
foreach ($n in $names) {
    try {
        $zip = Join-Path $env:TEMP $n
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/openai/codex/releases/latest/download/$n" -OutFile $zip
        $tmp = Join-Path $env:TEMP "codex-extract"
        Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
        Expand-Archive -Force $zip $tmp
        $exe = Get-ChildItem $tmp -Recurse -Filter "*.exe" | Where-Object { $_.Name -like "codex*" } | Select-Object -First 1
        if ($exe) {
            Copy-Item -Force $exe.FullName (Join-Path $Dest "codex.exe")
            Remove-Item -Force $zip -ErrorAction SilentlyContinue
            & (Join-Path $Dest "codex.exe") --version
            Done
        }
    } catch {
        Write-Host "  ($n nu a mers: $($_.Exception.Message))" -ForegroundColor DarkGray
    }
}

Write-Host "Varianta directa nu a mers; instalez prin Node.js." -ForegroundColor Yellow
$npm = Get-Command npm -ErrorAction SilentlyContinue
if (-not $npm) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install -e --id OpenJS.NodeJS.LTS --scope user --accept-source-agreements --accept-package-agreements
        $env:Path = [Environment]::GetEnvironmentVariable("Path", "User") + ";" + [Environment]::GetEnvironmentVariable("Path", "Machine")
        $npm = Get-Command npm -ErrorAction SilentlyContinue
    }
}
if (-not $npm) {
    Write-Host "Nu am putut instala Node.js automat. Instaleaza-l de pe https://nodejs.org (varianta LTS) si apasa din nou 'Instaleaza Codex'." -ForegroundColor Red
    Start-Process "https://nodejs.org/"
    exit 1
}
& npm install -g @openai/codex
if ($LASTEXITCODE -eq 0) { Done }
Write-Host "Instalarea a esuat. Trimite captura acestei ferestre." -ForegroundColor Red
exit 1
