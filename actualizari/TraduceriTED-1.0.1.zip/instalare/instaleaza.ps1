﻿# Instalare completa "Traduceri TED" pe un PC Windows (10 sau 11), chiar daca nu are nimic instalat.
# Pornit din INSTALEAZA.bat. Nu cere drepturi de administrator: totul se instaleaza pentru utilizatorul curent.
# (Mesajele sunt fara diacritice ca sa se vada corect in orice fereastra PowerShell.)

$ErrorActionPreference = "Continue"   # verificam singuri $LASTEXITCODE
$ProgressPreference = "SilentlyContinue"   # descarcarile sunt mult mai rapide fara bara de progres
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$App = Split-Path -Parent $PSScriptRoot
Set-Location $App
$PyVersion = "3.12.10"
$PyUrl = "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-amd64.exe"

function Titlu($t) { Write-Host ""; Write-Host "=== $t ===" -ForegroundColor Cyan }
function Ok($t)    { Write-Host "  [OK] $t" -ForegroundColor Green }
function Info($t)  { Write-Host "  $t" }
function Atentie($t) { Write-Host "  [!] $t" -ForegroundColor Yellow }
function Intreaba($t) {
    $r = Read-Host "  $t (D/N)"
    return ($r -match '^[dDyY]')
}
function Actualizeaza-Path {
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
}

# ------------------------------------------------------------------ 1. Python
function Gaseste-Python {
    $candidati = @()
    foreach ($v in "313", "312", "311") {
        $candidati += "$env:LOCALAPPDATA\Programs\Python\Python$v\python.exe"
        $candidati += "$env:ProgramFiles\Python$v\python.exe"
    }
    foreach ($c in $candidati) { if (Test-Path $c) { return $c } }
    # "py" (launcher-ul oficial) sau "python" din PATH — dar nu scurtatura falsa din Microsoft Store
    foreach ($cmd in @(@("py", "-3"), @("python"))) {
        try {
            $exe = $cmd[0]; $args0 = @(); if ($cmd.Count -gt 1) { $args0 = $cmd[1..($cmd.Count - 1)] }
            if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
            $out = & $exe @args0 -c "import sys; print(sys.version_info[0], sys.version_info[1], sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $out) {
                $p = "$out".Split(" ", 3)
                if ([int]$p[0] -eq 3 -and [int]$p[1] -ge 11 -and [int]$p[1] -le 13) { return $p[2].Trim() }
            }
        } catch { }
    }
    return $null
}

try {
Titlu "1/5 Python"
$Python = Gaseste-Python
if ($Python) {
    Ok "Python gasit: $Python"
} else {
    Info "Python nu este instalat. Il instalez acum (Python $PyVersion, doar pentru utilizatorul curent)..."
    $instalat = $false
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        try {
            winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host
            Actualizeaza-Path
            $Python = Gaseste-Python
            $instalat = [bool]$Python
        } catch { Atentie "winget nu a reusit, incerc direct de pe python.org." }
    }
    if (-not $instalat) {
        $kit = Join-Path $env:TEMP "python-$PyVersion-amd64.exe"
        Info "Descarc $PyUrl ..."
        Invoke-WebRequest -Uri $PyUrl -OutFile $kit -UseBasicParsing -ErrorAction Stop
        Info "Instalez (dureaza 1-2 minute)..."
        $p = Start-Process -FilePath $kit -ArgumentList "/quiet", "InstallAllUsers=0", "PrependPath=1",
            "Include_launcher=1", "Include_test=0", "Include_doc=0" -Wait -PassThru -ErrorAction Stop
        Remove-Item $kit -ErrorAction SilentlyContinue
        if ($p.ExitCode -ne 0) { throw "Instalarea Python a esuat (cod $($p.ExitCode))." }
        Actualizeaza-Path
        $Python = Gaseste-Python
    }
    if (-not $Python) { throw "Python a fost instalat, dar nu il gasesc. Reporneste PC-ul si ruleaza din nou INSTALEAZA.bat." }
    Ok "Python instalat: $Python"
}

# ------------------------------------------------------------------ 2. pachetele aplicatiei
Titlu "2/5 Pachetele aplicatiei"
$Venv = Join-Path $App ".venv\Scripts\python.exe"
if (-not (Test-Path $Venv)) {
    Info "Creez mediul aplicatiei (.venv)..."
    & $Python -m venv (Join-Path $App ".venv")
    if ($LASTEXITCODE -ne 0) { throw "Nu am putut crea mediul .venv." }
}
Info "Instalez 3 pachete (Flask, PyMuPDF, Pillow) - de obicei 1-2 minute."
Info "Daca antivirusul scaneaza fiecare fisier, poate dura mai mult. Nu inchide fereastra."
for ($i = 1; $i -le 3; $i++) {
    & $Venv -m pip install -r (Join-Path $App "requirements.txt") --disable-pip-version-check `
        --only-binary=:all: --progress-bar on --no-input
    if ($LASTEXITCODE -eq 0) {
        # PyMuPDF fără pachetele opționale mari (onnxruntime, numpy): instalarea durează mult mai puțin
        & $Venv -m pip install --no-deps -r (Join-Path $App "requirements-pdf.txt") --disable-pip-version-check `
            --only-binary=:all: --progress-bar on --no-input
    }
    if ($LASTEXITCODE -eq 0) { break }
    if ($i -eq 3) { throw "Instalarea pachetelor a esuat. Verifica internetul si ruleaza din nou INSTALEAZA.bat." }
    Atentie "Incerc din nou ($i/3)..."
    Start-Sleep -Seconds 3
}
& $Venv -c "import flask, pymupdf, PIL" 2>$null
if ($LASTEXITCODE -ne 0) { throw "Pachetele nu se pot incarca. Ruleaza din nou INSTALEAZA.bat." }
Ok "Pachetele sunt instalate."

# ------------------------------------------------------------------ 3. Claude Code (abonament Claude)
function Gaseste-Claude {
    foreach ($c in "$env:USERPROFILE\.local\bin\claude.exe", "$env:APPDATA\npm\claude.cmd") { if (Test-Path $c) { return $c } }
    $g = Get-Command claude -ErrorAction SilentlyContinue
    if ($g) { return $g.Source }
    return $null
}

Titlu "3/5 Ce AI folosesti?"
Info "1 = doar Claude        (abonament Claude Pro/Max)"
Info "2 = doar ChatGPT       (abonament ChatGPT Plus/Pro, prin Codex)"
Info "3 = ambele             (Claude traduce, ChatGPT verifica)"
Info "4 = niciunul acum      (il alegi mai tarziu din aplicatie: Conectare AI)"
$alegere = ""
while ($alegere -notmatch '^[1-4]$') { $alegere = (Read-Host "  Alege 1, 2, 3 sau 4").Trim() }
$VreauClaude = $alegere -in "1", "3"
$VreauCodex = $alegere -in "2", "3"
$mod = @{ "1" = "claude"; "2" = "codex"; "3" = "ambele"; "4" = "ambele" }[$alegere]
& $Venv (Join-Path $App "app.py") --ai $mod | Out-Null

$Claude = Gaseste-Claude
if ($VreauClaude -and -not $Claude) {
    Info "Instalez Claude Code..."
    try {
        Start-Process powershell -Wait -NoNewWindow -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-Command", "irm https://claude.ai/install.ps1 | iex"
        Actualizeaza-Path
        $Claude = Gaseste-Claude
    } catch { Atentie "Instalarea Claude Code nu a reusit: $($_.Exception.Message)" }
}
if ($VreauClaude -and $Claude) {
    Ok "Claude Code: $Claude"
    $stare = & $Claude auth status 2>$null | Out-String
    if ($stare -match '"loggedIn":\s*true') {
        Ok "Esti deja conectat la Claude."
    } elseif (Intreaba "Te conectezi acum la contul Claude? (se deschide browserul)") {
        & $Claude auth login
        Ok "Logare Claude terminata."
    }
}

# ------------------------------------------------------------------ 4. Codex (abonament ChatGPT)
function Gaseste-Codex {
    foreach ($c in "$env:APPDATA\npm\codex.cmd") { if (Test-Path $c) { return $c } }
    $g = Get-Command codex -ErrorAction SilentlyContinue
    if ($g) { return $g.Source }
    return $null
}

Titlu "4/5 Instalare si logare AI"
$Codex = Gaseste-Codex
if ($VreauCodex -and -not $Codex) {
    Info "Instalez Codex..."
    try {
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
            if (Get-Command winget -ErrorAction SilentlyContinue) {
                Info "Instalez Node.js (necesar pentru Codex)..."
                winget install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements | Out-Host
                Actualizeaza-Path
                $env:Path += ";$env:ProgramFiles\nodejs;$env:APPDATA\npm"
            } else {
                Start-Process "https://nodejs.org/"
                throw "Instaleaza Node.js (varianta LTS) de pe nodejs.org, apoi ruleaza din nou INSTALEAZA.bat."
            }
        }
        & npm install -g @openai/codex | Out-Host
        Actualizeaza-Path
        $env:Path += ";$env:APPDATA\npm"
        $Codex = Gaseste-Codex
    } catch { Atentie "Instalarea Codex nu a reusit: $($_.Exception.Message)" }
}
if ($VreauCodex -and $Codex) {
    Ok "Codex: $Codex"
    & $Codex login status *> $null
    if ($LASTEXITCODE -eq 0) {
        Ok "Esti deja conectat la ChatGPT."
    } elseif (Intreaba "Te conectezi acum la contul ChatGPT? (se deschide browserul)") {
        & $Codex login
        Ok "Logare ChatGPT terminata."
    }
}
if ($alegere -eq "4") { Info "Ai sarit peste AI. In aplicatie apasa ""Conectare AI"" (sus, in dreapta)." }

# ------------------------------------------------------------------ 5. scurtatura pe Desktop
Titlu "5/5 Scurtatura pe Desktop"
try {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $sh = New-Object -ComObject WScript.Shell
    $lnk = $sh.CreateShortcut((Join-Path $desktop "Traduceri TED.lnk"))
    $lnk.TargetPath = Join-Path $App "PORNESTE.bat"
    $lnk.WorkingDirectory = $App
    $lnk.IconLocation = "$env:SystemRoot\System32\shell32.dll,165"
    $lnk.Description = "Traduceri TED - fise tehnice si manuale"
    $lnk.Save()
    Ok "Pe Desktop ai acum iconita ""Traduceri TED""."
} catch { Atentie "Nu am putut crea scurtatura: $($_.Exception.Message)" }

Write-Host ""
Write-Host "Instalarea s-a terminat." -ForegroundColor Green
if (-not ($VreauClaude -and $Claude) -and -not ($VreauCodex -and $Codex)) {
    Atentie "Nu ai conectat niciun AI. In aplicatie apasa ""Conectare AI"" (sus, in dreapta)."
}
if (Intreaba "Pornesc aplicatia acum?") {
    Start-Process -FilePath (Join-Path $App "PORNESTE.bat") -WorkingDirectory $App
}
exit 0
} catch {
    Write-Host ""
    Write-Host "  EROARE: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Verifica conexiunea la internet si ruleaza din nou INSTALEAZA.bat." -ForegroundColor Red
    exit 1
}
