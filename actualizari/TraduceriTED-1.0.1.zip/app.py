"""Pornește aplicația Traduceri TED: python app.py (sau TraduceriTED.exe, după instalare)."""
from __future__ import annotations

import argparse
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

APP = Path(__file__).resolve().parent


def _free(port: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def _log_to_file() -> None:
    """Pornită fără fereastră (pythonw.exe): mesajele merg în data/aplicatie.log. Cu fereastră: diacriticele
    nu trebuie să oprească aplicația pe consolele Windows vechi (cp1252/cp852)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):
            pass
    if sys.stdout is not None and sys.stderr is not None:
        return
    from fise.storage import DATA
    DATA.mkdir(parents=True, exist_ok=True)
    f = open(DATA / "aplicatie.log", "a", encoding="utf-8", errors="replace", buffering=1)  # noqa: SIM115
    sys.stdout = sys.stdout or f
    sys.stderr = sys.stderr or f


def main() -> None:
    ap = argparse.ArgumentParser(description="Traduceri TED — aplicație locală")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--after-update", action="store_true", help="pornire după o actualizare (intern)")
    ap.add_argument("--ai", choices=["claude", "codex", "ambele"],
                    help="salvează ce AI folosești (folosit de instalator) și iese")
    args = ap.parse_args()
    _log_to_file()
    if args.ai:
        from fise.storage import load_settings, save_settings
        s = load_settings()
        s["ai_mode"] = args.ai
        save_settings(s)
        print(f"AI ales: {args.ai}")
        return
    url = f"http://127.0.0.1:{args.port}"
    if args.after_update:  # așteptăm să se oprească versiunea veche, apoi aplicăm actualizarea
        for _ in range(60):
            if _free(args.port):
                break
            time.sleep(0.5)
        from fise import update
        update.apply_pending()
    if not _free(args.port):
        print(f"Aplicația rulează deja: {url}")
        webbrowser.open(url)
        return
    from fise.web import create_app  # după actualizare: se încarcă codul nou
    if not args.no_browser and not args.after_update:  # după actualizare, pagina deschisă se reîncarcă singură
        threading.Thread(target=lambda: (time.sleep(1.2), webbrowser.open(url)), daemon=True).start()
    print(f"Traduceri TED rulează la {url}")
    create_app().run(host="127.0.0.1", port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
