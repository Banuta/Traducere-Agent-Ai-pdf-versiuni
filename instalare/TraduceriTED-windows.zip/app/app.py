"""Pornește aplicația Traduceri TED: python app.py (sau iconița „Traduceri TED”, după instalare)."""
from __future__ import annotations

import argparse
import json
import socket
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

APP = Path(__file__).resolve().parent
DEFAULT_PORT = 47321  # port rar folosit; dacă e ocupat de alt program, aplicația alege singură altul liber


def _can_bind(port: int) -> bool:
    """Portul e liber și Windows ne lasă să-l folosim (unele porturi sunt rezervate de Hyper-V / WSL)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def _available(port: int) -> bool:
    """Nimeni nu ascultă pe port și îl putem ocupa noi."""
    with socket.socket() as s:
        s.settimeout(1)
        if s.connect_ex(("127.0.0.1", port)) == 0:
            return False  # alt program (sau Traduceri TED) răspunde deja aici
    return _can_bind(port)


def _is_ours(port: int) -> bool:
    """Pe portul acesta rulează chiar Traduceri TED (nu alt program)?"""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=2) as r:  # noqa: S310
            return json.loads(r.read().decode("utf-8")).get("app") == "traduceri-ted"
    except Exception:  # noqa: BLE001
        return False


def _log_to_file() -> None:
    """Pornită fără fereastră (pythonw.exe): mesajele merg în data/aplicatie.log. Cu fereastră: diacriticele
    nu trebuie să oprească aplicația pe consolele Windows vechi (cp1252/cp852)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):
            pass
    if sys.stdout is not None and sys.stderr is not None:
        return
    from fise.storage import DATA
    DATA.mkdir(parents=True, exist_ok=True)
    f = open(DATA / "aplicatie.log", "a", encoding="utf-8", errors="replace", buffering=1)  # noqa: SIM115
    sys.stdout = sys.stdout or f
    sys.stderr = sys.stderr or f


def main() -> None:
    ap = argparse.ArgumentParser(description="Traduceri TED — aplicație locală")
    ap.add_argument("--port", type=int, default=0, help=f"portul local (implicit din Setări sau {DEFAULT_PORT})")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--after-update", action="store_true", help="pornire după o actualizare (intern)")
    ap.add_argument("--ai", choices=["claude", "codex", "ambele"],
                    help="salvează ce AI folosești (folosit de instalator) și iese")
    args = ap.parse_args()
    _log_to_file()
    from fise.storage import DATA, load_settings, save_settings
    if args.ai:
        s = load_settings()
        s["ai_mode"] = args.ai
        save_settings(s)
        print(f"AI ales: {args.ai}")
        return

    settings = load_settings()
    port = args.port or int(settings.get("port") or DEFAULT_PORT)
    if args.after_update:  # așteptăm să se oprească versiunea veche, apoi aplicăm actualizarea
        for _ in range(60):
            if _available(port):
                break
            time.sleep(0.5)
        from fise import update
        update.apply_pending()
    if not _available(port):
        if _is_ours(port):  # rulează deja: doar deschidem browserul
            print(f"Aplicația rulează deja: http://127.0.0.1:{port}")
            webbrowser.open(f"http://127.0.0.1:{port}")
            return
        # portul e folosit de alt program: căutăm unul liber și îl ținem minte (aceeași adresă data viitoare)
        old = port
        port = next((p for p in range(old + 1, old + 200) if _available(p)), 0)
        if not port:
            raise SystemExit(f"Nu găsesc niciun port liber după {old}. Alege altul din Setări.")
        print(f"Portul {old} e folosit de alt program; folosesc {port}.")
        settings = load_settings()
        settings["port"] = port
        save_settings(settings)
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / "port.txt").write_text(str(port), encoding="utf-8")  # pentru instalator / dezinstalator

    url = f"http://127.0.0.1:{port}"
    from fise.web import create_app  # după actualizare: se încarcă codul nou
    if not args.no_browser and not args.after_update:  # după actualizare, pagina deschisă se reîncarcă singură
        threading.Thread(target=lambda: (time.sleep(1.2), webbrowser.open(url)), daemon=True).start()
    print(f"Traduceri TED rulează la {url}")
    create_app().run(host="127.0.0.1", port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
