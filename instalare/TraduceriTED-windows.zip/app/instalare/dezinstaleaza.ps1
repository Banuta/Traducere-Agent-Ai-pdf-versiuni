# Traduceri TED - dezinstalare. Documentele tale (folderul data) raman, daca nu ceri altfel.
& {
    $Dir = Join-Path $env:LOCALAPPDATA "Programs\TraduceriTED"
    Set-Location $env:TEMP
    Write-Host ""
    Write-Host "  Traduceri TED - dezinstalare" -ForegroundColor White
    function Stop-TraduceriTED {
        # portul folosit acum (data\port.txt), apoi cel implicit si cel vechi (8765, versiunile 1.0.x)
        $ports = @()
        $pf = Join-Path $Dir "data\port.txt"
        if (Test-Path $pf) { try { $ports += [int]((Get-Content $pf -Raw).Trim()) } catch { } }
        $ports += 47321, 8765
        foreach ($port in ($ports | Select-Object -Unique)) {
            try {
                # oprim doar daca pe port raspunde chiar Traduceri TED, nu alt program
                $st = (Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/api/state" -TimeoutSec 3).Content | ConvertFrom-Json
                if ($null -ne $st.ai_modes) {
                    Invoke-WebRequest -UseBasicParsing -Method Post -Uri "http://127.0.0.1:$port/api/shutdown" `
                        -Headers @{ "X-Fise" = "1" } -ContentType "application/json" -Body '{"force": true}' -TimeoutSec 5 | Out-Null
                    Start-Sleep -Seconds 3
                }
            } catch { }
        }
    }
    Stop-TraduceriTED
    foreach ($d in @("app", "python", "update", "_nou")) {
        $p = Join-Path $Dir $d
        if (Test-Path $p) { Remove-Item -Recurse -Force $p -ErrorAction SilentlyContinue }
    }
    foreach ($f in @("icon.ico", "TraduceriTED.exe", "Dezinstaleaza.exe", "descarcare.zip")) {
        $p = Join-Path $Dir $f
        if (Test-Path $p) { Remove-Item -Force $p -ErrorAction SilentlyContinue }
    }
    Remove-Item -Force (Join-Path ([Environment]::GetFolderPath("Desktop")) "Traduceri TED.lnk") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path ([Environment]::GetFolderPath("Programs")) "Traduceri TED") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TraduceriTED" -ErrorAction SilentlyContinue

    $data = Join-Path $Dir "data"
    if (Test-Path $data) {
        $r = Read-Host "  Stergi si documentele tale (proiecte, traduceri, setari)? D/N [N]"
        if ($r -match "^[DdYy]") {
            Remove-Item -Recurse -Force $data -ErrorAction SilentlyContinue
            Remove-Item -Force $Dir -ErrorAction SilentlyContinue
        } else {
            Write-Host "  Documentele raman in $data" -ForegroundColor Gray
        }
    } else {
        Remove-Item -Force $Dir -ErrorAction SilentlyContinue
    }
    Write-Host "  Traduceri TED a fost dezinstalat." -ForegroundColor Green
    Read-Host "  Apasa Enter pentru a inchide"
}
