# Traduceri TED: fișe tehnice și manuale

Aplicație locală pentru Windows. Pui un PDF (fișă tehnică sau manual) în engleză și primești **același document**, cu toate pozele, schemele, tabelele, culorile și logo-urile, tradus în limbile alese.

Fluxul, pentru fiecare PDF:

1. **Scanare**: se citește tot textul paginilor, cu poziția, mărimea și culoarea lui.
2. **Verificare**: un al doilea AI compară textul citit cu imaginea paginii și corectează greșelile de citire (litere, majuscule, cifre, unități).
3. **Traducere**: fiecare limbă se traduce direct din originalul verificat.
4. **Export**: textul vechi se șterge din locul lui și se scrie traducerea în același loc. Rezultatul e câte un PDF pentru fiecare limbă.

Datele rămân pe calculatorul tău, în folderul `data`. Documentele sunt trimise doar către AI-ul pe care îl conectezi tu.

---

## 1. Instalare (o singură dată)

Windows 10 sau 11, cu internet. **Nu trebuie instalat nimic înainte** (Python și pachetele sunt incluse) și nu sunt necesare drepturi de administrator.

1. Apasă **Start**, scrie **PowerShell** și apasă **Enter**.
2. Copiază rândul de mai jos, lipește-l în fereastra albastră (clic dreapta) și apasă **Enter**:

   ```powershell
   irm https://raw.githubusercontent.com/Banuta/Traducere-Agent-Ai-pdf-versiuni/main/instaleaza.ps1 | iex
   ```

3. Scriptul descarcă programul (~50 MB), îl verifică (sha256) și te întreabă:
   - **ce AI folosești**: 1 = doar Claude, 2 = doar ChatGPT, 3 = ambele (recomandat), 4 = aleg mai târziu;
   - dacă să instaleze acum și **programul de conectare** (Claude Code / Codex, programele oficiale). Pentru Codex nu e nevoie de Node.js.
4. La final, aplicația se deschide în browser (`http://127.0.0.1:47321`). Pe Desktop apare iconița **„Traduceri TED”**.

**De ce o comandă și nu un fișier `.exe`?** Un `.exe` fără semnătură digitală plătită produce alerta Windows SmartScreen „Windows a protejat PC-ul / Don't run” și, des, alerte antivirus false. Cu această comandă nu se descarcă niciun `.exe` nesemnat: programul rulează cu Python-ul oficial, semnat digital de Python Software Foundation. Este același mod în care se instalează Claude Code.

Aceeași comandă **reinstalează sau repară** programul oricând, păstrând documentele și setările.

Unde se instalează: `%LOCALAPPDATA%\Programs\TraduceriTED` (`app` = programul, `python` = Python inclus, `data` = documentele și setările tale).
Dezinstalare: Start → Traduceri TED → „Dezinstaleaza Traduceri TED”, sau Setări Windows → Aplicații. Documentele rămân, dacă nu ceri altfel.

Aplicația rulează fără fereastră neagră. O oprești din butonul **„⏻ Închide aplicația”** (stânga jos).

**Portul (numărul de la sfârșitul adresei, implicit 47321):** dacă e ocupat de alt program, aplicația alege singură următorul port liber și îl ține minte. Îl poți schimba și manual din **⚙ Setări → Adresa aplicației (port)**; portul nou se folosește după ce închizi și pornești din nou aplicația.

## 2. Conectarea AI (o singură dată)

La prima pornire se deschide singură fereastra **„Conectare AI”** (o găsești oricând în stânga jos). Pentru fiecare AI ales:

1. **„⬇ Instalează”**, doar dacă nu l-ai instalat din instalator;
2. **„Conectează-te cu contul”**: se deschide logarea în browser; te loghezi cu contul tău Claude sau ChatGPT;
3. **„Verifică”**: punctul devine verde. Cu **„Test”** confirmi că AI-ul răspunde.

Aplicația nu vede și nu salvează parola contului.

### Variante de folosire

Sus în fereastra „Conectare AI” alegi (se poate schimba oricând):

| Variantă | Cine scanează și traduce | Cine verifică |
|---|---|---|
| **Doar Claude** | Claude | Claude |
| **Doar ChatGPT** | ChatGPT (Codex) | ChatGPT (Codex) |
| **Ambele** (recomandat) | Claude | ChatGPT: verificare independentă. Dacă unul nu e conectat, celălalt face tot. |
| **Avansat** | aleg eu pentru fiecare pas | aleg eu |

### Instalare manuală a programelor de conectare (dacă butonul nu merge)

| Abonament | În PowerShell |
|---|---|
| **Claude Pro / Max** | `irm https://claude.ai/install.ps1 \| iex` |
| **ChatGPT Plus / Pro** | Node.js de pe <https://nodejs.org>, apoi `npm install -g @openai/codex` |

### Cu cheie API (opțional, plată pe consum)

Lipești cheia de la <https://console.anthropic.com> sau <https://platform.openai.com> și o salvezi. Cheia este criptată cu Windows DPAPI.

Cheile API sunt opționale; pachetele pentru ele se instalează automat la prima folosire.

## Actualizări

Aplicația verifică la fiecare pornire dacă există o versiune nouă. Dacă există, sus apare **„⟳ Versiune nouă”**: apeși, citești ce e nou și apeși **„Actualizează acum”**. Aplicația descarcă actualizarea, o verifică (sha256), repornește singură în ~10 secunde și pagina se reîncarcă. Documentele și setările nu se ating. Verificarea manuală: **„⟳ Actualizări”**, în stânga jos.

Versiunile sunt publicate în <https://github.com/Banuta/Traducere-Agent-Ai-pdf-versiuni> (`latest.json` + pachetele din `actualizari/`). Codul complet este în <https://github.com/Banuta/Traducere-automata-PDF->.

## 3. Folosire

1. **+ Document nou**, apoi alegi **Fișe tehnice** sau **Manuale**.
2. Tragi unul sau mai multe PDF-uri. Fiecare devine un document separat și se procesează pe rând.
3. Bifezi limbile (27 incluse, altele se adaugă din Setări), apoi **Scanează, verifică, tradu și exportă**.

La final se deschide fila **Export PDF**, cu câte un PDF pe limbă: previzualizare și descărcare.

### Fila „Pagini”

Pentru fiecare pagină vezi **originalul lângă rezultat** și lista textelor.
- În modul **Original** corectezi textul sursă. La următorul „Tradu” se retraduce în toate limbile.
- Într-o limbă (de ex. Română) corectezi doar traducerea din limba aceea. Corectura e marcată „corectat” și **rămâne și la retraducere**. Butonul ↺ o anulează.
- **„nu traduce”** lasă un text exact cum e în original (de exemplu un nume de produs).

### Verificările (automat, la fiecare document)

1. **Verificarea scanării**: un al doilea AI compară textul citit cu imaginea paginii, corectează greșelile de citire, găsește textele lipsă și elimină textul vechi ascuns în fișier (de exemplu valorile unei fișe vechi rămase sub cea nouă).
2. **Verificarea traducerilor**: termeni tehnici, sens, cifre, cuvinte rămase netraduse. Corectura propusă se aplică automat (dacă nu schimbă cifrele și dacă nu ai corectat tu textul); varianta veche se vede în fila Verificare.
3. **Verificarea PDF-urilor finale**, după export, pe fiecare limbă și fiecare pagină:
   - **cifre**: fiecare valoare tradusă apare în pagină;
   - **suprapuneri**: texte scrise unul peste altul (fără cele care se suprapun deja în original);
   - **text rămas**: textul original rămas netradus sub traducere;
   - **text ascuns**: date vechi invizibile rămase în fișier;
   - **verificare vizuală cu AI**: un AI compară pagina originală cu cea tradusă, ca un corector de tipar. Se poate opri din Setări.

Rezultatele apar în fila **Verificare**, cu link spre pagină.

### Fila „Verificare”

- Ce a corectat AI-ul la verificarea scanării (înainte → după).
- Observațiile de la verificarea traducerilor: ce s-a corectat automat (înainte → după) și sugestiile neaplicate.
- ⚠ cifrele care diferă între original și traducere.

### Reguli care protejează datele

- Valorile tehnice (12.8V, 300Ah, -20 ~ 60°C, TED007438) nu se trimit la traducere și rămân identice în toate limbile.
- Dacă o traducere schimbă o cifră, rândul e marcat ⚠.
- Originalul importat nu se modifică niciodată; îl găsești în `data\proiecte\<id>\surse\`.

## 4. Ce tipuri de PDF merg

| Tipul paginii | Exemplu | Ce face aplicația |
|---|---|---|
| Text selectabil | manuale din InDesign | poziție și text exacte |
| Text desenat (contururi) | fișe din Illustrator / CorelDRAW | poziție, mărime și culoare exacte, din conturul literelor; textul e citit și verificat de AI |
| Pagină scanată (imagine) | manualul UPS | AI-ul citește textul din imagine; pozițiile sunt aproximative, deci verifică previzualizarea |

Opțional, pentru documente de la alți producători, la **Document nou → Opțiuni** poți cere înlocuirea logo-ului și a numelui producătorului cu TED.

## 5. Limitări cunoscute

- Fontul traducerii este DejaVu Sans (inclus în aplicație, cu diacritice, chirilică și greacă), nu fontul original al documentului.
- Formatarea mixtă din același rând se pierde: de exemplu, în „Length: **522 mm**” totul iese normal sau totul îngroșat.
- Dacă traducerea e mult mai lungă decât originalul, fontul se micșorează, iar paginile afectate sunt raportate la export.
- Paginile scanate pot avea texte ușor deplasate față de original.
- Limbile chineză, japoneză și arabă nu sunt suportate ca limbi de export.

## 6. Pentru dezvoltare

### Rulare din cod (fără instalator)

`INSTALEAZA.bat` (instalează Python dacă lipsește, creează `.venv` și pachetele), apoi `PORNESTE.bat`. Sau manual:

```bash
pip install -r requirements.txt && pip install --no-deps -r requirements-pdf.txt
python app.py
```

### Teste

```bash
python -m unittest discover -s tests -v
```

Testele folosesc un AI simulat și nu trimit nimic pe internet. Pentru o a doua verificare cu Claude, vezi `PROMPT_VERIFICARE_CLAUDE.md`.

### Construirea instalatorului Windows

Pe Linux / WSL (necesită `python3`, `curl` și `unzip`):

```bash
bash windows/build.sh        # => dist/TraduceriTED-windows.zip
```

Scriptul ia Python 3.12 pentru Windows (pachetul oficial de pe NuGet, semnat de Python Software Foundation), adaugă pachetele Windows (Flask, Pillow, PyMuPDF fără părțile opționale mari) și aplicația, într-o arhivă. Arhiva se instalează cu `instalare/instaleaza-windows.ps1`, publicat ca `instaleaza.ps1` în depozitul de versiuni.

### Publicarea unei versiuni noi

1. Mărește numărul din `VERSION` (ex. `1.0.1`) și notează noutățile în `CHANGELOG.md`.
2. `bash windows/build.sh`
3. `python windows/publish_update.py ../Traducere-Agent-Ai-pdf-versiuni --notes "Noutate 1" "Noutate 2"` (adaugă `--assets` dacă s-au schimbat fonturile sau șabloanele PDF).
4. Commit + push în ambele depozite: codul în `Traducere-automata-PDF-`, versiunea în `Traducere-Agent-Ai-pdf-versiuni`.

Aplicațiile instalate văd versiunea nouă la următoarea pornire.
