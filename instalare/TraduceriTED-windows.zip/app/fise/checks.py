"""Verificări pe PDF-urile finale („pluginuri” de control), rulate după export.

Fiecare verificare primește (proiect, limbă, PDF-ul original, PDF-ul tradus) și întoarce o listă de
probleme {page, check, severity, text}. Se adaugă ușor altele: o funcție nouă + o linie în CHECKS.

  cifre        — toate cifrele din original apar și în pagina tradusă
  suprapuneri  — rânduri de text scrise unul peste altul
  ramas        — text original rămas netradus / textul vechi nu a fost șters
  ascuns       — text ascuns (date vechi) rămas în fișier
  vizual (AI)  — un AI compară imaginea paginii originale cu cea tradusă
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

import pymupdf as fitz

from . import ai, memory
from .storage import all_languages, effective_source_language, load_settings, project_dir, text_for

Issue = dict[str, Any]
_NUM = re.compile(r"\d+(?:[.,]\d+)*")


def _issue(page: int, check: str, severity: str, text: str) -> Issue:
    return {"page": page, "check": check, "severity": severity, "text": text}


def _norm_num(n: str) -> str:
    return n.replace(",", ".")


def check_numbers(project, lang, orig: fitz.Document, out: fitz.Document) -> list[Issue]:
    """Fiecare valoare numerică din original trebuie să apară în pagina tradusă (zecimala , sau . e acceptată)."""
    issues = []
    for pinfo in project["doc"]["pages"]:
        page_text = out[pinfo["n"] - 1].get_text()
        present = {_norm_num(n) for n in _NUM.findall(page_text)}
        missing = []
        src_lang = effective_source_language(project)
        for b in pinfo["blocks"]:
            if b.get("skip"):
                continue
            text, _ = text_for(b["text"], lang, src_lang)
            if " ".join(text.split()) == " ".join(b["text"]["src"].split()):
                continue  # neschimbat: rămâne exact ca în original (poate fi chiar în imagine)
            for n in _NUM.findall(b["text"]["src"]):
                if _norm_num(n) not in present and n not in missing:
                    missing.append(n)
        if missing:
            issues.append(_issue(pinfo["n"], "cifre", "error",
                                 f"Valori din original care nu apar în pagina tradusă: {', '.join(missing[:12])}"))
    return issues


def _overlapping_lines(page: fitz.Page) -> list[tuple[fitz.Rect, str, str]]:
    lines = []
    for b in page.get_text("dict")["blocks"]:
        if b.get("type") != 0:
            continue
        for l in b["lines"]:
            t = "".join(s["text"] for s in l["spans"]).strip()
            if len(t) >= 3:
                lines.append((fitz.Rect(l["bbox"]), t))
    out = []
    for i, (r, t) in enumerate(lines):
        for r2, t2 in lines[i + 1:]:
            if (r & r2).get_area() > 0.3 * min(r.get_area(), r2.get_area()) and t != t2:
                out.append((r & r2, t, t2))
    return out


def check_overlaps(project, lang, orig, out: fitz.Document) -> list[Issue]:
    """Rânduri de text care se suprapun în PDF-ul tradus (fără cele care se suprapun deja în original)."""
    issues = []
    for pinfo in project["doc"]["pages"]:
        already = [r for r, _, _ in _overlapping_lines(orig[pinfo["n"] - 1])]
        found = [f"„{t[:30]}” / „{t2[:30]}”" for r, t, t2 in _overlapping_lines(out[pinfo["n"] - 1])
                 if not any((r & a).get_area() > 0 for a in already)]
        if found:
            issues.append(_issue(pinfo["n"], "suprapuneri", "error",
                                 f"{len(found)} texte se suprapun, ex.: {found[0]}"))
    return issues


def check_leftovers(project, lang, orig, out: fitz.Document) -> list[Issue]:
    """Textul original nu trebuie să mai apară acolo unde a fost tradus."""
    src_lang = effective_source_language(project)
    if lang == src_lang:
        return []
    issues = []
    for pinfo in project["doc"]["pages"]:
        page_text = " ".join(out[pinfo["n"] - 1].get_text().split()).lower()
        translated = " | ".join(" ".join(text_for(b["text"], lang, src_lang)[0].split()).lower()
                                for b in pinfo["blocks"] if not b.get("skip"))
        left = []
        for b in pinfo["blocks"]:
            src = " ".join(b["text"]["src"].split())
            text, state = text_for(b["text"], lang, src_lang)
            if b.get("skip") or state == "sursa" or len(src) < 12 or " ".join(text.split()) == src:
                continue
            # apare în pagină de mai multe ori decât apare în textele traduse => a rămas textul vechi
            if page_text.count(src.lower()) > translated.count(src.lower()):
                left.append(src[:40])
        if left:
            issues.append(_issue(pinfo["n"], "ramas", "error",
                                 f"Text original rămas în pagină: „{left[0]}”" + (f" și încă {len(left) - 1}" if len(left) > 1 else "")))
    return issues


def check_hidden(project, lang, orig, out: fitz.Document) -> list[Issue]:
    """Text ascuns (de ex. date vechi acoperite de o imagine) rămas în PDF-ul tradus."""
    from .document import _hidden_rects
    issues = []
    for i, page in enumerate(out):
        hidden = _hidden_rects(page)
        stale = []
        for h in hidden:
            ht = " ".join(getattr(h, "hidden_text", "").split())
            # o etichetă veche identică cu cea vizibilă de deasupra nu contează; o VALOARE diferită, da
            same = any((h & v).get_area() > 0.3 * max(0.01, h.get_area())
                       and " ".join(getattr(v, "hidden_text", "").split()) == ht for v in hidden.visible)
            if ht and not same:
                stale.append(ht)
        if stale:
            issues.append(_issue(i + 1, "ascuns", "warning",
                                 f"{len(stale)} texte vechi ascunse (invizibile) au rămas în fișier, ex.: „{stale[0][:40]}”. "
                                 "Nu se văd la tipar, dar apar la căutare/copiere."))
    return issues


VISUAL_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["problems"],
    "properties": {"problems": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["severity", "problem"],
        "properties": {"severity": {"type": "string", "enum": ["error", "warning"]},
                       "problem": {"type": "string"}}}}},
}


def _visual_prompt(lang: str) -> str:
    return (f"Image 1 is a page of a technical document; image 2 is the same page translated into "
            f"{all_languages().get(lang, lang)}. Act as a print proofreader. List ONLY real visible problems in image 2, "
            "in Romanian: text written over other text, old text still visible under the new text, text cut off or "
            "outside its box/cell, untranslated text, numbers/units that differ from image 1, missing parts (images, "
            "tables, logos) compared to image 1. Text inside photos/screenshots may stay untranslated. "
            "If the page is fine, return an empty list.")


def _visual_prepare(project, lang, orig: fitz.Document, out: fitz.Document, provider) -> tuple[dict, list]:
    """Randează paginile (pe firul principal: PyMuPDF nu e făcut pentru mai multe fire). Paginile care arată
    exact ca la o verificare anterioară primesc rezultatul ținut minte; restul devin lucrări pentru AI."""
    tmp = project_dir(project["id"]) / "cache"
    tmp.mkdir(parents=True, exist_ok=True)
    cached, todo = {}, []
    for pinfo in project["doc"]["pages"]:
        n = pinfo["n"]
        a_png = orig[n - 1].get_pixmap(dpi=110).tobytes("png")
        b_png = out[n - 1].get_pixmap(dpi=110).tobytes("png")
        k = memory.qa_key(lang + "|" + provider.key, a_png, b_png)
        hit = memory.qa_get(k)
        if hit is not None:
            cached[n] = hit
            continue
        a, b = tmp / f"qa-orig-{lang}-{n}.png", tmp / f"qa-{lang}-{n}.png"
        a.write_bytes(a_png)
        b.write_bytes(b_png)
        todo.append({"lang": lang, "n": n, "key": k, "a": a, "b": b})
    return cached, todo


def _visual_run(jobs: list[dict], provider, settings) -> dict[tuple[str, int], list]:
    """Trimite paginile la AI, mai multe deodată, și ține minte rezultatele."""
    def one(job):
        try:
            problems = provider.run(_visual_prompt(job["lang"]), VISUAL_SCHEMA, [job["a"], job["b"]]).get("problems", [])
        finally:
            job["a"].unlink(missing_ok=True)
            job["b"].unlink(missing_ok=True)
        memory.qa_put(job["key"], problems)
        return (job["lang"], job["n"]), problems

    if not jobs:
        return {}
    workers = max(1, min(int(settings.get("parallel_ai") or 3), 6, len(jobs)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        return dict(pool.map(one, jobs))


def _visual_issues(pages: dict[int, list]) -> list[Issue]:
    return [_issue(n, "vizual", p.get("severity", "warning"), p.get("problem", ""))
            for n in sorted(pages) for p in pages[n]]


def check_visual(project, lang, orig: fitz.Document, out: fitz.Document) -> list[Issue]:
    """Un AI se uită la pagina originală și la cea tradusă, ca un om care verifică tiparul."""
    settings = load_settings()
    provider = ai.for_role("verify", settings)
    cached, todo = _visual_prepare(project, lang, orig, out, provider)
    for (_, n), problems in _visual_run(todo, provider, settings).items():
        cached[n] = problems
    return _visual_issues(cached)


CHECKS: list[tuple[str, str, Callable, bool]] = [
    # (cod, nume afișat, funcție, folosește AI)
    ("cifre", "Cifre și valori", check_numbers, False),
    ("suprapuneri", "Text suprapus", check_overlaps, False),
    ("ramas", "Text original rămas", check_leftovers, False),
    ("ascuns", "Text ascuns rămas", check_hidden, False),
    ("vizual", "Verificare vizuală cu AI", check_visual, True),
]


def run_checks(project: dict[str, Any], languages: list[str], progress, use_ai: bool = True) -> dict[str, list[Issue]]:
    exports = {e["lang"]: e for e in project.get("exports", [])}
    orig = fitz.open(project_dir(project["id"]) / project["sources"][0]["path"])
    settings = load_settings()
    result: dict[str, list[Issue]] = {}
    visual: dict[str, dict[int, list]] = {}
    jobs: list[dict] = []
    provider = None
    try:
        for lang in languages:
            e = exports.get(lang)
            if not e:
                continue
            path = project_dir(project["id"]) / e["file"]
            if not Path(path).exists():
                continue
            out = fitz.open(path)
            issues: list[Issue] = []
            for code, name, fn, needs_ai in CHECKS:
                if needs_ai:
                    if not use_ai:
                        continue
                    # verificarea vizuală: doar pregătim paginile; le trimitem la AI pe toate deodată, mai jos
                    progress(f"Pregătesc verificarea vizuală: {all_languages().get(lang, lang)}…")
                    try:
                        provider = provider or ai.for_role("verify", settings)
                        visual[lang], todo = _visual_prepare(project, lang, orig, out, provider)
                        jobs += todo
                    except ai.AIError as err:
                        issues.append(_issue(0, code, "warning", f"Verificarea „{name}” nu a putut rula: {err}"))
                    continue
                progress(f"Verific PDF-ul {all_languages().get(lang, lang)}: {name}…")
                issues += fn(project, lang, orig, out)
            out.close()
            result[lang] = issues
    finally:
        orig.close()
    if jobs and provider:
        cached = sum(len(v) for v in visual.values())
        progress(f"Verificare vizuală cu AI: {len(jobs)} pagini" + (f" ({cached} neschimbate, din memorie)" if cached else "") + "…")
        try:
            for (lang, n), problems in _visual_run(jobs, provider, settings).items():
                visual[lang][n] = problems
        except ai.AIError as err:
            for lang in visual:
                result[lang].append(_issue(0, "vizual", "warning", f"Verificarea vizuală nu a putut rula: {err}"))
    for lang, pages in visual.items():
        result[lang] += _visual_issues(pages)
    project["qa"] = {**(project.get("qa") or {}), **result}
    return result
