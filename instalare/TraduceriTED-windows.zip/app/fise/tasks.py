"""Traducerea (fiecare limbă direct din textul verificat) și verificarea traducerilor."""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable

from . import ai, memory
from .catalog import LANGUAGE_ENGLISH_NAMES
from .storage import all_languages, effective_source_language, has_words, iter_fields, load_settings, now

Progress = Callable[[str], None]
_NUM = re.compile(r"\d+(?:[.,]\d+)*")


def numbers(text: str) -> list[str]:
    return sorted(_NUM.findall(text or ""))


def lang_name(code: str) -> str:
    return LANGUAGE_ENGLISH_NAMES.get(code) or all_languages().get(code, code)


TRANSLATE_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["translations"],
    "properties": {"translations": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["id", "text"],
        "properties": {"id": {"type": "string"}, "text": {"type": "string"}}}}},
}

TR_CHECK_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["issues"],
    "properties": {"issues": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["id", "problem", "suggestion"],
        "properties": {"id": {"type": "string"}, "problem": {"type": "string"},
                       "suggestion": {"type": "string"}}}}},
}


def needs_translation(f: dict[str, Any], lang: str, source_lang: str, force: bool = False) -> bool:
    src = f.get("src", "")
    if not src.strip() or not has_words(src) or source_lang == lang:
        return False  # valorile tehnice (12.8V, 300Ah) rămân identice în toate limbile
    if lang in f.get("ov", {}):
        return False  # corectura manuală nu se atinge niciodată
    if force:
        return True
    return f.get("tr_src", {}).get(lang) != src or lang not in f.get("tr", {})


def _item(f: dict[str, Any]) -> dict[str, Any]:
    """Fragmentul de tradus; textele scurte (celule, titluri) primesc o limită de lungime, ca să încapă."""
    src = f["src"]
    item: dict[str, Any] = {"id": f["id"], "text": src}
    if len(src) <= 60:
        item["max_chars"] = max(len(src) + 6, round(len(src) * 1.3))
    return item


def _prompt(lang: str, src_lang: str, items: list[dict], brand_names: list[str]) -> str:
    brand = ""
    if brand_names:
        brand = ("The document is re-branded for TED Electric: replace the manufacturer names "
                 + ", ".join(f'"{n}"' for n in brand_names) + ' with "TED", and their websites/e-mails with '
                 "www.tedelectric.eu.\n")
    return brand + f"""Translate these fragments of a technical product document (datasheet / user manual) from
{lang_name(src_lang)} into {lang_name(lang)}. Each fragment is one text block of a page (a title, paragraph, list item
or table cell); translate each one directly from the original.
Rules: use the standard technical terminology of {lang_name(lang)} electrical/battery product documentation.
Keep every number, decimal separator, range, tolerance, unit, symbol, model code and product identifier exactly
unchanged. Do not add, remove or explain information. Keep UPPER-CASE text upper-case. Keep each translation as
concise as possible: it must fit in the same place on the page. When an item has "max_chars", the translation
must not be longer than that (table cells, headings): use the standard abbreviations of {lang_name(lang)} technical
documentation if needed (e.g. "max.", "temp.", "coef."), never drop information. Return one translation per input id.

FRAGMENTS (JSON):
{json.dumps(items, ensure_ascii=False)}"""


def _brand_sensitive(f: dict[str, Any], brand_names: list[str]) -> bool:
    """Texte cu numele / site-ul producătorului: la re-branding traducerea lor depinde de document."""
    if not brand_names:
        return False
    t = f["src"].lower()
    return any(n.lower() in t for n in brand_names if n) or "www." in t or "@" in t or "http" in t


def _workers(settings: dict[str, Any], n: int) -> int:
    return max(1, min(int(settings.get("parallel_ai") or 3), 6, n))


def translate(project: dict[str, Any], languages: list[str], progress: Progress, force: bool = False) -> dict:
    """Traduce în toate limbile, în paralel. Textele aflate deja în memoria de traduceri (traduse și verificate
    înainte, sau corectate de tine) se iau direct de acolo; doar restul merg la AI."""
    if not project.get("doc"):
        raise ai.AIError("Documentul nu a fost încă scanat.")
    settings = load_settings()
    provider = ai.for_role("translate", settings)
    src_lang = effective_source_language(project)
    brand_names = project["doc"].get("manufacturer_names", []) if project.get("replace_brand") else []
    use_mem = bool(settings.get("use_memory", True)) and not force
    status: dict[str, str] = {}

    def show(lang: str, msg: str) -> None:
        status[lang] = msg
        progress("Traduc: " + " · ".join(status.values()))

    def one(lang: str) -> tuple[str, int, int]:
        name = all_languages().get(lang, lang)
        todo = [f for f in iter_fields(project) if needs_translation(f, lang, src_lang, force)]
        from_mem = 0
        if use_mem and todo:
            usable = [f for f in todo if not _brand_sensitive(f, brand_names)]
            hits = memory.lookup(src_lang, lang, [f["src"] for f in usable])
            usable_ids = {id(f) for f in usable}
            rest = []
            for f in todo:
                h = hits.get(f["src"]) if id(f) in usable_ids else None
                if not h:
                    rest.append(f)
                    continue
                f.setdefault("tr", {})[lang] = h["text"]
                f.setdefault("tr_src", {})[lang] = f["src"]
                f.setdefault("mem", {})[lang] = h["quality"]
                warn = f.setdefault("warn", {})
                if numbers(f["src"]) != numbers(h["text"]):
                    warn[lang] = "Cifrele din traducere diferă de original."
                else:
                    warn.pop(lang, None)
                from_mem += 1
            todo = rest
        for f in todo:
            f.get("mem", {}).pop(lang, None)
        done = 0
        if not todo:
            show(lang, f"{name} gata ({from_mem} din memorie)")
        for start in range(0, len(todo), 120):
            chunk = todo[start:start + 120]
            show(lang, f"{name} {start + len(chunk)}/{len(todo)}" + (f" (+{from_mem} din memorie)" if from_mem else ""))
            items = [_item(f) for f in chunk]
            out = provider.run(_prompt(lang, src_lang, items, brand_names), TRANSLATE_SCHEMA)
            by_id = {t["id"]: t["text"] for t in out.get("translations", []) if isinstance(t, dict)}
            retry = [f for f in chunk if not by_id.get(f["id"]) or "�" in by_id[f["id"]]]
            if retry:  # a doua încercare pentru textele lipsă sau cu caractere stricate
                again = provider.run(_prompt(lang, src_lang, [_item(f) for f in retry],
                                             brand_names), TRANSLATE_SCHEMA)
                by_id.update({t["id"]: t["text"] for t in again.get("translations", []) if isinstance(t, dict)})
            for f in chunk:
                text = by_id.get(f["id"])
                if not text or "�" in text:
                    continue
                f.setdefault("tr", {})[lang] = text
                f.setdefault("tr_src", {})[lang] = f["src"]
                warn = f.setdefault("warn", {})
                if numbers(f["src"]) != numbers(text):
                    warn[lang] = "Cifrele din traducere diferă de original."
                else:
                    warn.pop(lang, None)
                done += 1
        show(lang, f"{name} gata")
        return lang, done + from_mem, from_mem

    report: dict[str, int] = {}
    mem_hits: dict[str, int] = {}
    # limbile se traduc în paralel (fiecare limbă e un apel separat la AI)
    with ThreadPoolExecutor(max_workers=_workers(settings, len(languages))) as pool:
        for lang, n, m in pool.map(one, languages):
            report[lang], mem_hits[lang] = n, m
    total_mem = sum(mem_hits.values())
    project["memory_hits"] = mem_hits
    project["log"].append({"at": now(), "what": f"Traducere {', '.join(languages)} cu {provider.label}"
                           + (f" ({total_mem} texte din memorie)" if total_mem else "")})
    return report


VERIFY_PROMPT = """Check these {lang} translations of a technical product document against
the {src} originals. Report only real errors: wrong meaning, wrong technical term, changed or missing
numbers/units/codes, untranslated text, grammar errors. Write "problem" in Romanian and "suggestion" as the corrected
{lang} text: exactly ONE complete corrected translation of the whole fragment (no alternatives, no "/" between
options, no comments), ready to replace the current translation.

PAIRS (JSON):
{pairs}"""


def verify_translations(project: dict[str, Any], languages: list[str], progress: Progress) -> dict:
    """Verifică traducerile cu al doilea AI (toate limbile în paralel). Textele luate din memorie au fost deja
    verificate și nu se mai trimit. Traducerile bune se salvează în memorie, pentru documentele următoare."""
    settings = load_settings()
    provider = ai.for_role("verify", settings)
    src_lang = effective_source_language(project)
    brand_names = project["doc"].get("manufacturer_names", []) if project.get("replace_brand") else []
    verify_mem = bool(settings.get("verify_memory", False))
    learn = bool(settings.get("use_memory", True))
    result: dict[str, Any] = {"provider": provider.label, "at": now(), "issues": {}, "from_memory": {}}
    status: dict[str, str] = {}

    def show(lang: str, msg: str) -> None:
        status[lang] = msg
        progress("Verific traducerile: " + " · ".join(status.values()))

    def one(lang: str) -> tuple[str, int | None, int]:
        if lang == src_lang:
            return lang, None, 0
        name = all_languages().get(lang, lang)
        fields = [f for f in iter_fields(project) if lang in f.get("tr", {}) or lang in f.get("ov", {})]
        for f in fields:
            f.get("check", {}).pop(lang, None)
        known = [f for f in fields if f.get("mem", {}).get(lang) and lang not in f.get("ov", {}) and not verify_mem]
        known_ids = {id(f) for f in known}
        todo = [f for f in fields if id(f) not in known_ids]
        pairs = [{"id": f["id"], "original": f["src"], "translation": f.get("ov", {}).get(lang) or f["tr"][lang]}
                 for f in todo]
        by_id = {f["id"]: f for f in fields}
        found, flagged = 0, set()
        if not pairs:
            show(lang, f"{name} gata (tot din memorie)")
        for start in range(0, len(pairs), 150):
            chunk = pairs[start:start + 150]
            show(lang, f"{name} {start + len(chunk)}/{len(pairs)}" + (f" (+{len(known)} din memorie)" if known else ""))
            o = provider.run(VERIFY_PROMPT.format(lang=lang_name(lang), src=lang_name(src_lang),
                                                  pairs=json.dumps(chunk, ensure_ascii=False)), TR_CHECK_SCHEMA)
            for issue in o.get("issues", []):
                f = by_id.get(issue.get("id"))
                if not f:
                    continue
                sug = (issue.get("suggestion") or "").strip()
                check = {"problem": issue.get("problem", ""), "suggestion": sug}
                # corectăm automat traducerea AI (nu și corecturile tale), dacă cifrele rămân aceleași
                if sug and lang not in f.get("ov", {}) and numbers(sug) == numbers(f["src"]):
                    check.update({"applied": True, "before": f["tr"].get(lang, "")})
                    f["tr"][lang] = sug
                    f.setdefault("warn", {}).pop(lang, None)
                else:
                    flagged.add(f["id"])  # problemă nerezolvată: nu intră în memorie
                f.setdefault("check", {})[lang] = check
                found += 1
        if learn:  # învățăm: traducerile verificate (și corecturile tale) intră în memorie
            ok = [f for f in todo if f["id"] not in flagged and not f.get("warn", {}).get(lang)
                  and not _brand_sensitive(f, brand_names)]
            memory.store(src_lang, lang, [(f["src"], f["tr"][lang]) for f in ok
                                          if lang not in f.get("ov", {}) and lang in f.get("tr", {})], "verificat")
            memory.store(src_lang, lang, [(f["src"], f["ov"][lang]) for f in ok if lang in f.get("ov", {})], "manual")
        show(lang, f"{name} gata")
        return lang, found, len(known)

    with ThreadPoolExecutor(max_workers=_workers(settings, len(languages))) as pool:
        for lang, found, known in pool.map(one, languages):
            if found is not None:
                result["issues"][lang] = found
                result["from_memory"][lang] = known
    project["verification"] = result
    project["log"].append({"at": now(), "what": f"Verificare traduceri cu {provider.label}"})
    return result
