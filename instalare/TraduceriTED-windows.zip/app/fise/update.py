"""Actualizări automate din GitHub.

Versiunile noi sunt publicate în depozitul de versiuni:
    https://github.com/Banuta/Traducere-Agent-Ai-pdf-versiuni
care conține `latest.json`:
    {"version": "1.0.1", "date": "...", "notes": ["..."],
     "package": "actualizari/TraduceriTED-1.0.1.zip", "sha256": "...",
     "bundle": "instalare/TraduceriTED-windows.zip", "bundle_sha256": "...", "bundle_size": 52000000}
(`bundle` = pachetul complet, cu Python inclus, folosit de instaleaza.ps1 la prima instalare.)

Pașii unei actualizări:
  1. `check()`    — citește latest.json și compară cu versiunea instalată (fișierul VERSION);
  2. `download()` — descarcă pachetul, verifică sha256 și îl dezarhivează în `<instalare>/update/pending`;
  3. aplicația repornește: `apply_pending()` rulează la pornire, ÎNAINTE de a încărca restul codului,
     înlocuiește fișierele aplicației (datele din `data` nu se ating) și instalează pachetele noi.
Dacă ceva nu merge, versiunea veche rămâne în `<instalare>/update/backup` și se pune la loc.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

APP = Path(__file__).resolve().parent.parent          # folderul aplicației (cod)
REPO = "Banuta/Traducere-Agent-Ai-pdf-versiuni"
BRANCH = "main"
# TRADUCERI_TED_UPDATE_URL: altă sursă de actualizări (pentru teste); implicit depozitul de versiuni de pe GitHub
RAW = os.environ.get("TRADUCERI_TED_UPDATE_URL") or f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/"
PAGE = f"https://github.com/{REPO}"
# ce înlocuiește o actualizare (restul — data, python — rămâne neatins)
APP_ITEMS = ["app.py", "VERSION", "fise", "static", "templates", "fonts", "sabloane", "instalare",
             "requirements.txt", "requirements-pdf.txt", "requirements-api.txt", "README.md"]
WINDOWS = sys.platform == "win32"


def current_version() -> str:
    try:
        return (APP / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def _vtuple(v: str) -> tuple[int, ...]:
    out = []
    for part in str(v).strip().lstrip("vV").split("."):
        digits = "".join(c for c in part if c.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out + [0] * (3 - len(out)))


def installed_layout() -> bool:
    """Aplicația e instalată cu instalatorul Windows (are Python-ul ei în `<instalare>/python`)."""
    return (APP.parent / "python" / "python.exe").exists()


def _work() -> Path:
    return (APP.parent if installed_layout() else APP / "data") / "update"


def _get(url: str, timeout: int = 15) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "TraduceriTED-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (URL fix, https)
        return r.read()


def check(timeout: int = 8) -> dict[str, Any]:
    cur = current_version()
    try:
        info = json.loads(_get(RAW + "latest.json", timeout).decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        return {"current": cur, "available": False, "error": f"Nu am putut verifica actualizările: {e}"}
    latest = str(info.get("version", "0"))
    return {"current": cur, "latest": latest, "available": _vtuple(latest) > _vtuple(cur),
            "notes": info.get("notes", []), "date": info.get("date", ""),
            "can_apply": installed_layout(), "page": PAGE,
            "installer": PAGE}


def download(progress=lambda m: None) -> dict[str, Any]:
    info = json.loads(_get(RAW + "latest.json").decode("utf-8"))
    if _vtuple(info["version"]) <= _vtuple(current_version()):
        raise RuntimeError("Ai deja ultima versiune.")
    progress(f"Descarc versiunea {info['version']}…")
    data = _get(RAW + info["package"], timeout=300)
    if hashlib.sha256(data).hexdigest() != info.get("sha256", ""):
        raise RuntimeError("Pachetul descărcat este deteriorat (sha256 diferit). Încearcă din nou.")
    work = _work()
    pending = work / "pending"
    shutil.rmtree(pending, ignore_errors=True)
    pending.mkdir(parents=True)
    zpath = work / "pachet.zip"
    zpath.write_bytes(data)
    with zipfile.ZipFile(zpath) as z:
        for name in z.namelist():  # nimic în afara folderului
            target = (pending / name).resolve()
            if not str(target).startswith(str(pending.resolve())):
                raise RuntimeError("Pachet de actualizare invalid.")
        z.extractall(pending)
    zpath.unlink(missing_ok=True)
    if not (pending / "VERSION").exists() or not (pending / "fise").is_dir():
        shutil.rmtree(pending, ignore_errors=True)
        raise RuntimeError("Pachet de actualizare incomplet.")
    progress("Gata. Aplicația repornește…")
    return {"version": info["version"]}


def restart_into_update(port: int | None = None) -> None:
    """Pornește o instanță nouă (care aplică actualizarea), apoi oprește procesul curent."""
    python = Path(sys.executable)
    if WINDOWS and python.name.lower() == "python.exe" and (python.parent / "pythonw.exe").exists():
        python = python.parent / "pythonw.exe"
    flags = 0x00000008 | 0x00000200 if WINDOWS else 0  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    args = [str(python), "-s", str(APP / "app.py"), "--after-update"] + (["--port", str(port)] if port else [])
    subprocess.Popen(args, cwd=str(APP), creationflags=flags,
                     close_fds=True)


def apply_pending(log=print) -> str | None:
    """Rulează la pornire. Întoarce versiunea instalată, sau None dacă nu era nimic de aplicat."""
    work = _work()
    pending = work / "pending"
    if not (pending / "VERSION").exists():
        return None
    new_version = (pending / "VERSION").read_text(encoding="utf-8").strip()
    backup = work / "backup"
    shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True)
    old_req = _read(APP / "requirements.txt") + _read(APP / "requirements-pdf.txt")
    moved: list[str] = []
    try:
        for item in APP_ITEMS:
            src = pending / item
            if not src.exists():
                continue
            dst = APP / item
            if dst.exists():
                shutil.move(str(dst), str(backup / item))
                moved.append(item)
            shutil.move(str(src), str(dst))
    except Exception as e:  # noqa: BLE001 — punem la loc versiunea veche
        log(f"Actualizarea a eșuat ({e}); revin la versiunea anterioară.")
        for item in moved:
            shutil.rmtree(APP / item, ignore_errors=True) if (APP / item).is_dir() else (APP / item).unlink(missing_ok=True)
            shutil.move(str(backup / item), str(APP / item))
        shutil.rmtree(pending, ignore_errors=True)
        return None
    shutil.rmtree(pending, ignore_errors=True)
    if _read(APP / "requirements.txt") + _read(APP / "requirements-pdf.txt") != old_req:
        install_requirements(log)
    log(f"Actualizat la versiunea {new_version}.")
    return new_version


def install_requirements(log=print) -> None:
    python = Path(sys.executable)
    if python.name.lower() == "pythonw.exe" and (python.parent / "python.exe").exists():
        python = python.parent / "python.exe"
    py = [str(python), "-s", "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location",
          "--only-binary=:all:"]
    flags = 0x08000000 if WINDOWS else 0  # fără fereastră
    for args in (["-r", str(APP / "requirements.txt")], ["--no-deps", "-r", str(APP / "requirements-pdf.txt")]):
        if Path(args[-1]).exists():
            r = subprocess.run(py + args, capture_output=True, text=True, creationflags=flags)
            if r.returncode:
                log("Instalarea pachetelor noi a eșuat: " + (r.stderr or r.stdout)[-400:])


def _read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except OSError:
        return ""
