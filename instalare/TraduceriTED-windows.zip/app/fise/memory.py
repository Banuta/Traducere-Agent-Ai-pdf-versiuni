"""Memoria de traduceri: programul „învață” din ce a tradus deja.

Fiecare text tradus și VERIFICAT se salvează (original → traducere, pe limbă). Data viitoare, același text
(de ex. „Max. Power (Pm)” din altă fișă tehnică) se ia direct din memorie, fără AI: instant și identic cu
traducerea verificată de dinainte. Corecturile tale manuale au prioritate și se folosesc și ele mai departe.

Tot aici se țin minte și rezultatele verificării vizuale cu AI: o pagină tradusă care arată exact la fel ca
data trecută (aceeași imagine) nu mai este trimisă din nou la AI.

Totul stă local, în data/memorie/memorie.sqlite3.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
from contextlib import closing
from typing import Any

from . import storage

_lock = threading.Lock()
QUALITY = {"verificat": 1, "manual": 2}  # o corectură manuală nu e înlocuită de una automată


def _db() -> sqlite3.Connection:
    path = storage.DATA / "memorie" / "memorie.sqlite3"
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.execute("""CREATE TABLE IF NOT EXISTS tm (
        src_lang TEXT NOT NULL, lang TEXT NOT NULL, key TEXT NOT NULL, src TEXT NOT NULL, text TEXT NOT NULL,
        quality TEXT NOT NULL, uses INTEGER NOT NULL DEFAULT 0, updated TEXT NOT NULL,
        PRIMARY KEY (src_lang, lang, key))""")
    con.execute("""CREATE TABLE IF NOT EXISTS qa (key TEXT PRIMARY KEY, result TEXT NOT NULL, updated TEXT NOT NULL)""")
    return con


def key(src: str) -> str:
    """Același text, indiferent de spațiile și rândurile în plus."""
    return " ".join((src or "").split())


NON_LATIN = {"el", "bg", "ru", "uk", "sr", "mk", "be", "ka", "hy", "he", "ar", "fa", "zh", "ja", "ko", "th", "hi", "kk"}
_WORD = re.compile(r"[A-Za-z][A-Za-z\-]{3,}")


def learnable(src: str, text: str, lang: str) -> bool:
    """Traducere bună de ținut minte? O limbă cu alt alfabet (greacă, bulgară…) în care textul a rămas în
    engleză nu se învață (ex. „Barcode” netradus în greacă), cu excepția codurilor, acronimelor, site-urilor și
    a numelui TED: acelea rămân corect la fel."""
    if key(src) != key(text) or lang not in NON_LATIN:
        return True
    t = re.sub(r"\S*(www\.|https?:|@)\S*", " ", text)
    words = [w for w in _WORD.findall(t) if not w.isupper() and w.lower() not in ("electric", "ted")]
    return not words


def lookup(src_lang: str, lang: str, srcs: list[str]) -> dict[str, dict[str, str]]:
    """{text original: {"text": traducere, "quality": verificat|manual}} pentru textele aflate în memorie."""
    keys = sorted({key(s) for s in srcs if key(s)})
    found: dict[str, dict[str, str]] = {}
    if not keys:
        return found
    with _lock, closing(_db()) as con:
        for i in range(0, len(keys), 400):
            part = keys[i:i + 400]
            rows = con.execute(f"SELECT key, text, quality FROM tm WHERE src_lang=? AND lang=? AND key IN "
                               f"({','.join('?' * len(part))})", [src_lang, lang, *part]).fetchall()
            for k, text, quality in rows:
                found[k] = {"text": text, "quality": quality}
        if found:
            con.executemany("UPDATE tm SET uses = uses + 1 WHERE src_lang=? AND lang=? AND key=?",
                            [(src_lang, lang, k) for k in found])
            con.commit()
    return {s: found[key(s)] for s in srcs if key(s) in found}


def store(src_lang: str, lang: str, items: list[tuple[str, str]], quality: str = "verificat") -> int:
    """Salvează perechi (original, traducere). O corectură manuală nu e suprascrisă de una verificată automat."""
    rows = [(src_lang, lang, key(s), s, t, quality, storage.now()) for s, t in items
            if key(s) and (t or "").strip() and (quality == "manual" or learnable(s, t, lang))]
    if not rows:
        return 0
    with _lock, closing(_db()) as con:
        if quality == "manual":
            con.executemany("""INSERT INTO tm (src_lang, lang, key, src, text, quality, updated) VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(src_lang, lang, key) DO UPDATE SET text=excluded.text, quality=excluded.quality,
                updated=excluded.updated""", rows)
        else:
            con.executemany("""INSERT INTO tm (src_lang, lang, key, src, text, quality, updated) VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(src_lang, lang, key) DO UPDATE SET text=excluded.text, updated=excluded.updated
                WHERE tm.quality <> 'manual'""", rows)
        con.commit()
    return len(rows)


def forget(src_lang: str, lang: str, src: str, quality: str | None = None) -> None:
    with _lock, closing(_db()) as con:
        if quality:
            con.execute("DELETE FROM tm WHERE src_lang=? AND lang=? AND key=? AND quality=?",
                        (src_lang, lang, key(src), quality))
        else:
            con.execute("DELETE FROM tm WHERE src_lang=? AND lang=? AND key=?", (src_lang, lang, key(src)))
        con.commit()


def stats() -> dict[str, Any]:
    with _lock, closing(_db()) as con:
        per = dict(con.execute("SELECT lang, COUNT(*) FROM tm GROUP BY lang ORDER BY COUNT(*) DESC").fetchall())
        manual = con.execute("SELECT COUNT(*) FROM tm WHERE quality='manual'").fetchone()[0]
        reused = con.execute("SELECT COALESCE(SUM(uses), 0) FROM tm").fetchone()[0]
        pages = con.execute("SELECT COUNT(*) FROM qa").fetchone()[0]
    return {"total": sum(per.values()), "per_lang": per, "manual": manual, "reused": reused, "qa_pages": pages}


def clear() -> None:
    with _lock, closing(_db()) as con:
        con.execute("DELETE FROM tm")
        con.execute("DELETE FROM qa")
        con.commit()


# ------------------------------------------------------------ verificarea vizuală
def qa_key(lang: str, *images: bytes) -> str:
    h = hashlib.sha256(lang.encode())
    for img in images:
        h.update(hashlib.sha256(img).digest())
    return h.hexdigest()


def qa_get(k: str) -> list[dict[str, Any]] | None:
    with _lock, closing(_db()) as con:
        row = con.execute("SELECT result FROM qa WHERE key=?", (k,)).fetchone()
    return json.loads(row[0]) if row else None


def qa_put(k: str, problems: list[dict[str, Any]]) -> None:
    with _lock, closing(_db()) as con:
        con.execute("INSERT OR REPLACE INTO qa (key, result, updated) VALUES (?,?,?)",
                    (k, json.dumps(problems, ensure_ascii=False), storage.now()))
        con.commit()
